# MPPI GPU Controller — 代价函数全览

> 文件: `src/mppi_gpu_kernels.cu` → `mppi_sample_kernel()` (行 73–446)
> 所有代价项均在 GPU 内核中**每步 (per-timestep)** 计算，除以 `horizon` 归一化后累加。终端项在循环后一次性加入。

---

## 一、控制量采样 (Control Sampling)

### Guidance 混合机制 (行 181–193)

```
vx = (1−γ) · (base_vx + noise_vx·scale) + γ · path_dir_x_robot · base_speed_clamped
vy = (1−γ) · (base_vy + noise_vy·cross_track_scale) + γ · path_dir_y_robot · base_speed_clamped · lateral_scale
ω  = base_w + noise_w·scale + path_angle_error · (0.5/dt) · γ
```

| 参数 | 默认 | 作用 |
|------|------|------|
| `guidance_weight` (γ) | 0.35 | 0=纯base+噪声, 1=纯路径锚定 |
| `cross_track_noise_scale` | 0.5 | 横向噪声缩放，越小越抑制侧向探索 |
| `lateral_guidance_scale` | 0.15 | 横向 guidance 缩放，越小越抑制 vy |
| `noise_decay_rate` | 0.85 | 噪声随时间衰减: `1 − decay·t/(H−1)`, min 0.15 |

### 控制量 Clamp (行 195–197)

```
vx ∈ [min_v, max_v],  vy ∈ [−max_vy, max_vy],  ω ∈ [−max_w, max_w]
```

### 末端阻尼 (行 199–220)

| 阻尼 | 条件 | 效果 |
|------|------|------|
| **角速度阻尼** | dist_to_target < 1.5m | `ω *= dist/1.5` (min 0.06) |
| **平滑到达阻尼** | dist_to_target < 0.4m | `vx,vy,ω *= √(dist/0.4)` — ease-out 减速 |

---

## 二、逐步代价（每 timestep H=10 次循环累加，除以 horizon 归一化）

### ⓪ 速度奖励 (行 255–259) ◆ 奖励

```
cost −= max(0, speed_along_path) × speed_reward_weight / H
```

- 沿路径方向的速度分量 → **负代价（奖励）**
- 横向/后退速度不奖励
- `speed_reward_weight` = 6.0 (鼓励快速前进)

### ① 目标点渐进吸引 (行 261–266) ◆ 惩罚

```
cost += ‖(x,y) − (target_x,target_y)‖ × (1 − t/H) × 0.2
```

- 越靠近终点、越后期（`t/H → 1`），权重越小 → "先别急，后期再收束"
- 固定系数 `path_cost_weight = 0.2`

### ② 代价地图碰撞/膨胀（复杂） (行 326–405) ◆ 惩罚

**2a. 已知障碍物代价** (行 381–385)
```
cost += (max_known / 255)² × costmap_weight / H
```
- 8 个足迹采样点，双线性插值查询 costmap
- `max_known`: 取所有足迹点中最大的已知障碍物值 (≤254)
- 平方归一化保持对高代价栅格的敏感性

**2b. 各向异性势能场** (行 387–391)
```
cost += dir_norm × costmap_weight × 0.3 / H
```
- 宽边方向遇障 → 代价放大 (×宽窄比)
- 推动 MPPI 选择窄边面向障碍物通行

**2c. 分方向未知区域代价** (行 393–405)
```
cost += unknown_total × costmap_weight / H / 8
unknown_total = rear×1.0 + side×0.7 + front×0.0
```
- 后方未知 > 侧方未知 > 前方未知（机器人仅有前方视野）
- `corridor_trust` 折扣：深色走廊内未知 → 可通行
- `trail_confidence` 折扣：近期经过/看到过的区域 → 降低未知代价

### ③ 全局路径吸引 (行 407–411) ◆ 惩罚

```
cost += traj_to_path² × path_attract_t
path_attract_t = path_attraction_weight × (1 + 1.2 × t/H)
```
- 轨迹点到最近路径段的距离平方
- 渐进增强：远端 (`t→H`) 惩罚更严

### ④ 朝向奖励 (行 413–418) ◆ 惩罚

```
cost += |atan2(vy, vx)| × heading_weight / H
```
- 速度方向偏离机头朝向的角度
- `heading_weight` = 0.8

### ⑤ 路径长度惩罚 (行 420–423) ◆ 惩罚

```
cost += step_distance × 0.02
```
- 每步位移距离，防止绕路
- 固定系数 `len_weight = 0.02`

---

## 三、终端代价（循环后一次性加入）

### ⑥ 终点距离 (行 429–433) ◆ 惩罚

```
cost += ‖(x_T,y_T) − (target_x,target_y)‖ × 1.0
```
- T=H步后轨迹终点到前瞻点的直线距离
- 固定系数 `dist_weight = 1.0`

### ⑦ 终端朝向对齐 (行 435–443) ◆ 惩罚

```
cost += |heading_to_target − θ_T| × 0.6 × goal_proximity
goal_proximity = 1 / (1 + dist² × 5)
```
- 仅终点附近 (d<1.5m) 生效，远离时趋于零
- 终端朝向对齐到目标方向

---

## 四、代价函数总结表

| # | 名称 | 类型 | 权重参数 | 权重默认 | 作用 |
|---|------|------|----------|----------|------|
| ⓪ | 速度奖励 | **奖励**(−) | `speed_reward_weight` | 6.0 | 鼓励沿路径方向快速前进 |
| ① | 目标渐进吸引 | 惩罚(+) | `path_cost_weight` | 0.2 (固定) | 越后期越靠近前瞻点 |
| 2a | 已知障碍物 | 惩罚(+) | `costmap_weight` | 2.0 | 8点碰撞检测，平方归一化 |
| 2b | 各向异性势能 | 惩罚(+) | (内嵌) | 0.3×costmap_weight | 宽边障碍物额外惩罚 |
| 2c | 未知区域 | 惩罚(+) | `unknown_cost_{rear,side,front}` | 1.0/0.7/0.0 | 分方向+走廊信任+观测折扣 |
| ③ | 全局路径吸引 | 惩罚(+) | `path_attraction_weight` | 0.15 | Cross-track error 平方，渐进增强 |
| ④ | 朝向一致性 | 惩罚(+) | `heading_weight` | 0.8 | 速度方向对齐机头朝向 |
| ⑤ | 路径长度 | 惩罚(+) | `len_weight` | 0.02 (固定) | 反绕路 |
| ⑥ | 终端距离 | 惩罚(+) | `dist_weight` | 1.0 (固定) | 轨迹终点到前瞻点 |
| ⑦ | 终端朝向 | 惩罚(+) | (固定) | 0.6 | 终点朝向对齐，距离门控 |

---

## 五、CPU 端附加行为 (computeVelocityCommands)

### 横向偏好分析 (行 626–680)
- 在前瞻点处沿路径法向扫描 costmap (0.3m~1.8m)
- 比较左右两侧空闲度，带迟滞选择绕行方向
- 将 path_direction 微旋 ±6° 偏向空闲侧
- 可通过 `enable_lateral_bias` 关闭

### 最小输出兜底 (行 975–987)
- 当 best_vx/vy/ω 均 < 0.01 时
- 强制 vx=0.3, ω=0.5×heading_err (朝向目标)

### 终端角度对准 (行 410–435)
- dist_to_final_goal < `terminal_angle_dist` (0.10m)
- 退化 MPPI → 纯角度 P 控制器
- vx=vy=0, 仅追踪目标朝向

### EMA 输出平滑 (行 960–970)
- `cmd = α × raw + (1−α) × prev_cmd`
- `ema_alpha` = 0.1 (约 0.25s 时间常数@20Hz)
