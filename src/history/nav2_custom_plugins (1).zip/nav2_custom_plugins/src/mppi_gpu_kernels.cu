/**
 * @file mppi_gpu_kernels.cu
 * @brief MPPI GPU 内核 — 采样、轨迹滚动、代价计算与全时域加权求和
 *
 * 本文件是 MPPI GPU 加速的入口，包含两个 CUDA 内核:
 *   1. mppi_sample_kernel      — 并行采样 N 条轨迹并计算每条代价
 *   2. mppi_weighted_sum_kernel — 按代价指数加权，对每个 timestep 独立求和
 *
 * 以及两个 host 端包装函数 (extern "C"):
 *   3. mppi_gpu_sample_and_cost — 上传数据到 GPU，启动采样内核
 *   4. mppi_gpu_weighted_sum    — 启动加权求和内核
 *
 * 代价函数设计:
 *   本内核将每个奖励/惩罚项的计算委托给 mppi_gpu_rewards.cuh 中的
 *   独立 __device__ 函数，主循环中仅负责调用与累加：
 *
 *     total_cost = Σᵗ (                                  // 逐步累加
 *       compute_speed_reward(...)           // ⓪ 速度奖励 (负代价)
 *     + compute_goal_distance_cost(...)     // ① 目标渐进吸引
 *     + compute_costmap_collision_cost(...) // ② 碰撞/膨胀/未知代价
 *     + compute_path_attraction_cost(...)   // ③ Cross-track error
 *     + compute_heading_alignment_cost(...) // ④ 朝向对齐
 *     + compute_path_length_cost(...)       // ⑤ 路径长度
 *     )
 *     + compute_terminal_distance_cost(...) // ⑥ 终端距离
 *     + compute_terminal_heading_cost(...)  // ⑦ 终端朝向
 */

#include <cuda_runtime.h>
#include <cfloat>

#include "mppi_gpu_rewards.cuh"

// ═══════════════════════════════════════════════════════════════════════════
// 常量定义
// ═══════════════════════════════════════════════════════════════════════════

/** @brief 终端距离代价权重 — 惩罚轨迹终点离目标太远 */
static const float TERMINAL_DIST_WEIGHT = 1.0f;

/** @brief 路径长度代价权重 — 防止绕远路 */
static const float PATH_LEN_WEIGHT = 0.02f;

/** @brief 目标渐进吸引的基础权重 (在核函数内与 progress 组合) */
static const float PATH_COST_WEIGHT = 0.2f;

/** @brief 末端角速度阻尼距离阈值 (m) — 靠近目标时降低 omega */
static const float OMEGA_DAMP_DIST = 1.5f;

/** @brief 末端角速度阻尼下限 — omega 最多保留此比例 */
static const float OMEGA_DAMP_FLOOR = 0.06f;

/** @brief 平滑到达阻尼半径 (m) — 在目标附近平滑减速 */
static const float GOAL_SOFT_RADIUS = 0.4f;

/** @brief 路径吸引时间递增因子 — 后期更强约束回路径 */
static const float PATH_FOLLOW_SCALE_INCREMENT = 1.2f;

/** @brief 噪声衰减下限 — 即使到最后一步也保留 15% 噪声 */
static const float NOISE_SCALE_FLOOR = 0.15f;

/** @brief 保底速度比例 — 即使 base 序列归零，采样也不退化 */
static const float BASE_SPEED_FLOOR_RATIO = 0.18f;

// ═══════════════════════════════════════════════════════════════════════════
// 内核 1: MPPI 轨迹采样与代价计算
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief MPPI 采样与代价计算内核 — 每个 CUDA 线程独立处理一条轨迹
 *
 * 网格映射: 一维 grid，每个 block 的每个 thread 处理一条完整轨迹
 *   global_thread_id = blockIdx.x * blockDim.x + threadIdx.x
 *   → 对应第 s 条采样轨迹 (s ∈ [0, num_samples))
 *
 * 每条轨迹的处理流程:
 *
 * ┌─────────────────────────────────────────────────────────────┐
 * │ 初始化: 计算路径方向在机器人坐标系下的投影                 │
 * ├─────────────────────────────────────────────────────────────┤
 * │ for t = 0 .. horizon-1:                                    │
 * │   ├─ 计算时变噪声缩放 (noise_decay)                        │
 * │   ├─ 计算时变路径吸引权重                                   │
 * │   ├─ 采样控制量 (base + 噪声 + guidance 混合, 含阻尼)      │
 * │   ├─ RK2 运动学积分 → 新位置 (x, y, θ)                    │
 * │   ├─ 存储实际控制量与轨迹位置                               │
 * │   ├─ 调用 compute_speed_reward(...)          → 累加 ⓪     │
 * │   ├─ 调用 compute_goal_distance_cost(...)     → 累加 ①     │
 * │   ├─ 计算 traj_to_path_sq, corridor_trust                  │
 * │   ├─ 调用 compute_trail_confidence(...)                     │
 * │   ├─ 调用 compute_costmap_collision_cost(...) → 累加 ②     │
 * │   ├─ 调用 compute_path_attraction_cost(...)   → 累加 ③     │
 * │   ├─ 调用 compute_heading_alignment_cost(...) → 累加 ④     │
 * │   └─ 调用 compute_path_length_cost(...)       → 累加 ⑤     │
 * ├─────────────────────────────────────────────────────────────┤
 * │ 终端代价:                                                   │
 * │   ├─ compute_terminal_distance_cost(...)      → 累加 ⑥     │
 * │   └─ compute_terminal_heading_cost(...)       → 累加 ⑦     │
 * └─────────────────────────────────────────────────────────────┘
 *
 * @note 控制量采样策略:
 *   以上一帧最优控制序列 (base) 为采样中心，在控制空间加高斯噪声。
 *   路径方向仅作为软引导 (guidance)，不再替代采样中心。
 *
 *   guidance_weight γ ∈ [0, 1]:
 *     γ → 0: 完全信任 base + 噪声 (时序最平滑，帧间一致)
 *     γ → 1: 完全锚定路径方向 (退化为旧行为，帧间离散跳变)
 *     建议值: 0.2 ~ 0.4
 */
__global__ void mppi_sample_kernel(
    // ── 预生成的噪声序列 (控制空间: m/s, rad/s) ──
    const float* __restrict__ noise_vx,
    const float* __restrict__ noise_vy,
    const float* __restrict__ noise_w,

    // ── 上一帧最优控制序列 (采样中心) ──
    const float* __restrict__ base_vx,
    const float* __restrict__ base_vy,
    const float* __restrict__ base_w,

    // ── 机器人当前状态 ──
    float current_x, float current_y, float current_theta,

    // ── 前瞻目标点 ──
    float target_x, float target_y,

    // ── 代价地图 ──
    const unsigned char* __restrict__ costmap,
    int costmap_w, int costmap_h,
    float costmap_res, float costmap_origin_x, float costmap_origin_y,

    // ── 控制参数 ──
    float dt, float min_v, float max_v, float max_vy, float max_w,

    // ── 代价权重 ──
    float costmap_weight,
    float speed_reward_weight,
    float heading_weight,

    // ── 路径引导参数 ──
    float path_dir_x, float path_dir_y,
    float guidance_weight,
    float cross_track_noise_scale,
    float noise_decay_rate,
    float lateral_guidance_scale,

    // ── 未知区域代价参数 ──
    float unknown_cost_rear,
    float unknown_cost_side,
    float unknown_cost_front,

    // ── 近期轨迹观测窗口数据 ──
    const float* __restrict__ trail_x,
    const float* __restrict__ trail_y,
    const float* __restrict__ trail_cos,
    const float* __restrict__ trail_sin,
    int trail_count,
    float trust_radius_sq,
    float fov_range_sq,
    float fov_cos_half,
    float observed_area_cost_scale,

    // ── 碰撞箱尺寸 ──
    float fp_front, float fp_back, float fp_left, float fp_right,

    // ── 全局路径数据 ──
    const float* __restrict__ path_x,
    const float* __restrict__ path_y,
    int num_path_pts,
    float path_attraction_weight,

    // ── 维度信息 ──
    int num_samples, int horizon,

    // ── 输出 ──
    float* __restrict__ costs,           // [num_samples]: 每条轨迹的总代价
    float* __restrict__ sampled_vx,      // [num_samples × horizon]: 每步实际 vx
    float* __restrict__ sampled_vy,      // [num_samples × horizon]: 每步实际 vy
    float* __restrict__ sampled_w,       // [num_samples × horizon]: 每步实际 omega
    float* __restrict__ traj_x,          // [num_samples × horizon]: 轨迹点 x
    float* __restrict__ traj_y)          // [num_samples × horizon]: 轨迹点 y
{
  // ── 线程 ID → 样本索引 ──
  int s = blockIdx.x * blockDim.x + threadIdx.x;
  if (s >= num_samples) return;

  // ════════════════════════════════════════════════════════════════
  // 阶段 1: 初始化 — 路径方向坐标变换
  // ════════════════════════════════════════════════════════════════

  // 将世界坐标系下的路径方向旋转到机器人坐标系
  // R(-θ) · [path_dir_x, path_dir_y]^T
  float cos_rot = cosf(-current_theta);
  float sin_rot = sinf(-current_theta);
  float path_vx_robot = path_dir_x * cos_rot - path_dir_y * sin_rot;
  float path_vy_robot = path_dir_x * sin_rot + path_dir_y * cos_rot;

  // 路径方向与机器人朝向的夹角 — 用于 omega guidance
  float path_angle_error = atan2f(path_vy_robot, path_vx_robot);

  // ── 轨迹初始状态 ──
  float x = current_x;
  float y = current_y;
  float theta = current_theta;

  // ── 代价累加器 ──
  float cost = 0.0f;

  // ── 上一位置 (用于路径长度代价) ──
  float prev_x = x, prev_y = y;

  // ════════════════════════════════════════════════════════════════
  // 阶段 2: 逐步前向预测
  // ════════════════════════════════════════════════════════════════
  for (int t = 0; t < horizon; ++t) {
    int idx = s * horizon + t;  // 全局索引: (样本, 时步)

    // ── 2.1 读取当前步的 base 控制量 ──
    float base_vx_t = base_vx[t];
    float base_vy_t = base_vy[t];
    float base_w_t = base_w[t];

    // 保底速度幅值: 即使 base 序列归零，也有基于 max_v 的最低速度
    // 防止初始帧或 base 塌缩时采样完全退化
    float base_speed = hypotf(base_vx_t, base_vy_t);
    float base_speed_clamped = fmaxf(base_speed, BASE_SPEED_FLOOR_RATIO * max_v);

    // ── 2.2 时变噪声缩放 ──
    // noise_scale(t) = 1 - decay_rate · (t / (H-1))
    // 前期: scale≈1.0 (充分探索), 后期: scale→0.15 (跟随 base)
    float progress_t = static_cast<float>(t) / fmaxf(1.0f, static_cast<float>(horizon - 1));
    float noise_scale_t = 1.0f - noise_decay_rate * progress_t;
    noise_scale_t = fmaxf(NOISE_SCALE_FLOOR, noise_scale_t);

    // ── 2.3 时变路径吸引权重 ──
    // path_attract(t) = w_path_attract · (1 + progress_t · 1.2)
    // 后期更强制约轨迹回到路径上
    float path_follow_scale = 1.0f + progress_t * PATH_FOLLOW_SCALE_INCREMENT;
    float path_attract_t = path_attraction_weight * path_follow_scale;

    // ════════════════════════════════════════════════════════════
    // 2.4 控制量采样: base + 噪声 (主体) ⊕ path_dir × speed (软引导)
    // ════════════════════════════════════════════════════════════

    float noise_vx_s = noise_vx[idx] * noise_scale_t;
    float noise_vy_s = noise_vy[idx] * noise_scale_t;
    float noise_w_s  = noise_w[idx] * noise_scale_t;

    // vx: (1-γ)·(base_vx + noise) + γ·(path_dir_vx · speed)
    float vx = (1.0f - guidance_weight) * (base_vx_t + noise_vx_s)
             + guidance_weight * path_vx_robot * base_speed_clamped;

    // vy: (1-γ)·(base_vy + noise·cross_track_scale) + γ·(path_dir_vy · speed · lateral_scale)
    //     横向受 lateral_guidance_scale 和 cross_track_noise_scale 双重抑制
    float vy = (1.0f - guidance_weight) *
                   (base_vy_t + noise_vy_s * cross_track_noise_scale)
             + guidance_weight * path_vy_robot * base_speed_clamped
                   * lateral_guidance_scale;

    // omega: base + noise + 弱路径朝向修正 (仅在 guidance 较强时生效)
    float omega = base_w_t + noise_w_s
                + path_angle_error * (0.5f / dt) * guidance_weight;

    // ── 控制量钳制 ──
    vx    = fminf(max_v,  fmaxf(min_v,   vx));
    vy    = fminf(max_vy, fmaxf(-max_vy, vy));
    omega = fminf(max_w,  fmaxf(-max_w,  omega));

    // ── 2.5 末端角速度阻尼 ──
    // 靠近目标时降低 omega，防止在终点附近旋转振荡
    float dist_to_target = sqrtf(
        (target_x - x) * (target_x - x) + (target_y - y) * (target_y - y));
    if (dist_to_target < OMEGA_DAMP_DIST) {
      float damp = dist_to_target / OMEGA_DAMP_DIST;
      damp = fmaxf(OMEGA_DAMP_FLOOR, damp);
      omega *= damp;
    }

    // ── 2.6 平滑目标到达阻尼 ──
    // 替换硬截断 (GOAL_REACHED_DIST=0.25m break):
    // 在目标 0.4m 内平滑降低控制量→0，sqrt 曲线保证减速平缓 (ease-out)
    if (dist_to_target < GOAL_SOFT_RADIUS) {
      float arrival = dist_to_target / GOAL_SOFT_RADIUS;
      arrival = sqrtf(arrival);
      vx    *= arrival;
      vy    *= arrival;
      omega *= arrival;
    }

    // ── 2.7 存储实际控制量 ──
    sampled_vx[idx] = vx;
    sampled_vy[idx] = vy;
    sampled_w[idx]  = omega;

    // ════════════════════════════════════════════════════════════
    // 2.8 中点法 (RK2) 运动学积分
    // ════════════════════════════════════════════════════════════
    // 欧拉法用步长起点的朝向计算整步位移，在大 ω 或 vy 下
    // 会产生抛物线式累积误差 ("甩尾"). 中点法先推进半步得到
    // 中间朝向 θ_mid，再用 θ_mid 计算整步的 x/y 位移，二阶精度.
    //
    // 半步:
    //   dx1 = vx·cos(θ) - vy·sin(θ)
    //   dy1 = vx·sin(θ) + vy·cos(θ)
    //   θ_mid = θ + ω · dt/2
    // 整步 (用 θ_mid):
    //   dx2 = vx·cos(θ_mid) - vy·sin(θ_mid)
    //   dy2 = vx·sin(θ_mid) + vy·cos(θ_mid)
    //   x_new = x + dx2·dt,  y_new = y + dy2·dt,  θ_new = θ + ω·dt

    float dtheta1 = omega;
    float half_dt = 0.5f * dt;
    float theta_mid = theta + dtheta1 * half_dt;

    float dx2 = vx * cosf(theta_mid) - vy * sinf(theta_mid);
    float dy2 = vx * sinf(theta_mid) + vy * cosf(theta_mid);

    float new_x = x + dx2 * dt;
    float new_y = y + dy2 * dt;
    float new_theta = theta + omega * dt;

    x = new_x;
    y = new_y;
    theta = new_theta;

    // 存储轨迹位置 (用于可视化和调试)
    if (traj_x != nullptr && traj_y != nullptr) {
      traj_x[idx] = x;
      traj_y[idx] = y;
    }

    // ════════════════════════════════════════════════════════════
    // 2.9 代价计算 — 调用各奖励/惩罚函数并累加
    // ════════════════════════════════════════════════════════════

    // ⓪ 速度奖励: 鼓励沿路径方向快速前进 (负代价 = 奖励)
    cost += compute_speed_reward(
        vx, vy, path_vx_robot, path_vy_robot,
        speed_reward_weight, horizon);

    // ① 目标渐进吸引: 越靠近终点、越后期，代价越高
    cost += compute_goal_distance_cost(
        x, y, target_x, target_y,
        t, horizon, PATH_COST_WEIGHT);

    // ── 计算轨迹点到全局路径的最短距离 (一次计算，三处复用) ──
    //   • corridor_trust: 路径信任走廊系数
    //   • path_attraction_cost: 全局路径吸引代价
    float traj_to_path_sq = compute_min_path_distance_sq(
        x, y, path_x, path_y, num_path_pts);

    // ── 路径信任走廊: 平滑衡量轨迹点在路径附近的可信度 ──
    float corridor_trust = compute_corridor_trust(
        traj_to_path_sq, fp_left, fp_right);

    // ── 近期轨迹观测置信度: 此区域是否刚被观测/经过 ──
    float trail_confidence = compute_trail_confidence(
        x, y,
        trail_x, trail_y, trail_cos, trail_sin,
        trail_count,
        trust_radius_sq, fov_range_sq, fov_cos_half);

    // ② 代价地图碰撞/膨胀/未知区域代价
    cost += compute_costmap_collision_cost(
        x, y, cosf(theta), sinf(theta),
        costmap, costmap_w, costmap_h,
        costmap_res, costmap_origin_x, costmap_origin_y,
        costmap_weight, horizon,
        fp_front, fp_back, fp_left, fp_right,
        unknown_cost_rear, unknown_cost_side, unknown_cost_front,
        corridor_trust, trail_confidence, observed_area_cost_scale);

    // ③ 全局路径吸引: Cross-track error 惩罚 (渐进增强)
    if (num_path_pts >= 2) {
      cost += compute_path_attraction_cost(traj_to_path_sq, path_attract_t);
    }

    // ④ 朝向对齐: 鼓励机器人面朝行进方向
    cost += compute_heading_alignment_cost(vx, vy, heading_weight, horizon);

    // ⑤ 路径长度: 防止绕远路
    cost += compute_path_length_cost(x, y, prev_x, prev_y, PATH_LEN_WEIGHT);

    prev_x = x;
    prev_y = y;
  }

  // ════════════════════════════════════════════════════════════════
  // 阶段 3: 终端代价
  // ════════════════════════════════════════════════════════════════

  // ⑥ 终端距离代价: 轨迹终点到目标点的剩余距离
  cost += compute_terminal_distance_cost(
      x, y, target_x, target_y, TERMINAL_DIST_WEIGHT);

  // ⑦ 终端朝向对齐代价: 鼓励轨迹终点朝向目标
  cost += compute_terminal_heading_cost(
      x, y, theta, target_x, target_y);

  // ── 写入总代价 ──
  costs[s] = cost;
}

// ═══════════════════════════════════════════════════════════════════════════
// 内核 2: 全时域加权求和
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief MPPI 全时域加权求和内核 — 对每个 timestep 独立计算最优控制量
 *
 * 网格映射: 2D grid
 *   gridDim.x → 覆盖 num_samples 个样本
 *   gridDim.y → 覆盖 horizon 个时步
 *
 * 对每个 timestep t，计算:
 *   weight_k = exp(-(cost_k - min_cost) / lambda)     // 指数加权
 *   u*_t = Σ_k weight_k · sampled_u[k,t] / Σ_k weight_k
 *
 * 这是 MPPI 的核心更新公式: 代价越低的轨迹权重越大，
 * 最终控制量是全部采样在各 timestep 的加权平均。
 *
 * result_seq 布局 (每 timestep 4 个 float):
 *   [vx_0, vy_0, w_0, sum_w_0, vx_1, vy_1, w_1, sum_w_1, ...]
 *
 * 使用 atomicAdd 确保多线程安全累加。
 */
__global__ void mppi_weighted_sum_kernel(
    const float* __restrict__ costs,          // [num_samples]: 每条轨迹代价
    const float* __restrict__ sampled_vx,     // [num_samples × horizon]
    const float* __restrict__ sampled_vy,     // [num_samples × horizon]
    const float* __restrict__ sampled_w,      // [num_samples × horizon]
    float* __restrict__ result_seq,           // [horizon × 4]: 加权结果
    float min_cost,                            // 最小代价 (数值稳定性)
    float lambda,                              // 温度参数 (>0, 越小越贪婪)
    int num_samples,
    int horizon)
{
  int s = blockIdx.x * blockDim.x + threadIdx.x;  // 样本索引
  int t = blockIdx.y;                               // 时步索引

  if (s >= num_samples || t >= horizon) return;

  int idx = s * horizon + t;

  // 指数权重: w_k = exp(-(cost_k - min_cost) / lambda)
  // 减去 min_cost 防止 exp 下溢
  float weight = expf(-(costs[s] - min_cost) / lambda);

  // result_seq 布局: [vx_0, vy_0, w_0, sum_w_0, vx_1, ...]
  int base = t * 4;

  // atomicAdd: 多线程安全累加 (多个样本的同一时步可能并发写入)
  atomicAdd(&result_seq[base + 0], weight * sampled_vx[idx]);
  atomicAdd(&result_seq[base + 1], weight * sampled_vy[idx]);
  atomicAdd(&result_seq[base + 2], weight * sampled_w[idx]);
  atomicAdd(&result_seq[base + 3], weight);
}

// ═══════════════════════════════════════════════════════════════════════════
// Host 端包装函数 (extern "C" — 供 C++ 代码调用)
// ═══════════════════════════════════════════════════════════════════════════

extern "C" {

/**
 * @brief Host 端包装: 上传数据到 GPU 并启动 mppi_sample_kernel
 *
 * 执行步骤:
 *   1. 异步拷贝噪声、base 控制序列、代价地图到 GPU
 *   2. 异步拷贝近期轨迹点 (观测窗口) 到 GPU
 *   3. 异步拷贝全局路径点到 GPU
 *   4. 启动采样内核 (一维 grid)
 *
 * @return 0 = 成功, 非零 = cudaMemcpyAsync 或内核启动失败的错误码
 */
int mppi_gpu_sample_and_cost(
    // ── Host 端输入数据 ──
    const float* noise_vx, const float* noise_vy, const float* noise_w,
    const float* base_vx, const float* base_vy, const float* base_w,
    float current_x, float current_y, float current_theta,
    float target_x, float target_y,
    const unsigned char* costmap,
    int costmap_w, int costmap_h,
    float costmap_res, float costmap_origin_x, float costmap_origin_y,
    float dt, float min_v, float max_v, float max_vy, float max_w,
    float costmap_weight,
    float path_dir_x, float path_dir_y,
    float guidance_weight,
    float cross_track_noise_scale,
    float noise_decay_rate,
    float vel_direction_weight,
    float speed_reward_weight,
    float heading_weight,
    float lateral_guidance_scale,
    float unknown_cost_rear,
    float unknown_cost_side,
    float unknown_cost_front,
    const float* trail_x, const float* trail_y,
    const float* trail_cos, const float* trail_sin,
    int trail_count,
    float trust_radius_sq,
    float fov_range_sq,
    float fov_cos_half,
    float observed_area_cost_scale,
    float fp_front, float fp_back, float fp_left, float fp_right,
    const float* path_x, const float* path_y,
    int num_path_pts,
    float path_attraction_weight,
    int num_samples, int horizon,

    // ── GPU 端缓冲区 (已预分配) ──
    float* d_noise_vx, float* d_noise_vy, float* d_noise_w,
    float* d_base_vx, float* d_base_vy, float* d_base_w,
    unsigned char* d_costmap,
    float* d_path_x, float* d_path_y,
    float* d_trail_x_, float* d_trail_y_,
    float* d_trail_cos_, float* d_trail_sin_,
    float* d_costs, float* d_sampled_vx, float* d_sampled_vy, float* d_sampled_w,
    float* d_traj_x, float* d_traj_y,
    cudaStream_t stream)
{
  size_t noise_bytes = num_samples * horizon * sizeof(float);
  size_t base_bytes = horizon * sizeof(float);
  size_t costmap_bytes = costmap_w * costmap_h * sizeof(unsigned char);

  cudaError_t err;

  // ── 上传噪声序列 ──
  err = cudaMemcpyAsync(d_noise_vx, noise_vx, noise_bytes, cudaMemcpyHostToDevice, stream);
  if (err != cudaSuccess) return 1;
  err = cudaMemcpyAsync(d_noise_vy, noise_vy, noise_bytes, cudaMemcpyHostToDevice, stream);
  if (err != cudaSuccess) return 2;
  err = cudaMemcpyAsync(d_noise_w, noise_w, noise_bytes, cudaMemcpyHostToDevice, stream);
  if (err != cudaSuccess) return 3;

  // ── 上传 base 控制序列 ──
  err = cudaMemcpyAsync(d_base_vx, base_vx, base_bytes, cudaMemcpyHostToDevice, stream);
  if (err != cudaSuccess) return 4;
  err = cudaMemcpyAsync(d_base_vy, base_vy, base_bytes, cudaMemcpyHostToDevice, stream);
  if (err != cudaSuccess) return 5;
  err = cudaMemcpyAsync(d_base_w, base_w, base_bytes, cudaMemcpyHostToDevice, stream);
  if (err != cudaSuccess) return 6;

  // ── 上传代价地图 ──
  err = cudaMemcpyAsync(d_costmap, costmap, costmap_bytes, cudaMemcpyHostToDevice, stream);
  if (err != cudaSuccess) return 7;

  // ── 上传近期轨迹点 (观测窗口) ──
  if (trail_count > 0 && trail_x != nullptr && trail_y != nullptr) {
    size_t trail_bytes = trail_count * sizeof(float);
    err = cudaMemcpyAsync(d_trail_x_, trail_x, trail_bytes, cudaMemcpyHostToDevice, stream);
    if (err != cudaSuccess) return 11;
    err = cudaMemcpyAsync(d_trail_y_, trail_y, trail_bytes, cudaMemcpyHostToDevice, stream);
    if (err != cudaSuccess) return 12;
    err = cudaMemcpyAsync(d_trail_cos_, trail_cos, trail_bytes, cudaMemcpyHostToDevice, stream);
    if (err != cudaSuccess) return 13;
    err = cudaMemcpyAsync(d_trail_sin_, trail_sin, trail_bytes, cudaMemcpyHostToDevice, stream);
    if (err != cudaSuccess) return 14;
  }

  // ── 上传全局路径点 ──
  if (num_path_pts > 0 && path_x != nullptr && path_y != nullptr) {
    size_t path_bytes = num_path_pts * sizeof(float);
    err = cudaMemcpyAsync(d_path_x, path_x, path_bytes, cudaMemcpyHostToDevice, stream);
    if (err != cudaSuccess) return 9;
    err = cudaMemcpyAsync(d_path_y, path_y, path_bytes, cudaMemcpyHostToDevice, stream);
    if (err != cudaSuccess) return 10;
  }

  // ── 启动采样内核 ──
  int threads_per_block = 256;
  int blocks = (num_samples + threads_per_block - 1) / threads_per_block;

  mppi_sample_kernel<<<blocks, threads_per_block, 0, stream>>>(
      d_noise_vx, d_noise_vy, d_noise_w,
      d_base_vx, d_base_vy, d_base_w,
      current_x, current_y, current_theta,
      target_x, target_y,
      d_costmap,
      costmap_w, costmap_h,
      costmap_res, costmap_origin_x, costmap_origin_y,
      dt, min_v, max_v, max_vy, max_w,
      costmap_weight,
      speed_reward_weight,
      heading_weight,
      path_dir_x, path_dir_y,
      guidance_weight,
      cross_track_noise_scale,
      noise_decay_rate,
      lateral_guidance_scale,
      unknown_cost_rear,
      unknown_cost_side,
      unknown_cost_front,
      d_trail_x_, d_trail_y_,
      d_trail_cos_, d_trail_sin_,
      trail_count,
      trust_radius_sq,
      fov_range_sq,
      fov_cos_half,
      observed_area_cost_scale,
      fp_front, fp_back, fp_left, fp_right,
      d_path_x, d_path_y,
      num_path_pts,
      path_attraction_weight,
      num_samples, horizon,
      d_costs, d_sampled_vx, d_sampled_vy, d_sampled_w,
      d_traj_x, d_traj_y);

  err = cudaGetLastError();
  if (err != cudaSuccess) return 8;

  return 0;
}

/**
 * @brief Host 端包装: 启动全时域加权求和内核
 *
 * 先清零 result_seq 缓冲区，然后启动 2D 内核。
 *
 * @return 0 = 成功, 非零 = cudaMemsetAsync 或内核启动失败的错误码
 */
int mppi_gpu_weighted_sum(
    const float* d_costs,
    const float* d_sampled_vx,
    const float* d_sampled_vy,
    const float* d_sampled_w,
    float* d_result_seq,
    float min_cost,
    float lambda,
    int num_samples,
    int horizon,
    cudaStream_t stream)
{
  // 清零结果缓冲区 (horizon × 4 个 float)
  cudaError_t err = cudaMemsetAsync(d_result_seq, 0,
                                     horizon * 4 * sizeof(float), stream);
  if (err != cudaSuccess) return 1;

  int threads_per_block = 256;
  int blocks_per_t = (num_samples + threads_per_block - 1) / threads_per_block;

  // 2D grid: dim3(blocks_per_t, horizon)
  dim3 grid(blocks_per_t, horizon);
  mppi_weighted_sum_kernel<<<grid, threads_per_block, 0, stream>>>(
      d_costs, d_sampled_vx, d_sampled_vy, d_sampled_w,
      d_result_seq,
      min_cost, lambda,
      num_samples, horizon);

  err = cudaGetLastError();
  if (err != cudaSuccess) return 2;

  return 0;
}

}  // extern "C"
