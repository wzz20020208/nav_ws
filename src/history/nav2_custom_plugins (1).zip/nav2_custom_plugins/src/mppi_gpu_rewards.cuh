#ifndef MPPI_GPU_REWARDS_CUH_
#define MPPI_GPU_REWARDS_CUH_

/**
 * @file mppi_gpu_rewards.cuh
 * @brief MPPI 代价函数 — 各奖励/惩罚项独立封装
 *
 * 本文件将 MPPI 轨迹代价函数的每一个奖励或惩罚项封装为独立的
 * __device__ 函数，每个函数包含：
 *   - 数学公式的详细推导
 *   - 参数含义说明
 *   - 返回值含义（正值为惩罚/代价，负值为奖励）
 *
 * 主核函数 mppi_sample_kernel 在每个预测步依次调用这些函数，
 * 累加得到该轨迹的总代价:
 *
 *   total_cost = Σᵗ ( speed_reward(t)           // ⓪ 负代价=奖励
 *                    + goal_distance_cost(t)      // ①
 *                    + costmap_collision_cost(t)  // ②
 *                    + path_attraction_cost(t)    // ③
 *                    + heading_alignment_cost(t)  // ④
 *                    + path_length_cost(t) )      // ⑤
 *              + terminal_distance_cost           // ⑤ 终端
 *              + terminal_heading_cost            // ⑥ 终端
 *
 * 设计原则:
 *   - 每项代价都除以 horizon (在核函数中统一处理)，确保不同
 *     horizon 长度的代价可比
 *   - 奖励项返回负值，惩罚项返回正值，总和越小越好
 *   - 每个函数尽量无副作用，参数显式传递
 */

#include "mppi_gpu_common.cuh"

// ═══════════════════════════════════════════════════════════════════════════
// ⓪ 沿路径方向速度奖励 (Speed Reward)
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief 计算沿路径方向的速度奖励（负代价 → 鼓励快速前进）
 *
 * 只奖励沿路径方向的速度分量，不奖励横向或后退运动。
 *
 * 公式:
 *   speed_along_path = vx · path_vx + vy · path_vy    // 点积, 投影到路径方向
 *   reward = -max(0, speed_along_path) · w_speed / H
 *
 * 性质:
 *   - speed_along_path > 0: 机器人沿路径方向前进 → 负代价(奖励)
 *   - speed_along_path ≤ 0: 后退或静止 → 零代价(不奖励)
 *   - 横向速度 vy 若与路径方向一致，也会获得部分奖励
 *
 * 为什么用 max(0, ·):
 *   不惩罚后退，只鼓励前进。后退在某些避障场景中可能是合理的。
 *
 * @param  vx                   机器人坐标系下的前向速度 (m/s)
 * @param  vy                   机器人坐标系下的横向速度 (m/s)
 * @param  path_vx_robot        路径方向在机器人坐标系下的 x 分量 (归一化向量)
 * @param  path_vy_robot        路径方向在机器人坐标系下的 y 分量 (归一化向量)
 * @param  speed_reward_weight  速度奖励权重 w_speed (≥0)
 * @param  horizon              预测时域步数 H
 * @return                      负值 = 奖励 (cost 减少), 零或正 = 无奖励
 */
__device__ inline float compute_speed_reward(
    float vx, float vy,
    float path_vx_robot, float path_vy_robot,
    float speed_reward_weight, int horizon)
{
  // 速度向量在路径方向上的投影（点积）
  float speed_along_path = vx * path_vx_robot + vy * path_vy_robot;

  // 只奖励正向分量: 奖励 = -max(0, speed_proj) · w / H
  return -fmaxf(0.0f, speed_along_path) * speed_reward_weight
         / static_cast<float>(horizon);
}

// ═══════════════════════════════════════════════════════════════════════════
// ① 目标点渐进吸引代价 (Goal Distance Cost)
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief 计算目标点渐进吸引代价 — 越靠近终点、越后期，代价越高
 *
 * 设计思路:
 *   前期 (t≈0): 允许轨迹偏离目标去绕障碍物
 *   后期 (t≈H): 强制轨迹逼近目标，确保最终到达
 *
 * 公式:
 *   progress = t / H                 // 归一化时间 ∈ [0, 1)
 *   cost = dist_to_goal · (1 - progress) · w_path
 *
 * 性质:
 *   - t=0:      cost = dist · 1.0 · w_path  (全额成本)
 *   - t=H-1:    cost = dist · (1/H) · w_path (几乎为零)
 *   - 使得早期步有探索自由，后期步被强约束
 *
 * @param  x, y            当前轨迹点的世界坐标 (m)
 * @param  target_x, target_y  前瞻目标点的世界坐标 (m)
 * @param  t                当前预测步索引 (0 ~ H-1)
 * @param  horizon          预测时域步数 H
 * @param  path_cost_weight 路径代价权重 w_path
 * @return                  正值 = 代价 (cost 增加)
 */
__device__ inline float compute_goal_distance_cost(
    float x, float y,
    float target_x, float target_y,
    int t, int horizon, float path_cost_weight)
{
  float dx = target_x - x;
  float dy = target_y - y;
  float dist = sqrtf(dx * dx + dy * dy);

  // 归一化进度: progress ∈ [0, 1)
  float progress = static_cast<float>(t) / static_cast<float>(horizon);

  // 代价 = dist · (1 - progress) · weight
  // 后期 progress→1, (1-progress)→0, 代价趋零 → 强制靠近目标
  return dist * (1.0f - progress) * path_cost_weight;
}

// ═══════════════════════════════════════════════════════════════════════════
// 路径信任走廊 (Path Trust Corridor) — 辅助函数
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief 计算路径信任走廊系数 — 平滑衡量轨迹点在路径附近的可信度
 *
 * 用于代价地图未知区域代价的折扣: 在路径走廊内的未知栅格更可能是
 * 可通行的（规划器已验证），应降低惩罚。
 *
 * 公式:
 *   hw = max(fp_left, fp_right) + 0.1         // 走廊半宽
 *   ratio = √(dist_to_path_sq) / hw            // 归一化偏移
 *   trust = 1 / (1 + ratio³ · 15)              // 立方衰减
 *
 * 衰减曲线:
 *   ratio = 0.0 (在路径上)  → trust = 1.00  (完全信任)
 *   ratio = 0.5              → trust = 0.65  (部分信任)
 *   ratio = 1.0 (走廊边界)  → trust = 0.06  (几乎不信任)
 *   ratio ≥ 1.5              → trust ≈ 0.02  (完全不信任)
 *
 * 为什么用 ratio³ · 15:
 *   - 立方 (ratio³):     边界附近快速衰减，中心区域缓变
 *   - 系数 15:            使 ratio=1 时 trust≈1/16≈0.06，边界惩罚足够强
 *
 * @param  traj_to_path_sq  轨迹点到最近路径段的最短距离平方 (m²)
 * @param  fp_left          机器人碰撞箱左半尺寸 (m)
 * @param  fp_right         机器人碰撞箱右半尺寸 (m)
 * @return                  corridor_trust ∈ [0, 1]
 *                          1.0 = 在路径中心, 信任未知区域
 *                          0.0 = 远离路径, 不信任未知区域
 */
__device__ inline float compute_corridor_trust(
    float traj_to_path_sq, float fp_left, float fp_right)
{
  // 走廊半宽 = 碰撞箱横向尺寸 + 0.1m 余量
  float path_trust_hw = fmaxf(fp_left, fp_right) + 0.1f;

  // 归一化偏移 = 实际距离 / 走廊半宽
  float corridor_ratio = sqrtf(traj_to_path_sq) / fmaxf(path_trust_hw, 0.01f);

  // 立方衰减: trust = 1 / (1 + ratio³ · 15)
  return 1.0f / (1.0f + corridor_ratio * corridor_ratio * corridor_ratio * 15.0f);
}

// ═══════════════════════════════════════════════════════════════════════════
// 近期轨迹置信度 (Trail Confidence) — 辅助函数
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief 计算近期轨迹观测置信度 — 轨迹点是否处于"曾被观测/经过"的区域
 *
 * 对每个近期轨迹点计算两种置信度，取最大值:
 *
 * ① 距离置信度 (Trust Radius):
 *    基于到历史轨迹点的欧氏距离二次衰减。
 *    公式: conf_dist = 1 - (dist² / trust_radius²)²
 *    性质: 中心=1.0 (恰好经过), 边界=0.0 (在信任半径边缘)
 *
 * ② 视锥置信度 (FOV Cone):
 *    基于传感器 FOV 视锥: 同时满足"在视野范围内"和"在有效距离内"。
 *    公式: conf_fov = ang_conf² · dist_conf
 *    其中:
 *      ang_conf  = (cos_angle - cos_half) / (1 - cos_half)  // 角度衰减 ∈[0,1]
 *      dist_conf = 1 - dist² / fov_range²                    // 距离衰减 ∈[0,1]
 *
 *    使用 cos_angle 而非 angle 的直接比较，因为 GPU 上 cos 运算更高效
 *    且可以优雅处理角度边界。
 *
 * @param  x, y              当前轨迹点的世界坐标 (m)
 * @param  trail_x, trail_y  近期轨迹点的世界坐标数组
 * @param  trail_cos, trail_sin  近期轨迹点的朝向 (cosθ, sinθ) 数组
 * @param  trail_count       近期轨迹点数量
 * @param  trust_radius_sq   信任半径的平方 (m²)，距轨迹点多近算"安全"
 * @param  fov_range_sq      传感器 FOV 有效距离的平方 (m²)
 * @param  fov_cos_half      传感器 FOV 半角的余弦值
 * @return                   trail_confidence ∈ [0, 1]
 *                           1.0 = 此区域刚刚被观测/经过, 高度可信
 *                           0.0 = 此区域未被观测过, 完全未知
 */
__device__ inline float compute_trail_confidence(
    float x, float y,
    const float* __restrict__ trail_x,
    const float* __restrict__ trail_y,
    const float* __restrict__ trail_cos,
    const float* __restrict__ trail_sin,
    int trail_count,
    float trust_radius_sq,
    float fov_range_sq,
    float fov_cos_half)
{
  float max_confidence = 0.0f;

  // 无轨迹数据 → 零置信度
  if (trail_count <= 0 || trail_x == nullptr || trail_y == nullptr) {
    return 0.0f;
  }

  for (int tr = 0; tr < trail_count; ++tr) {
    float tdx = x - trail_x[tr];
    float tdy = y - trail_y[tr];
    float dist_sq = tdx * tdx + tdy * tdy;

    // ══ ① 距离置信度: 到历史轨迹点的欧氏距离 ══
    // 二次衰减曲线: 中心 1.0 → 边界 0.0
    if (dist_sq < trust_radius_sq) {
      float ratio = dist_sq / trust_radius_sq;
      float conf = 1.0f - ratio * ratio;  // 1 - (d²/R²)² 的简化: 减 ratio²
      if (conf > max_confidence) max_confidence = conf;
    }

    // ══ ② 视锥置信度: 传感器 FOV 视锥内的连续置信度 ══
    // 要求: 在 FOV 距离内 + 在 FOV 角度内
    if (dist_sq < fov_range_sq && trail_cos != nullptr && trail_sin != nullptr) {
      float forward_dot = tdx * trail_cos[tr] + tdy * trail_sin[tr];

      // forward_dot > 0 表示轨迹点在历史朝向的前方半平面
      if (forward_dot > 0.0f) {
        float dist_f = sqrtf(dist_sq);

        // 角度置信度: cos_angle = dot / dist → [cos_half, 1] → [0, 1]
        float cos_angle = forward_dot / dist_f;
        float ang_conf = (cos_angle - fov_cos_half) / (1.0f - fov_cos_half);
        ang_conf = fmaxf(0.0f, ang_conf);

        // 距离置信度: [0, fov_range²] → [1, 0]
        float dist_conf = 1.0f - dist_sq / fov_range_sq;

        // 综合置信度 = ang_conf² · dist_conf
        // 角度平方使 FOV 中心权重更高，边缘衰减更快
        float conf = ang_conf * ang_conf * dist_conf;
        if (conf > max_confidence) max_confidence = conf;
      }
    }
  }

  return max_confidence;
}

// ═══════════════════════════════════════════════════════════════════════════
// ② 代价地图碰撞/膨胀惩罚 (Costmap Collision Cost)
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief 计算代价地图碰撞与膨胀代价 — MPPI 避障的核心安全约束
 *
 * 在机器人碰撞箱的 8 个特征点（前后左右 + 四角）处采样代价地图，
 * 综合计算三项代价:
 *
 * ╔═══════════════════════════════════════════════════════════════╗
 * ║ 子项 A: 最大已知障碍物代价 (Max Known Obstacle Cost)        ║
 * ║   取所有足迹点中已知部分 (≤254) 的最大值，平方归一化:       ║
 * ║     cost_known = (max_known / 255)² · w_costmap / H          ║
 * ║   平方使高代价栅格 (如 254) 的惩罚远大于低代价 (如 128)，   ║
 * ║   保证致命障碍物被强排斥。                                   ║
 * ╠═══════════════════════════════════════════════════════════════╣
 * ║ 子项 B: 各向异性势能场 (Anisotropic Potential Field)        ║
 * ║   机器人的宽边(前/后)遇到障碍物时产生更大的排斥力，推动     ║
 * ║   MPPI 选择"窄边面向障碍物"的朝向 (侧身通过窄缝)。         ║
 * ║     aspect = fp_front / max(fp_left, fp_right)  (>1 表示宽) ║
 * ║     dir_weight = 1 + wide_frac · (aspect - 1)               ║
 * ║     cost_aniso = Σ(known_i · dir_weight_i) / (255·8) · w·0.3/H║
 * ╠═══════════════════════════════════════════════════════════════╣
 * ║ 子项 C: 分方向未知区域代价 (Directional Unknown Penalty)    ║
 * ║   未知栅格 (>254) 按足迹点方向分为前/侧/后三类:             ║
 * ║     有效未知 = unknown_frac · (1 - corridor_trust)           ║
 * ║     cost_unknown = Σ_dir(effective_unknown_dir · w_dir) / 8   ║
 * ║                    · (1 - trail_confidence · (1-scale))       ║
 * ║                    · w_costmap / H                            ║
 * ║   走廊信任折扣: corridor_trust→1 (路径上) → 未知惩罚→0       ║
 * ║   观测折扣:     trail_confidence→1 (刚经过) → 惩罚按scale缩放║
 * ║   方向权重:     后方>侧方>前方 (机器人仅有前方视野)         ║
 * ╚═══════════════════════════════════════════════════════════════╝
 *
 * 已知/未知连续过渡:
 *   传统方法用二值阈值 (≥254=未知) 导致"悬崖效应":
 *     代价从 0 突然跳到 max，优化不连续。
 *   本函数用线性混合:
 *     unknown_frac = clamp((cell_val - 254), 0, 1)   // [0,1] 连续
 *     known_frac   = 1 - unknown_frac
 *   254 → unknown_frac=0, 已知; 255 → unknown_frac=1, 未知
 *   254.5 → unknown_frac=0.5, 半已知半未知 (平滑过渡)
 *
 * @param  x, y                  机器人中心的当前世界坐标 (m)
 * @param  cos_theta, sin_theta  机器人朝向的余弦/正弦
 * @param  costmap               代价地图数据指针
 * @param  costmap_w, costmap_h  代价地图尺寸
 * @param  costmap_res           代价地图分辨率 (m/cell)
 * @param  costmap_origin_x, costmap_origin_y  代价地图原点 (m)
 * @param  costmap_weight        代价地图总权重 w_costmap
 * @param  horizon               预测时域步数 H
 * @param  fp_front, fp_back, fp_left, fp_right  碰撞箱半尺寸 (m)
 * @param  unknown_cost_rear     后方未知区域权重 (如 1.0)
 * @param  unknown_cost_side     侧方未知区域权重 (如 0.7)
 * @param  unknown_cost_front    前方未知区域权重 (如 0.0, 前方有传感器)
 * @param  corridor_trust        路径信任系数 (由 compute_corridor_trust 计算)
 * @param  trail_confidence      观测置信度 (由 compute_trail_confidence 计算)
 * @param  observed_area_cost_scale  观测区域代价缩放 [0,1]
 * @return                       总代价地图代价 (正值 = 惩罚)
 */
__device__ float compute_costmap_collision_cost(
    float x, float y,
    float cos_theta, float sin_theta,
    const unsigned char* __restrict__ costmap,
    int costmap_w, int costmap_h,
    float costmap_res, float costmap_origin_x, float costmap_origin_y,
    float costmap_weight, int horizon,
    float fp_front, float fp_back, float fp_left, float fp_right,
    float unknown_cost_rear,
    float unknown_cost_side,
    float unknown_cost_front,
    float corridor_trust,
    float trail_confidence,
    float observed_area_cost_scale)
{
  // 无代价地图数据 → 零代价
  if (costmap == nullptr || costmap_w <= 0 || costmap_h <= 0) {
    return 0.0f;
  }

  // ══ 定义 8 个碰撞箱特征点 (机器人坐标系) ══
  // 顺序: 前, 前, 后, 后,  前, 后,  中,  中
  // 对应: 左, 右, 左, 右,  中, 中,  左,  右
  float fp_lx[8] = { fp_front,  fp_front, -fp_back,  -fp_back,
                      fp_front, -fp_back,  0.0f,      0.0f};
  float fp_ly[8] = { fp_left, -fp_right,  fp_left, -fp_right,
                      0.0f,     0.0f,     fp_left, -fp_right};

  // 宽/窄边比例: >1 表示宽边(前/后)比窄边(左/右)长
  float obs_aspect = fp_front / fmaxf(fmaxf(fp_left, fp_right), 0.01f);

  // ── 子项 A/B/C 的累加器 ──
  float max_known_cost = 0.0f;
  float directional_obs_cost = 0.0f;   // 各向异性势能场
  float unknown_rear_penalty = 0.0f;
  float unknown_side_penalty = 0.0f;
  float unknown_front_penalty = 0.0f;

  // ── 遍历 8 个足迹点 ──
  for (int fp = 0; fp < 8; ++fp) {
    // 将足迹点从机器人坐标系变换到世界坐标系
    float fp_wx = x + fp_lx[fp] * cos_theta - fp_ly[fp] * sin_theta;
    float fp_wy = y + fp_lx[fp] * sin_theta + fp_ly[fp] * cos_theta;

    // 双线性插值: 连续代价 [0, 255]
    float cell_val = costmap_bilinear(fp_wx, fp_wy, costmap,
                                      costmap_w, costmap_h,
                                      costmap_res, costmap_origin_x, costmap_origin_y);

    // 已知/未知连续分解:
    //   cell_val ∈ [0, 254]   → unknown_frac = 0,     全部已知
    //   cell_val ∈ (254, 255] → unknown_frac ∈ (0, 1], 部分或全部未知
    //   cell_val = 255         → unknown_frac = 1,     完全未知
    float unknown_frac_raw = fmaxf(0.0f, (cell_val - 254.0f));
    float known_frac = 1.0f - unknown_frac_raw;

    // ── 子项 A: 最大已知障碍物代价 ──
    float effective_known = cell_val * known_frac;
    if (effective_known > max_known_cost) {
      max_known_cost = effective_known;
    }

    // ── 子项 B: 各向异性势能场 ──
    // 仅在宽边显著长于窄边时生效 (aspect > 1.05)
    if (effective_known > 0.0f && obs_aspect > 1.05f) {
      float abs_lx = fabsf(fp_lx[fp]);
      float abs_ly = fabsf(fp_ly[fp]);
      float total_ext = abs_lx + abs_ly + 1e-6f;

      // wide_frac: 足迹点在宽边(前/后)方向上的分量比例
      //   1.0 = 纯宽边方向 (前方正中央)
      //   0.0 = 纯窄边方向 (正左侧/正右侧)
      float wide_frac = abs_lx / total_ext;

      // 方向权重: 宽边权重更大，障碍物在宽边产生更大排斥
      float dir_weight = 1.0f + wide_frac * (obs_aspect - 1.0f);
      directional_obs_cost += effective_known * dir_weight;
    }

    // ── 子项 C: 分方向未知区域代价 ──
    // 未知分量经走廊信任折扣: 走廊内未知→可通行→低惩罚
    float effective_unknown = unknown_frac_raw * (1.0f - corridor_trust);

    if (effective_unknown > 0.001f) {
      // 按足迹点的前后方向分类
      if (fp_lx[fp] > 0.01f) {
        // 前方: 机器人传感器可观测，权重最低
        unknown_front_penalty += effective_unknown;
      } else if (fp_lx[fp] < -0.01f) {
        // 后方: 机器人完全看不到，权重最高
        unknown_rear_penalty += effective_unknown;
      } else {
        // 侧方: 介于两者之间
        unknown_side_penalty += effective_unknown;
      }
    }
  }

  // ══ 汇总代价地图代价 ══
  float total_costmap_cost = 0.0f;

  // ── 子项 A: 已知障碍物代价 (平方归一化) ──
  // norm = (max_known / 255)² → [0, 1]
  // 平方使 254/255≈0.996²≈0.992 的惩罚远大于 128/255≈0.5²≈0.25
  // 保留对高代价栅格的梯度敏感性
  if (max_known_cost > 0.0f) {
    float norm = max_known_cost / 255.0f;
    total_costmap_cost += (norm * norm * costmap_weight) / static_cast<float>(horizon);
  }

  // ── 子项 B: 各向异性势能场代价 ──
  // 归一化: 除以 (255 * 8) 因为最多 8 个点各 255 代价
  // 缩放 0.3: 使此项为已知代价的补充而非主导
  if (directional_obs_cost > 0.0f) {
    float dir_norm = directional_obs_cost / (255.0f * 8.0f);
    total_costmap_cost += (dir_norm * costmap_weight * 0.3f) / static_cast<float>(horizon);
  }

  // ── 子项 C: 分方向未知区域代价 ──
  const float UNKNOWN_NORMALIZER = 1.0f / 8.0f;  // 平均每个足迹点

  // 按方向的加权和
  float unknown_total =
      unknown_rear_penalty  * unknown_cost_rear  +
      unknown_side_penalty  * unknown_cost_side  +
      unknown_front_penalty * unknown_cost_front;

  // 观测窗口折扣: trail_confidence=1 → 折扣=observed_area_cost_scale
  //               trail_confidence=0 → 折扣=1.0 (全额惩罚)
  float obs_discount = 1.0f - trail_confidence * (1.0f - observed_area_cost_scale);
  unknown_total *= obs_discount;

  if (unknown_total > 0.0f) {
    total_costmap_cost += (unknown_total * UNKNOWN_NORMALIZER * costmap_weight)
                          / static_cast<float>(horizon);
  }

  return total_costmap_cost;
}

// ═══════════════════════════════════════════════════════════════════════════
// ③ 全局路径吸引代价 (Path Attraction / Cross-Track Error)
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief 计算全局路径吸引代价 — 惩罚偏离全局路径的轨迹
 *
 * 使用轨迹点到最近路径段的距离平方作为惩罚（已在核函数中预计算
 * traj_to_path_sq，此处仅做加权）。
 *
 * 公式:
 *   cost = traj_to_path_sq · path_attract_weight_t
 *
 * 其中 path_attract_weight_t 在核函数中随时间递增:
 *   path_attract_t = w_path_attract · (1 + progress · 1.2)
 *
 * 时间递增的设计意图:
 *   前期 (t≈0): 允许轨迹偏离路径绕开障碍物
 *   后期 (t≈H): 强约束轨迹回到路径上
 *
 * @param  traj_to_path_sq    轨迹点到最近路径段的最短距离平方 (m²)
 * @param  path_attract_t     当前时间步的路径吸引权重 (已含时间递增)
 * @return                    正值 = 代价 (cost 增加)
 */
__device__ inline float compute_path_attraction_cost(
    float traj_to_path_sq, float path_attract_t)
{
  // 代价 = 偏离距离² · 时间递增权重
  return traj_to_path_sq * path_attract_t;
}

// ═══════════════════════════════════════════════════════════════════════════
// ④ 朝向对齐代价 (Heading Alignment Cost)
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief 计算朝向对齐代价 — 鼓励机器人面朝行进方向
 *
 * 在机器人坐标系下，速度向量 (vx, vy) 与机头朝向 (x 轴) 的夹角
 * 即为行进方向与朝向的偏差。全向底盘可以侧移，但面朝行进方向
 * 通常更高效、传感器视野更好。
 *
 * 公式:
 *   travel_angle = atan2(vy, vx)     // 速度方向与机头朝向的夹角
 *   cost = |travel_angle| · w_heading / H
 *
 * 性质:
 *   - travel_angle = 0:   正前向行驶 → 无惩罚 ✓
 *   - travel_angle = ±π/2: 纯侧移 → 中等惩罚
 *   - travel_angle = ±π:   倒车 → 最大惩罚
 *
 * @param  vx, vy          机器人坐标系下的当前控制速度 (m/s)
 * @param  heading_weight  朝向对齐权重 w_heading
 * @param  horizon         预测时域步数 H
 * @return                 正值 = 代价 (cost 增加)
 */
__device__ inline float compute_heading_alignment_cost(
    float vx, float vy, float heading_weight, int horizon)
{
  // 速度方向与机头朝向 (x轴正方向) 的夹角
  float travel_angle = atan2f(vy, vx);

  // 归一化到 [-π, π]
  travel_angle = normalize_angle(travel_angle);

  // 代价 = |偏离角度| · 权重 / H
  return fabsf(travel_angle) * heading_weight / static_cast<float>(horizon);
}

// ═══════════════════════════════════════════════════════════════════════════
// ⑤ 路径长度代价 (Path Length Penalty)
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief 计算路径长度代价 — 防止轨迹绕远路
 *
 * 每一步累加实际走过的欧氏距离，惩罚绕路行为。
 *
 * 公式:
 *   step_len = √((x - x_prev)² + (y - y_prev)²)
 *   cost = step_len · w_len
 *
 * 作用:
 *   在多个候选轨迹代价相当时，选择路径更短（更直接）的那条，
 *   避免不必要的迂回。
 *
 * @param  x, y           当前轨迹点的世界坐标 (m)
 * @param  prev_x, prev_y 上一轨迹点的世界坐标 (m)
 * @param  len_weight     路径长度权重 w_len
 * @return                正值 = 代价 (cost 增加)
 */
__device__ inline float compute_path_length_cost(
    float x, float y, float prev_x, float prev_y, float len_weight)
{
  float step_dx = x - prev_x;
  float step_dy = y - prev_y;
  return sqrtf(step_dx * step_dx + step_dy * step_dy) * len_weight;
}

// ═══════════════════════════════════════════════════════════════════════════
// ⑥ 终端距离代价 (Terminal Distance Cost)
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief 计算终端距离代价 — 轨迹终点到目标点的距离惩罚
 *
 * 在预测时域结束后，对轨迹终点与目标点的剩余距离施加一次性惩罚。
 * 这是 MPPI 标准做法: 终端代价确保优化不会选择"在时域内看起来便宜
 * 但最终离目标很远"的短视轨迹。
 *
 * 公式:
 *   dist_to_goal = √((target_x - x_final)² + (target_y - y_final)²)
 *   cost = dist_to_goal · w_terminal_dist
 *
 * @param  x_final, y_final      轨迹终点的世界坐标 (m)
 * @param  target_x, target_y    前瞻目标点的世界坐标 (m)
 * @param  terminal_dist_weight  终端距离权重 w_terminal_dist
 * @return                       正值 = 代价 (cost 增加)
 */
__device__ inline float compute_terminal_distance_cost(
    float x_final, float y_final,
    float target_x, float target_y,
    float terminal_dist_weight)
{
  float dx = target_x - x_final;
  float dy = target_y - y_final;
  float dist_to_goal = sqrtf(dx * dx + dy * dy);
  return dist_to_goal * terminal_dist_weight;
}

// ═══════════════════════════════════════════════════════════════════════════
// ⑦ 终端朝向对齐代价 (Terminal Heading Alignment Cost)
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief 计算终端朝向对齐代价 — 鼓励轨迹终点朝向目标
 *
 * 距离目标越近，朝向对齐越重要。使用距离门控 (goal_proximity)
 * 在远处削弱此项，避免过早强制朝向影响避障。
 *
 * 公式:
 *   goal_proximity = 1 / (1 + dist_to_goal · 1.6)      // 距离门控
 *   heading_to_goal = atan2(y_goal - y, x_goal - x)     // 目标方向
 *   heading_err = heading_to_goal - theta_final          // 朝向偏差
 *   cost = |heading_err| · 0.8 · goal_proximity
 *
 * 距离门控曲线 (goal_proximity):
 *   d = 0.0m   → prox = 1.00   (最近, 朝向对齐最重要)
 *   d = 0.5m   → prox = 0.56
 *   d = 1.0m   → prox = 0.38
 *   d = 1.5m   → prox = 0.29
 *   d = 2.0m   → prox = 0.24   (较远, 朝向对齐不重要)
 *
 * 设计意图:
 *   平缓的衰减使 MPPI 在 1~2m 就开始考虑朝向对齐，
 *   而非等到终点附近才突然要求对准。
 *
 * @param  x_final, y_final  轨迹终点的世界坐标 (m)
 * @param  theta_final       轨迹终点的朝向 (rad)
 * @param  target_x, target_y  前瞻目标点的世界坐标 (m)
 * @return                   正值 = 代价 (cost 增加)
 */
__device__ inline float compute_terminal_heading_cost(
    float x_final, float y_final, float theta_final,
    float target_x, float target_y)
{
  float dx = target_x - x_final;
  float dy = target_y - y_final;
  float dist_to_goal = sqrtf(dx * dx + dy * dy);

  // 距离门控: 越近 → goal_proximity 越大 → 朝向对齐越重要
  float goal_proximity = 1.0f / (1.0f + dist_to_goal * 1.6f);

  // 目标方向
  float heading_to_goal = atan2f(dy, dx);

  // 朝向偏差
  float heading_err = heading_to_goal - theta_final;
  heading_err = normalize_angle(heading_err);

  // 终端朝向代价 = |偏差| · 0.8 · 门控系数
  return fabsf(heading_err) * 0.8f * goal_proximity;
}

// ═══════════════════════════════════════════════════════════════════════════
// 辅助: 计算轨迹点到全局路径的最短距离平方
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief 计算轨迹点到全局路径所有线段的最短距离平方
 *
 * 遍历路径段，对每个段调用 point_to_segment_dist_sq，取最小值。
 * 此值被 corridor_trust 和 path_attraction_cost 复用。
 *
 * @param  x, y             轨迹点世界坐标 (m)
 * @param  path_x, path_y   全局路径点坐标数组 (世界坐标, m)
 * @param  num_path_pts     路径点数量
 * @return                  到路径的最短距离平方 (m²)，无路径时返回 FLT_MAX
 */
__device__ inline float compute_min_path_distance_sq(
    float x, float y,
    const float* __restrict__ path_x,
    const float* __restrict__ path_y,
    int num_path_pts)
{
  float min_dist_sq = FLT_MAX;

  if (num_path_pts < 2 || path_x == nullptr || path_y == nullptr) {
    return min_dist_sq;
  }

  for (int p = 0; p < num_path_pts - 1; ++p) {
    float d_sq = point_to_segment_dist_sq(
        x, y, path_x[p], path_y[p], path_x[p + 1], path_y[p + 1]);
    if (d_sq < min_dist_sq) min_dist_sq = d_sq;
  }

  return min_dist_sq;
}

#endif  // MPPI_GPU_REWARDS_CUH_
