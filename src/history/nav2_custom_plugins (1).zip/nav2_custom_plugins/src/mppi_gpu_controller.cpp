#include "nav2_custom_plugins/mppi_gpu_controller.hpp"
#include <limits>
#include <cmath>
#include <algorithm>
#include <random>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <cuda_runtime.h>
#include "tf2/utils.h"

// CUDA host wrapper 函数声明（实现在 mppi_gpu_kernels.cu 中）
extern "C" {
int mppi_gpu_sample_and_cost(
    const float* noise_vx, const float* noise_vy, const float* noise_w,
    const float* base_vx, const float* base_vy, const float* base_w,
    float current_x, float current_y, float current_theta,
    float target_x, float target_y,
    const unsigned char* costmap,
    int costmap_w, int costmap_h,
    float costmap_res, float costmap_origin_x, float costmap_origin_y,
    float dt, float min_v, float max_v, float max_vy, float max_w,
    float costmap_weight,
    float path_dir_x, float path_dir_y,
    float guidance_weight,
    float cross_track_noise_scale,
    float noise_decay_rate,
    float vel_direction_weight,
    float speed_reward_weight,
    float heading_weight,
    float lateral_guidance_scale,
    float unknown_cost_rear,
    float unknown_cost_side,
    float unknown_cost_front,
    const float* trail_x, const float* trail_y,
    const float* trail_cos, const float* trail_sin,
    int trail_count,
    float trust_radius_sq,
    float fov_range_sq,
    float fov_cos_half,
    float observed_area_cost_scale,
    float fp_front, float fp_back, float fp_left, float fp_right,
    const float* path_x, const float* path_y,
    int num_path_pts,
    float path_attraction_weight,
    int num_samples, int horizon,
    float* d_noise_vx, float* d_noise_vy, float* d_noise_w,
    float* d_base_vx, float* d_base_vy, float* d_base_w,
    unsigned char* d_costmap,
    float* d_path_x, float* d_path_y,
    float* d_trail_x_, float* d_trail_y_,
    float* d_trail_cos_, float* d_trail_sin_,
    float* d_costs, float* d_sampled_vx, float* d_sampled_vy, float* d_sampled_w,
    float* d_traj_x, float* d_traj_y,
    cudaStream_t stream);

int mppi_gpu_weighted_sum(
    const float* d_costs,
    const float* d_sampled_vx, const float* d_sampled_vy, const float* d_sampled_w,
    float* d_result_seq,
    float min_cost,
    float lambda,
    int num_samples,
    int horizon,
    cudaStream_t stream);
}

// ── CUDA / ROS 参数封装宏，消除重复样板代码 ──

/// cudaMalloc + 自动错误检查（依赖上下文中的 node_）
#define CUDA_MALLOC_CHECK(ptr, size, name)                                          \
  do {                                                                              \
    cudaError_t err_ = cudaMalloc(&(ptr), (size));                                  \
    if (err_ != cudaSuccess) {                                                      \
      RCLCPP_ERROR(node_.lock()->get_logger(),                                      \
        "cudaMalloc(%s) 失败: %s", name, cudaGetErrorString(err_));                 \
    }                                                                               \
  } while (0)

/// cudaFree + 安全置空
#define CUDA_FREE_NULL(ptr)                                                         \
  do {                                                                              \
    cudaFree(ptr);                                                                  \
    (ptr) = nullptr;                                                                \
  } while (0)

/// declare_parameter + get_parameter 合并调用
#define DECLARE_GET_PARAM(node_ptr, prefix, name, var)                              \
  do {                                                                              \
    (node_ptr)->declare_parameter((prefix) + "." + (name), (var));                  \
    (node_ptr)->get_parameter((prefix) + "." + (name), (var));                      \
  } while (0)

namespace nav2_custom_plugins
{

void MPPIGPUController::allocateGPUBuffers()
{
  if (gpu_buffers_allocated_) {
    RCLCPP_WARN(node_.lock()->get_logger(), "GPU 缓冲区已分配，跳过重复分配");
    return;
  }

  int N = num_samples_;
  int H = prediction_horizon_;

  // N×H 噪声 & 轨迹缓冲区
  CUDA_MALLOC_CHECK(d_noise_vx_,   N * H * sizeof(float), "d_noise_vx");
  CUDA_MALLOC_CHECK(d_noise_vy_,   N * H * sizeof(float), "d_noise_vy");
  CUDA_MALLOC_CHECK(d_noise_w_,    N * H * sizeof(float), "d_noise_w");
  CUDA_MALLOC_CHECK(d_sampled_vx_, N * H * sizeof(float), "d_sampled_vx");
  CUDA_MALLOC_CHECK(d_sampled_vy_, N * H * sizeof(float), "d_sampled_vy");
  CUDA_MALLOC_CHECK(d_sampled_w_,  N * H * sizeof(float), "d_sampled_w");
  CUDA_MALLOC_CHECK(d_traj_x_,     N * H * sizeof(float), "d_traj_x");
  CUDA_MALLOC_CHECK(d_traj_y_,     N * H * sizeof(float), "d_traj_y");

  // H 维 base 序列
  CUDA_MALLOC_CHECK(d_base_vx_, H * sizeof(float), "d_base_vx");
  CUDA_MALLOC_CHECK(d_base_vy_, H * sizeof(float), "d_base_vy");
  CUDA_MALLOC_CHECK(d_base_w_,  H * sizeof(float), "d_base_w");

  // N 维代价 & H×4 加权结果
  CUDA_MALLOC_CHECK(d_costs_,      N * sizeof(float),       "d_costs");
  CUDA_MALLOC_CHECK(d_result_seq_, H * 4 * sizeof(float),   "d_result_seq");

  // 路径 & 轨迹缓存（固定最大点数）
  CUDA_MALLOC_CHECK(d_path_x_,    MAX_PATH_POINTS * sizeof(float), "d_path_x");
  CUDA_MALLOC_CHECK(d_path_y_,    MAX_PATH_POINTS * sizeof(float), "d_path_y");
  CUDA_MALLOC_CHECK(d_trail_x_,   MAX_TRAIL_POINTS * sizeof(float), "d_trail_x");
  CUDA_MALLOC_CHECK(d_trail_y_,   MAX_TRAIL_POINTS * sizeof(float), "d_trail_y");
  CUDA_MALLOC_CHECK(d_trail_cos_, MAX_TRAIL_POINTS * sizeof(float), "d_trail_cos");
  CUDA_MALLOC_CHECK(d_trail_sin_, MAX_TRAIL_POINTS * sizeof(float), "d_trail_sin");

  // costmap 显存按需分配
  d_costmap_ = nullptr;
  costmap_w_ = 0;
  costmap_h_ = 0;

  gpu_buffers_allocated_ = true;
}

void MPPIGPUController::freeGPUBuffers()
{
  if (!gpu_buffers_allocated_) return;

  CUDA_FREE_NULL(d_noise_vx_);
  CUDA_FREE_NULL(d_noise_vy_);
  CUDA_FREE_NULL(d_noise_w_);
  CUDA_FREE_NULL(d_base_vx_);
  CUDA_FREE_NULL(d_base_vy_);
  CUDA_FREE_NULL(d_base_w_);
  CUDA_FREE_NULL(d_costs_);
  CUDA_FREE_NULL(d_sampled_vx_);
  CUDA_FREE_NULL(d_sampled_vy_);
  CUDA_FREE_NULL(d_sampled_w_);
  CUDA_FREE_NULL(d_result_seq_);
  CUDA_FREE_NULL(d_traj_x_);
  CUDA_FREE_NULL(d_traj_y_);
  CUDA_FREE_NULL(d_path_x_);
  CUDA_FREE_NULL(d_path_y_);
  CUDA_FREE_NULL(d_trail_x_);
  CUDA_FREE_NULL(d_trail_y_);
  CUDA_FREE_NULL(d_trail_cos_);
  CUDA_FREE_NULL(d_trail_sin_);

  CUDA_FREE_NULL(d_costmap_);
  costmap_w_ = 0;
  costmap_h_ = 0;

  gpu_buffers_allocated_ = false;
}

void MPPIGPUController::configure(
  const rclcpp_lifecycle::LifecycleNode::WeakPtr & parent,
  std::string name,
  std::shared_ptr<tf2_ros::Buffer> tf,
  std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros)
{
  node_ = parent;
  plugin_name_ = name;
  tf_ = tf;
  costmap_ros_ = costmap_ros;

  auto node_ptr = node_.lock();

  // ── 声明并加载所有可配置参数 ──
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "path_attraction_weight",       path_attraction_weight_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "lookahead_time",               lookahead_time_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "min_lookahead_dist",           min_lookahead_dist_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "guidance_weight",              guidance_weight_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "cross_track_noise_scale",      cross_track_noise_scale_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "noise_decay_rate",             noise_decay_rate_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "vel_direction_weight",         vel_direction_weight_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "speed_reward_weight",          speed_reward_weight_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "heading_weight",               heading_weight_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "lateral_guidance_scale",       lateral_guidance_scale_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "ema_alpha",                    ema_alpha_);

  // 分方向未知区域代价权重：后方 > 侧方 > 前方（机器人只有前方视野）
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "unknown_cost_rear",            unknown_cost_rear_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "unknown_cost_side",            unknown_cost_side_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "unknown_cost_front",           unknown_cost_front_);

  // 观测窗口参数：近期经过的区域降低未知代价
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "observation_window_duration",  observation_window_duration_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "trust_radius",                 trust_radius_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "observed_area_cost_scale",     observed_area_cost_scale_);

  // 传感器 FOV 参数：可视区域也纳入观测窗口
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "fov_half_angle",               fov_half_angle_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "fov_range",                    fov_range_);

  // 碰撞箱尺寸
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "footprint_front",              footprint_front_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "footprint_back",               footprint_back_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "footprint_left",               footprint_left_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "footprint_right",              footprint_right_);

  // 终端角度对准：靠近目标时退化 MPPI 为纯角度追踪
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "terminal_angle_dist",          terminal_angle_dist_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "terminal_angle_kp",            terminal_angle_kp_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "terminal_angle_tolerance",     terminal_angle_tolerance_);

  // 前方障碍物 KP 速度控制
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "front_obstacle_kp_enabled",    front_obstacle_kp_enabled_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "front_obstacle_fov_deg",       front_obstacle_fov_deg_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "front_obstacle_safe_dist",     front_obstacle_safe_dist_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "front_obstacle_min_kp",        front_obstacle_min_kp_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "front_obstacle_max_range",     front_obstacle_max_range_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "front_obstacle_num_rays",      front_obstacle_num_rays_);

  // 回退允许距离
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "fallback_enable_dist",         fallback_enable_dist_);

  // 核心 MPPI 参数
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "num_samples",                  num_samples_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "prediction_horizon",           prediction_horizon_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "dt",                           dt_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "max_v",                        max_v_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "min_v",                        min_v_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "max_vy",                       max_vy_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "max_w",                        max_w_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "action_std_v",                 action_std_v_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "action_std_vy",                action_std_vy_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "action_std_w",                 action_std_w_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "lambda",                       lambda_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "collision_cost",               costmap_weight_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "enable_lateral_bias",          enable_lateral_bias_);

  // 全局代价地图订阅参数
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "use_global_costmap",           use_global_costmap_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "global_costmap_topic",         global_costmap_topic_);

  if (use_global_costmap_) {
    global_costmap_sub_ = node_ptr->create_subscription<nav_msgs::msg::OccupancyGrid>(
      global_costmap_topic_, rclcpp::SystemDefaultsQoS(),
      std::bind(&MPPIGPUController::globalCostmapCallback, this, std::placeholders::_1));
    RCLCPP_INFO(node_.lock()->get_logger(),
      "已订阅全局代价地图: %s", global_costmap_topic_.c_str());
  }

  // 统计数据采集参数
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "enable_stats",                 enable_stats_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "stats_file_path",              stats_file_path_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "mutation_thresh_vx",           mutation_thresh_vx_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "mutation_thresh_vy",           mutation_thresh_vy_);
  DECLARE_GET_PARAM(node_ptr, plugin_name_, "mutation_thresh_w",            mutation_thresh_w_);

  if (enable_stats_) {
    stats_start_time_ = node_ptr->now().seconds();
    RCLCPP_INFO(node_.lock()->get_logger(),
      "统计数据已启用，输出文件: %s", stats_file_path_.c_str());
  }

  vis_pub_ = node_ptr->create_publisher<visualization_msgs::msg::MarkerArray>(
    "/mppi_gpu_visualization", 10);

  optimal_vx_seq_.resize(prediction_horizon_, 0.0);
  optimal_vy_seq_.resize(prediction_horizon_, 0.0);
  optimal_omega_seq_.resize(prediction_horizon_, 0.0);

  std::random_device rd;
  generator_ = std::mt19937(rd());
  dist_vx_ = std::normal_distribution<>(0.0, action_std_v_);
  dist_vy_ = std::normal_distribution<>(0.0, action_std_vy_);
  dist_w_  = std::normal_distribution<>(0.0, action_std_w_);

  allocateGPUBuffers();

  RCLCPP_INFO(node_.lock()->get_logger(), "配置 MPPIGPUController (GPU加速) 成功！");
}

void MPPIGPUController::cleanup()
{
  RCLCPP_INFO(node_.lock()->get_logger(), "清理 MPPIGPUController");
  writeStatsToFile();
  freeGPUBuffers();
}

void MPPIGPUController::activate()
{
  RCLCPP_INFO(node_.lock()->get_logger(), "激活 MPPIGPUController");
  fallback_active_ = false;
  terminal_angle_active_ = false;
  fallback_prev_yaw_err_ = 0.0;
}

void MPPIGPUController::deactivate()
{
  RCLCPP_INFO(node_.lock()->get_logger(), "停用 MPPIGPUController");
}

void MPPIGPUController::globalCostmapCallback(const nav_msgs::msg::OccupancyGrid::SharedPtr msg)
{
  latest_global_costmap_ = msg;
}

void MPPIGPUController::setPlan(const nav_msgs::msg::Path & path)
{
  global_plan_ = path;
  // 新路径到达时重置回退/终端状态，给 MPPI 全新起点
  fallback_active_ = false;
  terminal_angle_active_ = false;
  fallback_prev_yaw_err_ = 0.0;
}

void MPPIGPUController::setSpeedLimit(const double &, const bool &)
{
}

geometry_msgs::msg::TwistStamped MPPIGPUController::computeVelocityCommands(
  const geometry_msgs::msg::PoseStamped & pose,
  const geometry_msgs::msg::Twist & /*current_vel*/,
  nav2_core::GoalChecker *)
{
  // ══════════════════════════════════════════════════════════════════
  // MPPI GPU 控制器 — 控制策略三层架构
  // ══════════════════════════════════════════════════════════════════
  //
  // 本控制器按"距目标远近"将控制分为三层，由远及近逐级退化：
  //
  // ┌──────────────────────────────────────────────────────────────┐
  // │ 层级 1: 正常 MPPI (dist_to_final > fallback_enable_dist_)    │
  // │   覆盖绝大部分路径。GPU 并行采样 N 条轨迹，全时域加权求和， │
  // │   输出平滑连续的控制序列。是保证运动质量的核心。             │
  // ├──────────────────────────────────────────────────────────────┤
  // │ 层级 2: 纯追踪回退 (terminal_angle_dist_ ~ fallback_enable_dist_)│
  // │   靠近目标时，若 MPPI 输出微弱 (<0.15)，退化到纯追踪。       │
  // │   omega 由"路径切线追踪"和"目标姿态对齐"混合，随距离渐进。  │
  // │   带迟滞状态机：进入需全低于 0.15，退出需连续 5 帧 >0.30。  │
  // ├──────────────────────────────────────────────────────────────┤
  // │ 层级 3: 终端角度对准 (dist_to_final < terminal_angle_dist_)  │
  // │   距离目标极近 (<0.10m)，跳过 GPU，纯 P 控制器对准 goal yaw。│
  // │   朝向到位后完全停止 (omega=0)。                              │
  // └──────────────────────────────────────────────────────────────┘
  //
  // 关键设计原则:
  //   - MPPI 是主力，应用于绝大部分路径保证平滑运动
  //   - 纯追踪是兜底，仅在最后阶段 + MPPI 失效时介入完成对准
  //   - 终端对准是终点，纯旋转对齐 goal pose 朝向
  //   - 远离目标时绝不回退，完全信任 MPPI
  // ══════════════════════════════════════════════════════════════════
  geometry_msgs::msg::TwistStamped cmd_vel;
  cmd_vel.header.frame_id = "BASE_LINK";
  cmd_vel.header.stamp = node_.lock()->now();

  int N = num_samples_;
  int H = prediction_horizon_;

  double current_x = pose.pose.position.x;
  double current_y = pose.pose.position.y;
  double current_theta = tf2::getYaw(pose.pose.orientation);

  // 维护近期轨迹观测窗口（位置 + 朝向，用于 FOV 视锥检查）
  TrailPose tp;
  tp.x = current_x;
  tp.y = current_y;
  tp.cos_theta = std::cos(current_theta);
  tp.sin_theta = std::sin(current_theta);
  trail_poses_.push_back(tp);
  // 清理超出观测窗口的旧轨迹点
  while (!trail_poses_.empty()) {
    size_t max_trail = static_cast<size_t>(observation_window_duration_ * 20.0);  // 20Hz
    if (trail_poses_.size() > max_trail) {
      trail_poses_.pop_front();
    } else {
      break;
    }
  }

  double target_x = current_x;
  double target_y = current_y;
  int closest_idx = 0;

  if (!global_plan_.poses.empty()) {
    double min_dist = std::numeric_limits<double>::max();

    for (size_t i = 0; i < global_plan_.poses.size(); ++i) {
      double dx = global_plan_.poses[i].pose.position.x - current_x;
      double dy = global_plan_.poses[i].pose.position.y - current_y;
      double dist = std::hypot(dx, dy);
      if (dist < min_dist) {
        min_dist = dist;
        closest_idx = static_cast<int>(i);
      }
    }

    // ── 终端角度对准模式（带迟滞状态）──
    // 进入后保持激活，防止在 0.10m 边界反复抖动。
    double final_gx = global_plan_.poses.back().pose.position.x;
    double final_gy = global_plan_.poses.back().pose.position.y;
    double dist_to_final = std::hypot(final_gx - current_x, final_gy - current_y);

    const double TERMINAL_HYSTERESIS = 0.10;  // 退出迟滞，进入 0.10m，退出 0.20m
    if (!terminal_angle_active_ && dist_to_final < terminal_angle_dist_) {
      terminal_angle_active_ = true;
    } else if (terminal_angle_active_ && dist_to_final > terminal_angle_dist_ + TERMINAL_HYSTERESIS) {
      terminal_angle_active_ = false;
    }

    if (terminal_angle_active_) {
      double goal_yaw = tf2::getYaw(global_plan_.poses.back().pose.orientation);
      double yaw_err = goal_yaw - current_theta;
      while (yaw_err > M_PI) yaw_err -= 2.0 * M_PI;
      while (yaw_err < -M_PI) yaw_err += 2.0 * M_PI;

      cmd_vel.twist.linear.x = 0.0;
      cmd_vel.twist.linear.y = 0.0;
      cmd_vel.twist.angular.z = std::max(-max_w_, std::min(max_w_,
        terminal_angle_kp_ * yaw_err));

      // 朝向到位 → 完全停止，重置状态
      if (std::abs(yaw_err) < terminal_angle_tolerance_) {
        cmd_vel.twist.angular.z = 0.0;
        terminal_angle_active_ = false;
      }

      return cmd_vel;
    }

    // 前瞻点：沿路径插值取精确的 min_lookahead_dist_ 米处
    // 在路径段上线性插值，而非直接取离散路径点，避免前瞻点跳变
    int last_idx = static_cast<int>(global_plan_.poses.size()) - 1;
    double accumulated = 0.0;
    double raw_lookahead_x = target_x;
    double raw_lookahead_y = target_y;
    bool found = false;

    for (int i = closest_idx; i < last_idx; ++i) {
      double dx = global_plan_.poses[i + 1].pose.position.x
                - global_plan_.poses[i].pose.position.x;
      double dy = global_plan_.poses[i + 1].pose.position.y
                - global_plan_.poses[i].pose.position.y;
      double seg_len = std::hypot(dx, dy);

      if (accumulated + seg_len >= min_lookahead_dist_) {
        // 在当前段内线性插值，取精确的前瞻点
        double remaining = min_lookahead_dist_ - accumulated;
        double alpha = (seg_len > 1e-9) ? remaining / seg_len : 0.0;
        alpha = std::max(0.0, std::min(1.0, alpha));
        raw_lookahead_x = global_plan_.poses[i].pose.position.x + alpha * dx;
        raw_lookahead_y = global_plan_.poses[i].pose.position.y + alpha * dy;
        found = true;
        break;
      }
      accumulated += seg_len;
    }

    // 路径不够长时，退化为终点
    if (!found && last_idx >= closest_idx) {
      raw_lookahead_x = global_plan_.poses[last_idx].pose.position.x;
      raw_lookahead_y = global_plan_.poses[last_idx].pose.position.y;
    }

    // 帧间指数平滑：抑制 closest_idx 跳变或路径点稀疏引入的残余抖动
    if (has_prev_lookahead_) {
      const double SMOOTH_ALPHA = 0.35;  // 平滑系数: 0=完全锁定, 1=不平滑
      target_x = prev_lookahead_x_ + SMOOTH_ALPHA * (raw_lookahead_x - prev_lookahead_x_);
      target_y = prev_lookahead_y_ + SMOOTH_ALPHA * (raw_lookahead_y - prev_lookahead_y_);
    } else {
      target_x = raw_lookahead_x;
      target_y = raw_lookahead_y;
      has_prev_lookahead_ = true;
    }
    prev_lookahead_x_ = target_x;
    prev_lookahead_y_ = target_y;
  }

  // 局部路径方向：取 closest_idx 处的一小段，用于 guidance 和噪声对齐
  double path_direction_x = 0.0;
  double path_direction_y = 0.0;
  if (!global_plan_.poses.empty() && closest_idx + 1 < static_cast<int>(global_plan_.poses.size())) {
    path_direction_x = global_plan_.poses[closest_idx + 1].pose.position.x
                     - global_plan_.poses[closest_idx].pose.position.x;
    path_direction_y = global_plan_.poses[closest_idx + 1].pose.position.y
                     - global_plan_.poses[closest_idx].pose.position.y;
    double path_len = std::hypot(path_direction_x, path_direction_y);
    if (path_len > 0.01) {
      path_direction_x /= path_len;
      path_direction_y /= path_len;
    }
  }

  // 提取全局路径点并均匀重采样（用于 GPU 内核的 cross-track error 计算）
  std::vector<float> host_path_x, host_path_y;
  int num_path_pts = 0;

  if (!global_plan_.poses.empty() && closest_idx < static_cast<int>(global_plan_.poses.size())) {
    // 第一步：计算从 closest_idx 到末尾的累计距离
    std::vector<double> cum_dist;
    cum_dist.push_back(0.0);
    double total_dist = 0.0;

    for (int i = closest_idx + 1; i < static_cast<int>(global_plan_.poses.size()); ++i) {
      double dx = global_plan_.poses[i].pose.position.x - global_plan_.poses[i - 1].pose.position.x;
      double dy = global_plan_.poses[i].pose.position.y - global_plan_.poses[i - 1].pose.position.y;
      total_dist += std::hypot(dx, dy);
      cum_dist.push_back(total_dist);
    }

    if (total_dist > 0.05 && cum_dist.size() >= 2) {
      // 第二步：按均匀步长采样 MAX_PATH_POINTS 个点
      double sample_dist = total_dist / (MAX_PATH_POINTS - 1);
      int seg_idx = 0;  // 当前所在的路径段索引

      for (int k = 0; k < MAX_PATH_POINTS; ++k) {
        double target_dist = k * sample_dist;

        // 找到包含 target_dist 的段
        while (seg_idx + 1 < static_cast<int>(cum_dist.size()) &&
               cum_dist[seg_idx + 1] < target_dist) {
          seg_idx++;
        }

        int i0 = closest_idx + seg_idx;
        int i1 = i0 + 1;
        if (i1 >= static_cast<int>(global_plan_.poses.size())) {
          i1 = static_cast<int>(global_plan_.poses.size()) - 1;
        }

        double seg_start = cum_dist[seg_idx];
        double seg_end = (seg_idx + 1 < static_cast<int>(cum_dist.size()))
                             ? cum_dist[seg_idx + 1]
                             : total_dist;
        double seg_len = seg_end - seg_start;
        double alpha = (seg_len > 1e-9) ? (target_dist - seg_start) / seg_len : 0.0;
        alpha = std::max(0.0, std::min(1.0, alpha));

        double px = global_plan_.poses[i0].pose.position.x +
                    alpha * (global_plan_.poses[i1].pose.position.x -
                             global_plan_.poses[i0].pose.position.x);
        double py = global_plan_.poses[i0].pose.position.y +
                    alpha * (global_plan_.poses[i1].pose.position.y -
                             global_plan_.poses[i0].pose.position.y);

        host_path_x.push_back(static_cast<float>(px));
        host_path_y.push_back(static_cast<float>(py));
      }
      num_path_pts = MAX_PATH_POINTS;
    }
  }

  // 初始化或滚动最优控制序列
  if (!initialized_) {
    double dx = target_x - current_x;
    double dy = target_y - current_y;
    double angle_to_goal = std::atan2(dy, dx);
    double angle_diff = angle_to_goal - current_theta;
    while (angle_diff > M_PI) angle_diff -= 2 * M_PI;
    while (angle_diff < -M_PI) angle_diff += 2 * M_PI;

    double dist_to_goal = std::hypot(dx, dy);
    double init_vx = std::min(max_v_, dist_to_goal / dt_);
    double init_vy = 0.0;
    double init_omega = std::max(-max_w_, std::min(max_w_, angle_diff / dt_));

    for (int i = 0; i < H; ++i) {
      optimal_vx_seq_[i] = init_vx;
      optimal_vy_seq_[i] = init_vy;
      optimal_omega_seq_[i] = init_omega;
    }
    initialized_ = true;
  } else {
    for (int i = 0; i < H - 1; ++i) {
      optimal_vx_seq_[i] = optimal_vx_seq_[i + 1];
      optimal_vy_seq_[i] = optimal_vy_seq_[i + 1];
      optimal_omega_seq_[i] = optimal_omega_seq_[i + 1];
    }
    // 尾部指数衰减而非直接清零，防止 base 序列逐帧塌缩
    // 连续 H 帧清零会导致整条序列归零，轨迹失去前向引导而四散
    const double TAIL_DECAY = 0.5;
    optimal_vx_seq_.back()     = optimal_vx_seq_[H - 2] * TAIL_DECAY;
    optimal_vy_seq_.back()     = optimal_vy_seq_[H - 2] * TAIL_DECAY;
    optimal_omega_seq_.back()  = optimal_omega_seq_[H - 2] * TAIL_DECAY;
  }

  // 预生成噪声序列（CPU 端，与原始 MPPI 一致）
  size_t noise_size = N * H;
  std::vector<float> noise_vx(noise_size);
  std::vector<float> noise_vy(noise_size);
  std::vector<float> noise_w(noise_size);

  for (int i = 0; i < N * H; ++i) {
    noise_vx[i] = static_cast<float>(dist_vx_(generator_));
    noise_vy[i] = static_cast<float>(dist_vy_(generator_));
    noise_w[i]  = static_cast<float>(dist_w_(generator_));
  }

  // 转换基控制序列为 float
  std::vector<float> base_vx_f(H), base_vy_f(H), base_w_f(H);
  for (int i = 0; i < H; ++i) {
    base_vx_f[i] = static_cast<float>(optimal_vx_seq_[i]);
    base_vy_f[i] = static_cast<float>(optimal_vy_seq_[i]);
    base_w_f[i]  = static_cast<float>(optimal_omega_seq_[i]);
  }

  // 获取 costmap 数据
  const unsigned char* costmap_data = nullptr;
  int costmap_w = 0, costmap_h = 0;
  float costmap_res = 0.05f;
  float costmap_origin_x = 0.0f, costmap_origin_y = 0.0f;

  // 可写的合并后 costmap（生命周期需覆盖后续所有 costmap_data 使用）
  std::vector<unsigned char> merged_costmap;

  if (costmap_ros_ != nullptr) {
    nav2_costmap_2d::Costmap2D* costmap = costmap_ros_->getCostmap();
    if (costmap != nullptr) {
      costmap_data = costmap->getCharMap();
      costmap_w = static_cast<int>(costmap->getSizeInCellsX());
      costmap_h = static_cast<int>(costmap->getSizeInCellsY());
      costmap_res = static_cast<float>(costmap->getResolution());
      costmap_origin_x = static_cast<float>(costmap->getOriginX());
      costmap_origin_y = static_cast<float>(costmap->getOriginY());

      // ── 合并全局代价地图到局部代价地图 ──
      // 对局部 costmap 每个 cell，通过 tf2 将世界坐标从 odom 帧
      // 变换到 map 帧，查询全局 costmap 对应值，取 max 合并。
      if (use_global_costmap_ && latest_global_costmap_ != nullptr) {
        const auto& global = *latest_global_costmap_;
        int gw = static_cast<int>(global.info.width);
        int gh = static_cast<int>(global.info.height);
        float g_res = global.info.resolution;
        float g_ox = static_cast<float>(global.info.origin.position.x);
        float g_oy = static_cast<float>(global.info.origin.position.y);

        // 仅分辨率相近时合并，避免栅格不对齐
        if (gw > 0 && gh > 0 && std::abs(g_res - costmap_res) < 1e-4f) {
          int total_cells = costmap_w * costmap_h;
          merged_costmap.assign(costmap_data, costmap_data + total_cells);

          try {
            auto tf_stamped = tf_->lookupTransform(
              "map", "odom", tf2::TimePointZero);

            double tx = tf_stamped.transform.translation.x;
            double ty = tf_stamped.transform.translation.y;
            double yaw = tf2::getYaw(tf_stamped.transform.rotation);
            double cos_t = std::cos(yaw);
            double sin_t = std::sin(yaw);

            int merged_count = 0;
            for (int my = 0; my < costmap_h; ++my) {
              for (int mx = 0; mx < costmap_w; ++mx) {
                // odom 帧下的世界坐标
                double wx = costmap_origin_x + (mx + 0.5) * costmap_res;
                double wy = costmap_origin_y + (my + 0.5) * costmap_res;

                // 变换到 map 帧
                double wx_map = tx + cos_t * wx - sin_t * wy;
                double wy_map = ty + sin_t * wx + cos_t * wy;

                // 查询全局 costmap
                int gx = static_cast<int>((wx_map - g_ox) / g_res);
                int gy = static_cast<int>((wy_map - g_oy) / g_res);
                if (gx >= 0 && gx < gw && gy >= 0 && gy < gh) {
                  unsigned char g_val = global.data[gy * gw + gx];
                  unsigned char& local_val = merged_costmap[my * costmap_w + mx];
                  // 取 max：不遗漏全局已知障碍物
                  if (g_val == 255 && local_val == 0) {
                    // 全局未知但局部空闲 → 适度提示（局部可能未探索此处）
                    local_val = 128;
                  } else if (g_val > local_val) {
                    local_val = g_val;
                  }
                  merged_count++;
                }
              }
            }
            costmap_data = merged_costmap.data();
            RCLCPP_DEBUG(node_.lock()->get_logger(),
              "全局代价地图合并: %d/%d cells 有覆盖", merged_count, total_cells);
          } catch (const tf2::TransformException& e) {
            RCLCPP_WARN_THROTTLE(node_.lock()->get_logger(),
              *node_.lock()->get_clock(), 5000,
              "odom→map 变换失败，跳过全局代价地图合并: %s", e.what());
          }
        }
      }
    }
  }

  // 按需分配/重分配 costmap GPU 缓冲区
  if (costmap_data != nullptr && costmap_w > 0 && costmap_h > 0) {
    if (costmap_w != costmap_w_ || costmap_h != costmap_h_) {
      cudaFree(d_costmap_);
      cudaError_t err = cudaMalloc(&d_costmap_, costmap_w * costmap_h * sizeof(unsigned char));
      if (err != cudaSuccess) {
        RCLCPP_ERROR(node_.lock()->get_logger(), "cudaMalloc(costmap) 失败: %s", cudaGetErrorString(err));
        d_costmap_ = nullptr;
        costmap_w_ = 0;
        costmap_h_ = 0;
      } else {
        costmap_w_ = costmap_w;
        costmap_h_ = costmap_h;
      }
    }
  }

  // 如果没有 costmap，确保 d_costmap_ 为 nullptr（内核需检查）
  if (costmap_data == nullptr) {
    costmap_w = 0;
    costmap_h = 0;
  }

  // ── 横向偏好分析：打破对称障碍物的左右抉择困境 ──
  // 在前瞻点处沿路径法向扫描 costmap，判断哪侧空闲更多，
  // 将 path_direction 微旋向空闲侧，使 MPPI 噪声采样/guidance 偏向该侧
  // 可通过 enable_lateral_bias 参数关闭
  if (enable_lateral_bias_ && costmap_data != nullptr && costmap_w > 0 && costmap_h > 0
      && std::hypot(path_direction_x, path_direction_y) > 0.01) {
    // 路径法向（全局坐标系）：左 = +90° 旋转
    double perp_x = -path_direction_y;
    double perp_y =  path_direction_x;

    auto sample_cost = [&](double wx, double wy) -> double {
      int mx = static_cast<int>((wx - costmap_origin_x) / costmap_res);
      int my = static_cast<int>((wy - costmap_origin_y) / costmap_res);
      if (mx >= 0 && mx < costmap_w && my >= 0 && my < costmap_h) {
        return costmap_data[my * costmap_w + mx] / 255.0;  // 归一化到 [0, 1]
      }
      return 1.0;  // 越界视为障碍
    };

    // 在前瞻点处沿法向采样左右两侧 (0.3m ~ 1.8m, 步长 0.3m)
    double left_cost = 0.0, right_cost = 0.0;
    int n_samples = 0;
    for (double d = 0.3; d <= 1.8; d += 0.3) {
      left_cost  += sample_cost(target_x + d * perp_x, target_y + d * perp_y);
      right_cost += sample_cost(target_x - d * perp_x, target_y - d * perp_y);
      n_samples++;
    }
    if (n_samples > 0) {
      left_cost /= n_samples;
      right_cost /= n_samples;
    }

    double cost_diff = right_cost - left_cost;  // >0 → 左侧更空闲 → 偏好左绕
    const double HYSTERESIS_MARGIN = 0.25;       // 迟滞区间，costmap 噪声下不易翻转

    if (preferred_lateral_dir_ < -0.5) {
      // 当前偏好左绕，需要右侧显著更空闲才切换
      if (cost_diff < -HYSTERESIS_MARGIN) {
        preferred_lateral_dir_ = 1.0;
      }
    } else if (preferred_lateral_dir_ > 0.5) {
      // 当前偏好右绕，需要左侧显著更空闲才切换
      if (cost_diff > HYSTERESIS_MARGIN) {
        preferred_lateral_dir_ = -1.0;
      }
    } else {
      // 无偏好，任一方向有显著优势即采纳
      if (cost_diff > HYSTERESIS_MARGIN) {
        preferred_lateral_dir_ = -1.0;
      } else if (cost_diff < -HYSTERESIS_MARGIN) {
        preferred_lateral_dir_ = 1.0;
      }
    }

    // 若前瞻点前方空旷且两侧对称，重置偏好（已通过障碍）
    double ahead_cost = sample_cost(target_x, target_y);
    if (ahead_cost < 0.05 && std::abs(cost_diff) < 0.08) {
      preferred_lateral_dir_ = 0.0;
    }

    // 将 path_direction 向偏好侧微旋（±6°），避免过度偏转引起摆动
    if (std::abs(preferred_lateral_dir_) > 0.1) {
      const double MAX_BIAS_ANGLE = 6.0 * M_PI / 180.0;
      double bias_angle = preferred_lateral_dir_ * MAX_BIAS_ANGLE;
      double cos_ba = std::cos(bias_angle);
      double sin_ba = std::sin(bias_angle);
      double biased_x = path_direction_x * cos_ba - path_direction_y * sin_ba;
      double biased_y = path_direction_x * sin_ba + path_direction_y * cos_ba;
      path_direction_x = biased_x;
      path_direction_y = biased_y;
    }
  }

  // 准备近期轨迹数据 (观测窗口：位置 + 朝向，用于 FOV 视锥检查)
  std::vector<float> trail_x, trail_y, trail_cos, trail_sin;
  int trail_count = static_cast<int>(trail_poses_.size());
  if (trail_count > MAX_TRAIL_POINTS) {
    // 超出最大容量时均匀降采样
    float step = static_cast<float>(trail_count) / static_cast<float>(MAX_TRAIL_POINTS);
    for (int i = 0; i < MAX_TRAIL_POINTS; ++i) {
      int idx = static_cast<int>(i * step);
      trail_x.push_back(static_cast<float>(trail_poses_[idx].x));
      trail_y.push_back(static_cast<float>(trail_poses_[idx].y));
      trail_cos.push_back(static_cast<float>(trail_poses_[idx].cos_theta));
      trail_sin.push_back(static_cast<float>(trail_poses_[idx].sin_theta));
    }
    trail_count = MAX_TRAIL_POINTS;
  } else {
    for (const auto& tp : trail_poses_) {
      trail_x.push_back(static_cast<float>(tp.x));
      trail_y.push_back(static_cast<float>(tp.y));
      trail_cos.push_back(static_cast<float>(tp.cos_theta));
      trail_sin.push_back(static_cast<float>(tp.sin_theta));
    }
  }
  float trust_radius_sq = static_cast<float>(trust_radius_ * trust_radius_);
  float fov_range_sq = static_cast<float>(fov_range_ * fov_range_);
  float fov_cos_half = std::cos(fov_half_angle_ * M_PI / 180.0);

  // 创建 CUDA stream
  cudaStream_t stream;
  cudaStreamCreate(&stream);

  // GPU 采样 + 代价计算
  int ret = mppi_gpu_sample_and_cost(
      noise_vx.data(), noise_vy.data(), noise_w.data(),
      base_vx_f.data(), base_vy_f.data(), base_w_f.data(),
      static_cast<float>(current_x), static_cast<float>(current_y), static_cast<float>(current_theta),
      static_cast<float>(target_x), static_cast<float>(target_y),
      costmap_data,
      costmap_w, costmap_h,
      costmap_res, costmap_origin_x, costmap_origin_y,
      static_cast<float>(dt_), static_cast<float>(min_v_), static_cast<float>(max_v_), static_cast<float>(max_vy_), static_cast<float>(max_w_),
      static_cast<float>(costmap_weight_),
      static_cast<float>(path_direction_x), static_cast<float>(path_direction_y),
      static_cast<float>(guidance_weight_),
      static_cast<float>(cross_track_noise_scale_),
      static_cast<float>(noise_decay_rate_),
      static_cast<float>(vel_direction_weight_),
      static_cast<float>(speed_reward_weight_),
      static_cast<float>(heading_weight_),
      static_cast<float>(lateral_guidance_scale_),
      static_cast<float>(unknown_cost_rear_),
      static_cast<float>(unknown_cost_side_),
      static_cast<float>(unknown_cost_front_),
      trail_x.data(), trail_y.data(),
      trail_cos.data(), trail_sin.data(),
      trail_count,
      trust_radius_sq,
      fov_range_sq,
      fov_cos_half,
      static_cast<float>(observed_area_cost_scale_),
      static_cast<float>(footprint_front_), static_cast<float>(footprint_back_),
      static_cast<float>(footprint_left_), static_cast<float>(footprint_right_),
      host_path_x.data(), host_path_y.data(),
      num_path_pts,
      static_cast<float>(path_attraction_weight_),
      N, H,
      d_noise_vx_, d_noise_vy_, d_noise_w_,
      d_base_vx_, d_base_vy_, d_base_w_,
      d_costmap_,
      d_path_x_, d_path_y_,
      d_trail_x_, d_trail_y_,
      d_trail_cos_, d_trail_sin_,
      d_costs_, d_sampled_vx_, d_sampled_vy_, d_sampled_w_,
      d_traj_x_, d_traj_y_,
      stream);

  if (ret != 0) {
    RCLCPP_ERROR(node_.lock()->get_logger(), "GPU 采样核函数失败，错误码: %d", ret);
    cudaStreamDestroy(stream);
    cmd_vel.twist.linear.x = 0.0;
    cmd_vel.twist.linear.y = 0.0;
    cmd_vel.twist.angular.z = 0.0;
    return cmd_vel;
  }

  // 拷贝代价回 CPU 以查找最小值
  std::vector<float> host_costs(N);
  cudaMemcpyAsync(host_costs.data(), d_costs_, N * sizeof(float), cudaMemcpyDeviceToHost, stream);
  cudaError_t sync_err = cudaStreamSynchronize(stream);
  if (sync_err != cudaSuccess) {
    RCLCPP_ERROR(node_.lock()->get_logger(),
      "cudaStreamSynchronize 失败 (代价拷贝): %s", cudaGetErrorString(sync_err));
    cudaStreamDestroy(stream);
    cmd_vel.twist.linear.x = 0.0;
    cmd_vel.twist.linear.y = 0.0;
    cmd_vel.twist.angular.z = 0.0;
    return cmd_vel;
  }

  float min_cost = std::numeric_limits<float>::max();
  int best_idx = 0;
  for (int i = 0; i < N; ++i) {
    if (host_costs[i] < min_cost) {
      min_cost = host_costs[i];
      best_idx = i;
    }
  }

  // GPU 加权求和 —— 对全部 H 个 timestep 独立计算
  ret = mppi_gpu_weighted_sum(
      d_costs_, d_sampled_vx_, d_sampled_vy_, d_sampled_w_,
      d_result_seq_,
      min_cost,
      static_cast<float>(lambda_),
      N, H,
      stream);

  if (ret != 0) {
    RCLCPP_ERROR(node_.lock()->get_logger(), "GPU 加权求和核函数失败，错误码: %d", ret);
    cudaStreamDestroy(stream);
    cmd_vel.twist.linear.x = 0.0;
    cmd_vel.twist.linear.y = 0.0;
    cmd_vel.twist.angular.z = 0.0;
    return cmd_vel;
  }

  // 拷贝全时域加权结果回 CPU（H × 4 个 float）
  std::vector<float> host_result_seq(H * 4);
  cudaMemcpyAsync(host_result_seq.data(), d_result_seq_, H * 4 * sizeof(float),
                  cudaMemcpyDeviceToHost, stream);
  sync_err = cudaStreamSynchronize(stream);
  if (sync_err != cudaSuccess) {
    RCLCPP_ERROR(node_.lock()->get_logger(),
      "cudaStreamSynchronize 失败 (结果拷贝): %s", cudaGetErrorString(sync_err));
    cudaStreamDestroy(stream);
    cmd_vel.twist.linear.x = 0.0;
    cmd_vel.twist.linear.y = 0.0;
    cmd_vel.twist.angular.z = 0.0;
    return cmd_vel;
  }

  // 解析全时域加权结果: u*_t = Σ w_k · sampled_u[k,t] / Σ w_k
  std::vector<double> u_star_vx(H, 0.0);
  std::vector<double> u_star_vy(H, 0.0);
  std::vector<double> u_star_w(H, 0.0);

  for (int t = 0; t < H; ++t) {
    float sum_w = host_result_seq[t * 4 + 3];
    if (sum_w > 1e-6f) {
      u_star_vx[t] = static_cast<double>(host_result_seq[t * 4 + 0] / sum_w);
      u_star_vy[t] = static_cast<double>(host_result_seq[t * 4 + 1] / sum_w);
      u_star_w[t]  = static_cast<double>(host_result_seq[t * 4 + 2] / sum_w);
    }
  }

  // 当前执行的控制量 = 优化序列的第一步 u*[0]
  double best_vx = u_star_vx[0];
  double best_vy = u_star_vy[0];
  double best_omega = u_star_w[0];

  // Clamp
  best_vx = std::max(min_v_, std::min(max_v_, best_vx));
  best_vy = std::max(-max_vy_, std::min(max_vy_, best_vy));
  best_omega = std::max(-max_w_, std::min(max_w_, best_omega));

  // ── 输出 EMA 低通滤波：抑制帧间控制量跳变 ──
  // ema = α·current + (1-α)·prev
  // α=0: 完全冻结, α=1: 无平滑 (raw MPPI)
  if (!ema_initialized_) {
    ema_cmd_vx_ = best_vx;
    ema_cmd_vy_ = best_vy;
    ema_cmd_w_  = best_omega;
    ema_initialized_ = true;
  } else {
    ema_cmd_vx_ = ema_alpha_ * best_vx + (1.0 - ema_alpha_) * ema_cmd_vx_;
    ema_cmd_vy_ = ema_alpha_ * best_vy + (1.0 - ema_alpha_) * ema_cmd_vy_;
    ema_cmd_w_  = ema_alpha_ * best_omega + (1.0 - ema_alpha_) * ema_cmd_w_;
  }
  best_vx = ema_cmd_vx_;
  best_vy = ema_cmd_vy_;
  best_omega = ema_cmd_w_;

  // MPPI 滚动优化：直接存储当前帧的全时域最优序列 u*
  // 下一帧开头会执行一次移位 (optimal[i] = optimal[i+1]) 将时间对齐到新时刻。
  // 此处不再移位，避免与开头的移位叠加形成"双重移位"导致 u*[1] 被跳过。
  for (int i = 0; i < H; ++i) {
    optimal_vx_seq_[i] = u_star_vx[i];
    optimal_vy_seq_[i] = u_star_vy[i];
    optimal_omega_seq_[i] = u_star_w[i];
  }

  // ── 纯追踪回退（单向切换，不退返）──
  // 进入回退范围意味着已到终点跟前，之后一路纯追踪 → 终端对准 → 完成。
  // 不做退出，避免 MPPI 重新接管后在 0.20m 边界反复进出。
  //   - 进入：dist_to_final < fallback_enable_dist_ → 立即激活
  //   - 退出：不退出，纯追踪一路到底（新路径到达时 reset）
  double dist_to_final_fb = 1e9;
  if (!global_plan_.poses.empty()) {
    dist_to_final_fb = std::hypot(
      global_plan_.poses.back().pose.position.x - current_x,
      global_plan_.poses.back().pose.position.y - current_y);
  }

  if (!fallback_active_ && dist_to_final_fb < fallback_enable_dist_) {
    fallback_active_ = true;
    RCLCPP_DEBUG(node_.lock()->get_logger(),
      "MPPI fallback 激活: dist=%.2fm < %.2fm, 之后不退出",
      dist_to_final_fb, fallback_enable_dist_);
  }

  if (fallback_active_) {
    // ── 回退策略：全向纯追踪 (PD 控制 + 距离比例速度) ──
    // 全向底盘速度方向与朝向解耦，直接沿目标方向移动，
    // omega 用 PD 控制柔和收敛 goal yaw，速度随距离衰减。
    double final_gx = global_plan_.poses.back().pose.position.x;
    double final_gy = global_plan_.poses.back().pose.position.y;
    double dx = final_gx - current_x;
    double dy = final_gy - current_y;
    double dist = std::hypot(dx, dy);

    // ── 速度：距离比例，越近越慢 ──
    // d=0.20m → speed≈0.10, d=0.10m → speed≈0.05, d→0 → speed→0
    double speed = dist * 0.5;  // Kp_pos = 0.5, 距离比例
    speed = std::min(speed, 0.10);  // 上限 0.10 m/s

    double world_angle = std::atan2(dy, dx);
    double rel_angle = world_angle - current_theta;
    best_vx = std::cos(rel_angle) * speed;
    best_vy = std::sin(rel_angle) * speed;

    // ── omega: PD 控制追踪 goal yaw ──
    double goal_yaw = tf2::getYaw(global_plan_.poses.back().pose.orientation);
    double yaw_err = goal_yaw - current_theta;
    while (yaw_err > M_PI) yaw_err -= 2 * M_PI;
    while (yaw_err < -M_PI) yaw_err += 2 * M_PI;

    // 首次进入回退时，用当前误差初始化避免 D 项冲击
    if (fallback_prev_yaw_err_ == 0.0 && yaw_err != 0.0) {
      fallback_prev_yaw_err_ = yaw_err;
    }
    double yaw_deriv = (yaw_err - fallback_prev_yaw_err_) / dt_;
    fallback_prev_yaw_err_ = yaw_err;

    const double W_KP = 1.0;     // P 增益，足够在 0.5s 窗口内收敛
    const double W_KD = 0.2;     // D 增益，抑制超调
    const double W_MAX = 0.5;    // 上限 ~30°/s，不会太剧烈
    best_omega = yaw_err * W_KP + yaw_deriv * W_KD;
    best_omega = std::max(-W_MAX, std::min(W_MAX, best_omega));
  }

  // ── 前方障碍物 KP 速度控制 ──
  // 在机器人前方 ±fov_half 范围内投射射线，检测最近障碍物。
  // avg_obstacle_dist / safe_dist → kp ∈ [min_kp, 1.0]
  // 障碍物越近 → kp 越小 → 线速度越低，但角速度保持不变以保留避障能力
  if (front_obstacle_kp_enabled_ && costmap_data != nullptr
      && costmap_w > 0 && costmap_h > 0) {
    double fov_half_rad = front_obstacle_fov_deg_ * M_PI / 180.0;
    double step = costmap_res * 0.5;  // 半步长，避免跳过薄障碍物
    int max_steps = static_cast<int>(front_obstacle_max_range_ / step);
    int num_rays = front_obstacle_num_rays_;

    double total_dist = 0.0;
    int valid_rays = 0;

    for (int r = 0; r < num_rays; ++r) {
      double angle = current_theta - fov_half_rad
                   + (2.0 * fov_half_rad * r) / std::max(1, num_rays - 1);
      double ray_cos = std::cos(angle);
      double ray_sin = std::sin(angle);

      double hit_dist = front_obstacle_max_range_;

      for (int s = 1; s <= max_steps; ++s) {
        double d = s * step;
        double wx = current_x + d * ray_cos;
        double wy = current_y + d * ray_sin;
        int mx = static_cast<int>((wx - costmap_origin_x) / costmap_res);
        int my = static_cast<int>((wy - costmap_origin_y) / costmap_res);
        if (mx < 0 || mx >= costmap_w || my < 0 || my >= costmap_h) break;
        unsigned char cell = costmap_data[my * costmap_w + mx];
        if (cell >= 254) {  // 致命障碍物或未知
          hit_dist = d;
          break;
        }
      }

      total_dist += hit_dist;
      valid_rays++;
    }

    if (valid_rays > 0) {
      double avg_dist = total_dist / valid_rays;
      double kp = avg_dist / front_obstacle_safe_dist_;
      kp = std::max(front_obstacle_min_kp_, std::min(1.0, kp));
      best_vx *= kp;
      best_vy *= kp;

      RCLCPP_DEBUG(node_.lock()->get_logger(),
        "前方障碍物 KP: avg_dist=%.2fm, kp=%.2f, vx=%.2f→%.2f",
        avg_dist, kp, best_vx / kp, best_vx);
    }
  }

  cmd_vel.twist.linear.x = best_vx;
  cmd_vel.twist.linear.y = best_vy;
  cmd_vel.twist.angular.z = best_omega;

  // 可视化：挑选代价最低的 10 条轨迹，从 GPU 拷贝
  const int TOP_K = 10;

  // 找出代价最低的 TOP_K 个索引
  std::vector<int> top_indices;
  {
    std::vector<std::pair<float, int>> cost_idx_pairs;
    cost_idx_pairs.reserve(N);
    for (int i = 0; i < N; ++i) {
      cost_idx_pairs.emplace_back(host_costs[i], i);
    }
    int n_select = std::min(TOP_K, N);
    std::partial_sort(cost_idx_pairs.begin(),
                      cost_idx_pairs.begin() + n_select,
                      cost_idx_pairs.end());
    for (int k = 0; k < n_select; ++k) {
      top_indices.push_back(cost_idx_pairs[k].second);
    }
  }

  int vis_samples = static_cast<int>(top_indices.size());
  std::vector<float> vis_traj_x(vis_samples * H);
  std::vector<float> vis_traj_y(vis_samples * H);

  // 按索引逐条拷贝（同一 stream 保证顺序）
  for (int k = 0; k < vis_samples; ++k) {
    int idx = top_indices[k];
    cudaMemcpyAsync(vis_traj_x.data() + k * H, d_traj_x_ + idx * H,
                    H * sizeof(float), cudaMemcpyDeviceToHost, stream);
    cudaMemcpyAsync(vis_traj_y.data() + k * H, d_traj_y_ + idx * H,
                    H * sizeof(float), cudaMemcpyDeviceToHost, stream);
  }

  // 最后一次同步：确保所有 stream 操作（含可视数据拷贝）完成
  cudaError_t vis_sync_err = cudaStreamSynchronize(stream);
  cudaStreamDestroy(stream);

  if (vis_sync_err != cudaSuccess) {
    RCLCPP_ERROR(node_.lock()->get_logger(),
      "cudaStreamSynchronize 失败 (vis): %s", cudaGetErrorString(vis_sync_err));
  }

  // top_indices[0] 代价最低，为最优轨迹（绿色），其余按代价升序排列
  int vis_best_idx = 0;

  publishVisualization(current_x, current_y, current_theta,
                       target_x, target_y,
                       vis_traj_x, vis_traj_y,
                       vis_samples, vis_best_idx,
                       pose.header.frame_id);

  // ── 运行时统计数据采集 ──
  if (enable_stats_) {
    // cross-track error: 当前位置到全局路径的最短距离
    double cross_track_err = std::numeric_limits<double>::max();
    if (!global_plan_.poses.empty() && closest_idx + 1 < static_cast<int>(global_plan_.poses.size())) {
      for (size_t i = 0; i + 1 < global_plan_.poses.size(); ++i) {
        double ax = global_plan_.poses[i].pose.position.x;
        double ay = global_plan_.poses[i].pose.position.y;
        double bx = global_plan_.poses[i + 1].pose.position.x;
        double by = global_plan_.poses[i + 1].pose.position.y;
        double abx = bx - ax, aby = by - ay;
        double ab_len_sq = abx * abx + aby * aby;
        double t = 0.0;
        if (ab_len_sq > 1e-9) {
          t = ((current_x - ax) * abx + (current_y - ay) * aby) / ab_len_sq;
          t = std::max(0.0, std::min(1.0, t));
        }
        double cx = ax + t * abx;
        double cy = ay + t * aby;
        double err = std::hypot(current_x - cx, current_y - cy);
        if (err < cross_track_err) cross_track_err = err;
      }
    }
    if (cross_track_err == std::numeric_limits<double>::max()) cross_track_err = 0.0;

    // heading error: 机器人朝向与路径方向之差
    double path_heading = std::atan2(path_direction_y, path_direction_x);
    double heading_err = path_heading - current_theta;
    while (heading_err > M_PI) heading_err -= 2.0 * M_PI;
    while (heading_err < -M_PI) heading_err += 2.0 * M_PI;

    // 到前瞻点距离
    double dist_to_goal = std::hypot(target_x - current_x, target_y - current_y);

    double now_sec = node_.lock()->now().seconds();

    recordStatsFrame(best_vx, best_vy, best_omega,
                     u_star_vx[0], u_star_vy[0], u_star_w[0],
                     cross_track_err, heading_err, dist_to_goal,
                     min_cost, now_sec);
  }

  return cmd_vel;
}

void MPPIGPUController::publishVisualization(
  double robot_x, double robot_y, double robot_theta,
  double target_x, double target_y,
  const std::vector<float>& traj_data_x,
  const std::vector<float>& traj_data_y,
  int vis_samples,
  int best_idx,
  const std::string& frame_id)
{
  auto node_ptr = node_.lock();
  if (!node_ptr || !vis_pub_) return;

  int H = prediction_horizon_;

  visualization_msgs::msg::MarkerArray marker_array;
  rclcpp::Time now = node_ptr->now();
  // 设置生命周期为控制器周期的 2 倍，确保每帧刷新、旧 marker 自动过期
  auto marker_lifetime = rclcpp::Duration::from_seconds(0.1);

  // 机器人位置（红色）
  {
    visualization_msgs::msg::Marker m;
    m.header.frame_id = frame_id;
    m.header.stamp = now;
    m.ns = "mppi_gpu";
    m.id = 0;
    m.type = visualization_msgs::msg::Marker::SPHERE;
    m.action = visualization_msgs::msg::Marker::ADD;
    m.lifetime = marker_lifetime;
    m.pose.position.x = robot_x;
    m.pose.position.y = robot_y;
    m.pose.position.z = 0.1;
    m.scale.x = 0.3;
    m.scale.y = 0.3;
    m.scale.z = 0.3;
    m.color.r = 1.0;
    m.color.g = 0.0;
    m.color.b = 0.0;
    m.color.a = 1.0;
    marker_array.markers.push_back(m);
  }

  // 目标点（绿色）
  {
    visualization_msgs::msg::Marker m;
    m.header.frame_id = frame_id;
    m.header.stamp = now;
    m.ns = "mppi_gpu";
    m.id = 1;
    m.type = visualization_msgs::msg::Marker::SPHERE;
    m.action = visualization_msgs::msg::Marker::ADD;
    m.lifetime = marker_lifetime;
    m.pose.position.x = target_x;
    m.pose.position.y = target_y;
    m.pose.position.z = 0.1;
    m.scale.x = 0.4;
    m.scale.y = 0.4;
    m.scale.z = 0.4;
    m.color.r = 0.0;
    m.color.g = 1.0;
    m.color.b = 0.0;
    m.color.a = 1.0;
    marker_array.markers.push_back(m);
  }

  // 机器人朝向（黄色箭头）
  {
    visualization_msgs::msg::Marker m;
    m.header.frame_id = frame_id;
    m.header.stamp = now;
    m.ns = "mppi_gpu";
    m.id = 2;
    m.type = visualization_msgs::msg::Marker::LINE_STRIP;
    m.action = visualization_msgs::msg::Marker::ADD;
    m.lifetime = marker_lifetime;
    m.points.resize(2);
    m.points[0].x = robot_x;
    m.points[0].y = robot_y;
    m.points[0].z = 0.15;
    m.points[1].x = robot_x + std::cos(robot_theta) * 0.8;
    m.points[1].y = robot_y + std::sin(robot_theta) * 0.8;
    m.points[1].z = 0.15;
    m.scale.x = 0.08;
    m.color.r = 1.0;
    m.color.g = 1.0;
    m.color.b = 0.0;
    m.color.a = 1.0;
    marker_array.markers.push_back(m);
  }

  // 采样轨迹
  for (int i = 0; i < vis_samples; ++i) {
    visualization_msgs::msg::Marker m;
    m.header.frame_id = frame_id;
    m.header.stamp = now;
    m.ns = "samples_gpu";
    m.id = i;
    m.type = visualization_msgs::msg::Marker::LINE_STRIP;
    m.action = visualization_msgs::msg::Marker::ADD;
    m.lifetime = marker_lifetime;

    // 起点：机器人当前位置（轨迹从这里开始）
    {
      geometry_msgs::msg::Point p;
      p.x = robot_x;
      p.y = robot_y;
      p.z = 0.05;
      m.points.push_back(p);
    }

    // GPU 预测的 H 步位置，到达目标附近时截断
    const float GOAL_REACHED_DIST = 0.25f;
    for (int t = 0; t < H; ++t) {
      float px = traj_data_x[i * H + t];
      float py = traj_data_y[i * H + t];
      geometry_msgs::msg::Point p;
      p.x = px;
      p.y = py;
      p.z = 0.05;
      m.points.push_back(p);
      float dx_g = static_cast<float>(target_x) - px;
      float dy_g = static_cast<float>(target_y) - py;
      if (std::hypot(dx_g, dy_g) < GOAL_REACHED_DIST) break;
    }

    if (i == best_idx) {
      m.color.r = 0.0;
      m.color.g = 1.0;
      m.color.b = 0.0;
      m.color.a = 0.8;
      m.scale.x = 0.06;
    } else {
      m.color.r = 0.7;
      m.color.g = 0.7;
      m.color.b = 0.7;
      m.color.a = 0.5;
      m.scale.x = 0.04;
    }
    marker_array.markers.push_back(m);
  }

  vis_pub_->publish(marker_array);
}

void MPPIGPUController::recordStatsFrame(
  double vx, double vy, double omega,
  double vx_raw, double vy_raw, double omega_raw,
  double cross_track_err, double heading_err,
  double dist_to_goal, float best_cost,
  double current_time)
{
  StatsFrame f;
  f.frame = stats_frame_count_++;
  f.time_s = current_time - stats_start_time_;
  f.vx = vx;
  f.vy = vy;
  f.omega = omega;
  f.vx_raw = vx_raw;
  f.vy_raw = vy_raw;
  f.omega_raw = omega_raw;
  f.cross_track_err = cross_track_err;
  f.heading_err = heading_err;
  f.dist_to_goal = dist_to_goal;
  f.best_cost = best_cost;

  // 突变检测：相邻帧间原始控制量跳变超过阈值
  if (has_prev_stats_) {
    f.mutation_vx = std::abs(vx_raw - prev_vx_raw_) > mutation_thresh_vx_;
    f.mutation_vy = std::abs(vy_raw - prev_vy_raw_) > mutation_thresh_vy_;
    f.mutation_w  = std::abs(omega_raw - prev_omega_raw_) > mutation_thresh_w_;
  } else {
    f.mutation_vx = false;
    f.mutation_vy = false;
    f.mutation_w = false;
  }

  prev_vx_raw_ = vx_raw;
  prev_vy_raw_ = vy_raw;
  prev_omega_raw_ = omega_raw;
  has_prev_stats_ = true;

  stats_frames_.push_back(f);
}

void MPPIGPUController::writeStatsToFile()
{
  if (!enable_stats_ || stats_frames_.empty()) return;

  std::ofstream ofs(stats_file_path_);
  if (!ofs.is_open()) {
    RCLCPP_ERROR(node_.lock()->get_logger(),
      "无法打开统计数据文件: %s", stats_file_path_.c_str());
    return;
  }

  ofs << std::fixed << std::setprecision(4);

  // 表头
  ofs << "# MPPI GPU Controller Statistics\n";
  ofs << "# frame,time_s,vx,vy,omega,vx_raw,vy_raw,omega_raw,"
      << "cross_track_err,heading_err,dist_to_goal,"
      << "mutation_vx,mutation_vy,mutation_w,best_cost\n";

  // 逐帧数据
  for (const auto& f : stats_frames_) {
    ofs << f.frame << "," << f.time_s << ","
        << f.vx << "," << f.vy << "," << f.omega << ","
        << f.vx_raw << "," << f.vy_raw << "," << f.omega_raw << ","
        << f.cross_track_err << "," << f.heading_err << "," << f.dist_to_goal << ","
        << (f.mutation_vx ? 1 : 0) << ","
        << (f.mutation_vy ? 1 : 0) << ","
        << (f.mutation_w ? 1 : 0) << ","
        << f.best_cost << "\n";
  }

  // ── 汇总统计 ──
  int n = static_cast<int>(stats_frames_.size());
  if (n == 0) { ofs.close(); return; }

  auto compute_stats = [&](const auto& getter) -> std::tuple<double, double, double, double> {
    double sum = 0.0, sq_sum = 0.0, min_v = 1e18, max_v = -1e18;
    for (const auto& f : stats_frames_) {
      double v = getter(f);
      sum += v;
      sq_sum += v * v;
      if (v < min_v) min_v = v;
      if (v > max_v) max_v = v;
    }
    double mean = sum / n;
    double stddev = std::sqrt(sq_sum / n - mean * mean);
    return {mean, stddev, min_v, max_v};
  };

  auto [avg_vx, std_vx, min_vx, max_vx] = compute_stats([](const StatsFrame& f) { return f.vx; });
  auto [avg_vy, std_vy, min_vy, max_vy] = compute_stats([](const StatsFrame& f) { return f.vy; });
  auto [avg_w, std_w, min_w, max_w] = compute_stats([](const StatsFrame& f) { return f.omega; });
  auto [avg_cte, std_cte, min_cte, max_cte] = compute_stats([](const StatsFrame& f) { return f.cross_track_err; });
  auto [avg_he, std_he, min_he, max_he] = compute_stats([](const StatsFrame& f) { return std::abs(f.heading_err); });

  int mut_vx_cnt = 0, mut_vy_cnt = 0, mut_w_cnt = 0;
  for (const auto& f : stats_frames_) {
    if (f.mutation_vx) mut_vx_cnt++;
    if (f.mutation_vy) mut_vy_cnt++;
    if (f.mutation_w)  mut_w_cnt++;
  }

  ofs << "#\n# ── 汇总统计 (n=" << n << ") ──\n";
  ofs << "# avg_vx: " << avg_vx << ", std_vx: " << std_vx
      << ", min_vx: " << min_vx << ", max_vx: " << max_vx << "\n";
  ofs << "# avg_vy: " << avg_vy << ", std_vy: " << std_vy
      << ", min_vy: " << min_vy << ", max_vy: " << max_vy << "\n";
  ofs << "# avg_omega: " << avg_w << ", std_omega: " << std_w
      << ", min_omega: " << min_w << ", max_omega: " << max_w << "\n";
  ofs << "# avg_cross_track_err: " << avg_cte << ", max_cross_track_err: " << max_cte << "\n";
  ofs << "# avg_abs_heading_err: " << avg_he << ", max_abs_heading_err: " << max_he << "\n";
  ofs << "# mutation_rate_vx: " << (static_cast<double>(mut_vx_cnt) / n)
      << " (" << mut_vx_cnt << "/" << n << "), thresh=" << mutation_thresh_vx_ << "\n";
  ofs << "# mutation_rate_vy: " << (static_cast<double>(mut_vy_cnt) / n)
      << " (" << mut_vy_cnt << "/" << n << "), thresh=" << mutation_thresh_vy_ << "\n";
  ofs << "# mutation_rate_w: " << (static_cast<double>(mut_w_cnt) / n)
      << " (" << mut_w_cnt << "/" << n << "), thresh=" << mutation_thresh_w_ << "\n";

  ofs.close();

  RCLCPP_INFO(node_.lock()->get_logger(),
    "统计数据已写入: %s (%d 帧)", stats_file_path_.c_str(), n);
}

}  // namespace nav2_custom_plugins

PLUGINLIB_EXPORT_CLASS(nav2_custom_plugins::MPPIGPUController, nav2_core::Controller)
