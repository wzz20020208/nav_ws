#include "nav2_custom_plugins/mppi_gpu_controller.hpp"
#include <limits>
#include <cmath>
#include <algorithm>
#include <random>
#include <cstring>
#include <cuda_runtime.h>
#include "tf2/utils.h"

// CUDA host wrapper 函数声明（实现在 mppi_gpu_kernels.cu 中）
extern "C" {
int mppi_gpu_sample_and_cost(
    const float* noise_vx, const float* noise_vy, const float* noise_w,
    const float* base_vx, const float* base_vy, const float* base_w,
    float current_x, float current_y, float current_theta,
    float target_x, float target_y,
    const unsigned char* costmap,
    int costmap_w, int costmap_h,
    float costmap_res, float costmap_origin_x, float costmap_origin_y,
    float dt, float min_v, float max_v, float max_vy, float max_w,
    float costmap_weight,
    float path_dir_x, float path_dir_y,
    float guidance_weight,
    float cross_track_noise_scale,
    float noise_decay_rate,
    float vel_direction_weight,
    float speed_reward_weight,
    float heading_weight,
    float lateral_guidance_scale,
    float unknown_cost_rear,
    float unknown_cost_side,
    float unknown_cost_front,
    const float* trail_x, const float* trail_y,
    const float* trail_cos, const float* trail_sin,
    int trail_count,
    float trust_radius_sq,
    float fov_range_sq,
    float fov_cos_half,
    float observed_area_cost_scale,
    float fp_front, float fp_back, float fp_left, float fp_right,
    const float* path_x, const float* path_y,
    int num_path_pts,
    float path_attraction_weight,
    int num_samples, int horizon,
    float* d_noise_vx, float* d_noise_vy, float* d_noise_w,
    float* d_base_vx, float* d_base_vy, float* d_base_w,
    unsigned char* d_costmap,
    float* d_path_x, float* d_path_y,
    float* d_trail_x_, float* d_trail_y_,
    float* d_trail_cos_, float* d_trail_sin_,
    float* d_costs, float* d_sampled_vx, float* d_sampled_vy, float* d_sampled_w,
    float* d_traj_x, float* d_traj_y,
    cudaStream_t stream);

int mppi_gpu_weighted_sum(
    const float* d_costs,
    const float* d_sampled_vx, const float* d_sampled_vy, const float* d_sampled_w,
    float* d_result_seq,
    float min_cost,
    float lambda,
    int num_samples,
    int horizon,
    cudaStream_t stream);
}

namespace nav2_custom_plugins
{

void MPPIGPUController::allocateGPUBuffers()
{
  // 防止重复分配
  if (gpu_buffers_allocated_) {
    RCLCPP_WARN(node_.lock()->get_logger(), "GPU 缓冲区已分配，跳过重复分配");
    return;
  }

  int N = num_samples_;
  int H = prediction_horizon_;
  cudaError_t err;

  auto check = [&](cudaError_t e, const char* name) {
    if (e != cudaSuccess) {
      RCLCPP_ERROR(node_.lock()->get_logger(),
        "cudaMalloc(%s) 失败: %s", name, cudaGetErrorString(e));
    }
  };

  err = cudaMalloc(&d_noise_vx_, N * H * sizeof(float));  check(err, "d_noise_vx");
  err = cudaMalloc(&d_noise_vy_, N * H * sizeof(float));  check(err, "d_noise_vy");
  err = cudaMalloc(&d_noise_w_,  N * H * sizeof(float));  check(err, "d_noise_w");
  err = cudaMalloc(&d_base_vx_, H * sizeof(float));       check(err, "d_base_vx");
  err = cudaMalloc(&d_base_vy_, H * sizeof(float));       check(err, "d_base_vy");
  err = cudaMalloc(&d_base_w_,  H * sizeof(float));       check(err, "d_base_w");
  err = cudaMalloc(&d_costs_,       N * sizeof(float));      check(err, "d_costs");
  err = cudaMalloc(&d_sampled_vx_,  N * H * sizeof(float));  check(err, "d_sampled_vx");
  err = cudaMalloc(&d_sampled_vy_,  N * H * sizeof(float));  check(err, "d_sampled_vy");
  err = cudaMalloc(&d_sampled_w_,   N * H * sizeof(float));  check(err, "d_sampled_w");
  err = cudaMalloc(&d_result_seq_,  H * 4 * sizeof(float));  check(err, "d_result_seq");
  err = cudaMalloc(&d_traj_x_,      N * H * sizeof(float));  check(err, "d_traj_x");
  err = cudaMalloc(&d_traj_y_,      N * H * sizeof(float));  check(err, "d_traj_y");
  err = cudaMalloc(&d_path_x_,      MAX_PATH_POINTS * sizeof(float));  check(err, "d_path_x");
  err = cudaMalloc(&d_path_y_,      MAX_PATH_POINTS * sizeof(float));  check(err, "d_path_y");
  err = cudaMalloc(&d_trail_x_,     MAX_TRAIL_POINTS * sizeof(float));  check(err, "d_trail_x");
  err = cudaMalloc(&d_trail_y_,     MAX_TRAIL_POINTS * sizeof(float));  check(err, "d_trail_y");
  err = cudaMalloc(&d_trail_cos_,   MAX_TRAIL_POINTS * sizeof(float));  check(err, "d_trail_cos");
  err = cudaMalloc(&d_trail_sin_,   MAX_TRAIL_POINTS * sizeof(float));  check(err, "d_trail_sin");

  // costmap 显存最初不分配（等到 computeVelocityCommands 中按需分配）
  d_costmap_ = nullptr;
  costmap_w_ = 0;
  costmap_h_ = 0;

  gpu_buffers_allocated_ = true;
}

void MPPIGPUController::freeGPUBuffers()
{
  if (!gpu_buffers_allocated_) return;

  cudaFree(d_noise_vx_);  d_noise_vx_ = nullptr;
  cudaFree(d_noise_vy_);  d_noise_vy_ = nullptr;
  cudaFree(d_noise_w_);   d_noise_w_  = nullptr;
  cudaFree(d_base_vx_);   d_base_vx_  = nullptr;
  cudaFree(d_base_vy_);   d_base_vy_  = nullptr;
  cudaFree(d_base_w_);    d_base_w_   = nullptr;
  cudaFree(d_costs_);       d_costs_      = nullptr;
  cudaFree(d_sampled_vx_);  d_sampled_vx_ = nullptr;
  cudaFree(d_sampled_vy_);  d_sampled_vy_ = nullptr;
  cudaFree(d_sampled_w_);   d_sampled_w_  = nullptr;
  cudaFree(d_result_seq_);  d_result_seq_ = nullptr;
  cudaFree(d_traj_x_);      d_traj_x_     = nullptr;
  cudaFree(d_traj_y_);      d_traj_y_     = nullptr;
  cudaFree(d_path_x_);      d_path_x_     = nullptr;
  cudaFree(d_path_y_);      d_path_y_     = nullptr;
  cudaFree(d_trail_x_);     d_trail_x_    = nullptr;
  cudaFree(d_trail_y_);     d_trail_y_    = nullptr;
  cudaFree(d_trail_cos_);   d_trail_cos_  = nullptr;
  cudaFree(d_trail_sin_);   d_trail_sin_  = nullptr;

  cudaFree(d_costmap_);   d_costmap_  = nullptr;
  costmap_w_ = 0;
  costmap_h_ = 0;

  gpu_buffers_allocated_ = false;
}

void MPPIGPUController::configure(
  const rclcpp_lifecycle::LifecycleNode::WeakPtr & parent,
  std::string name,
  std::shared_ptr<tf2_ros::Buffer> tf,
  std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros)
{
  node_ = parent;
  plugin_name_ = name;
  tf_ = tf;
  costmap_ros_ = costmap_ros;

  auto node_ptr = node_.lock();

  // 声明并加载可配置参数
  node_ptr->declare_parameter(plugin_name_ + ".path_attraction_weight", path_attraction_weight_);
  node_ptr->get_parameter(plugin_name_ + ".path_attraction_weight", path_attraction_weight_);

  node_ptr->declare_parameter(plugin_name_ + ".lookahead_time", lookahead_time_);
  node_ptr->get_parameter(plugin_name_ + ".lookahead_time", lookahead_time_);

  node_ptr->declare_parameter(plugin_name_ + ".min_lookahead_dist", min_lookahead_dist_);
  node_ptr->get_parameter(plugin_name_ + ".min_lookahead_dist", min_lookahead_dist_);

  node_ptr->declare_parameter(plugin_name_ + ".guidance_weight", guidance_weight_);
  node_ptr->get_parameter(plugin_name_ + ".guidance_weight", guidance_weight_);

  node_ptr->declare_parameter(plugin_name_ + ".cross_track_noise_scale", cross_track_noise_scale_);
  node_ptr->get_parameter(plugin_name_ + ".cross_track_noise_scale", cross_track_noise_scale_);

  node_ptr->declare_parameter(plugin_name_ + ".noise_decay_rate", noise_decay_rate_);
  node_ptr->get_parameter(plugin_name_ + ".noise_decay_rate", noise_decay_rate_);

  node_ptr->declare_parameter(plugin_name_ + ".vel_direction_weight", vel_direction_weight_);
  node_ptr->get_parameter(plugin_name_ + ".vel_direction_weight", vel_direction_weight_);

  node_ptr->declare_parameter(plugin_name_ + ".speed_reward_weight", speed_reward_weight_);
  node_ptr->get_parameter(plugin_name_ + ".speed_reward_weight", speed_reward_weight_);

  node_ptr->declare_parameter(plugin_name_ + ".heading_weight", heading_weight_);
  node_ptr->get_parameter(plugin_name_ + ".heading_weight", heading_weight_);

  node_ptr->declare_parameter(plugin_name_ + ".lateral_guidance_scale", lateral_guidance_scale_);
  node_ptr->get_parameter(plugin_name_ + ".lateral_guidance_scale", lateral_guidance_scale_);

  node_ptr->declare_parameter(plugin_name_ + ".ema_alpha", ema_alpha_);
  node_ptr->get_parameter(plugin_name_ + ".ema_alpha", ema_alpha_);

  // 分方向未知区域代价权重：后方 > 侧方 > 前方（机器人只有前方视野）
  node_ptr->declare_parameter(plugin_name_ + ".unknown_cost_rear", unknown_cost_rear_);
  node_ptr->get_parameter(plugin_name_ + ".unknown_cost_rear", unknown_cost_rear_);
  node_ptr->declare_parameter(plugin_name_ + ".unknown_cost_side", unknown_cost_side_);
  node_ptr->get_parameter(plugin_name_ + ".unknown_cost_side", unknown_cost_side_);
  node_ptr->declare_parameter(plugin_name_ + ".unknown_cost_front", unknown_cost_front_);
  node_ptr->get_parameter(plugin_name_ + ".unknown_cost_front", unknown_cost_front_);

  // 观测窗口参数：近期经过的区域降低未知代价
  node_ptr->declare_parameter(plugin_name_ + ".observation_window_duration", observation_window_duration_);
  node_ptr->get_parameter(plugin_name_ + ".observation_window_duration", observation_window_duration_);
  node_ptr->declare_parameter(plugin_name_ + ".trust_radius", trust_radius_);
  node_ptr->get_parameter(plugin_name_ + ".trust_radius", trust_radius_);
  node_ptr->declare_parameter(plugin_name_ + ".observed_area_cost_scale", observed_area_cost_scale_);
  node_ptr->get_parameter(plugin_name_ + ".observed_area_cost_scale", observed_area_cost_scale_);

  // 传感器 FOV 参数：可视区域也纳入观测窗口
  node_ptr->declare_parameter(plugin_name_ + ".fov_half_angle", fov_half_angle_);
  node_ptr->get_parameter(plugin_name_ + ".fov_half_angle", fov_half_angle_);
  node_ptr->declare_parameter(plugin_name_ + ".fov_range", fov_range_);
  node_ptr->get_parameter(plugin_name_ + ".fov_range", fov_range_);

  node_ptr->declare_parameter(plugin_name_ + ".footprint_front", footprint_front_);
  node_ptr->get_parameter(plugin_name_ + ".footprint_front", footprint_front_);
  node_ptr->declare_parameter(plugin_name_ + ".footprint_back", footprint_back_);
  node_ptr->get_parameter(plugin_name_ + ".footprint_back", footprint_back_);
  node_ptr->declare_parameter(plugin_name_ + ".footprint_left", footprint_left_);
  node_ptr->get_parameter(plugin_name_ + ".footprint_left", footprint_left_);
  node_ptr->declare_parameter(plugin_name_ + ".footprint_right", footprint_right_);
  node_ptr->get_parameter(plugin_name_ + ".footprint_right", footprint_right_);

  // 核心 MPPI 参数
  node_ptr->declare_parameter(plugin_name_ + ".num_samples", num_samples_);
  node_ptr->get_parameter(plugin_name_ + ".num_samples", num_samples_);

  node_ptr->declare_parameter(plugin_name_ + ".prediction_horizon", prediction_horizon_);
  node_ptr->get_parameter(plugin_name_ + ".prediction_horizon", prediction_horizon_);

  node_ptr->declare_parameter(plugin_name_ + ".dt", dt_);
  node_ptr->get_parameter(plugin_name_ + ".dt", dt_);

  node_ptr->declare_parameter(plugin_name_ + ".max_v", max_v_);
  node_ptr->get_parameter(plugin_name_ + ".max_v", max_v_);

  node_ptr->declare_parameter(plugin_name_ + ".min_v", min_v_);
  node_ptr->get_parameter(plugin_name_ + ".min_v", min_v_);

  node_ptr->declare_parameter(plugin_name_ + ".max_vy", max_vy_);
  node_ptr->get_parameter(plugin_name_ + ".max_vy", max_vy_);

  node_ptr->declare_parameter(plugin_name_ + ".max_w", max_w_);
  node_ptr->get_parameter(plugin_name_ + ".max_w", max_w_);

  node_ptr->declare_parameter(plugin_name_ + ".action_std_v", action_std_v_);
  node_ptr->get_parameter(plugin_name_ + ".action_std_v", action_std_v_);

  node_ptr->declare_parameter(plugin_name_ + ".action_std_vy", action_std_vy_);
  node_ptr->get_parameter(plugin_name_ + ".action_std_vy", action_std_vy_);

  node_ptr->declare_parameter(plugin_name_ + ".action_std_w", action_std_w_);
  node_ptr->get_parameter(plugin_name_ + ".action_std_w", action_std_w_);

  node_ptr->declare_parameter(plugin_name_ + ".lambda", lambda_);
  node_ptr->get_parameter(plugin_name_ + ".lambda", lambda_);

  node_ptr->declare_parameter(plugin_name_ + ".collision_cost", costmap_weight_);
  node_ptr->get_parameter(plugin_name_ + ".collision_cost", costmap_weight_);

  node_ptr->declare_parameter(plugin_name_ + ".enable_lateral_bias", enable_lateral_bias_);
  node_ptr->get_parameter(plugin_name_ + ".enable_lateral_bias", enable_lateral_bias_);

  vis_pub_ = node_ptr->create_publisher<visualization_msgs::msg::MarkerArray>(
    "/mppi_gpu_visualization", 10);

  optimal_vx_seq_.resize(prediction_horizon_, 0.0);
  optimal_vy_seq_.resize(prediction_horizon_, 0.0);
  optimal_omega_seq_.resize(prediction_horizon_, 0.0);

  std::random_device rd;
  generator_ = std::mt19937(rd());
  dist_vx_ = std::normal_distribution<>(0.0, action_std_v_);
  dist_vy_ = std::normal_distribution<>(0.0, action_std_vy_);
  dist_w_  = std::normal_distribution<>(0.0, action_std_w_);

  allocateGPUBuffers();

  RCLCPP_INFO(node_.lock()->get_logger(), "配置 MPPIGPUController (GPU加速) 成功！");
}

void MPPIGPUController::cleanup()
{
  RCLCPP_INFO(node_.lock()->get_logger(), "清理 MPPIGPUController");
  freeGPUBuffers();
}

void MPPIGPUController::activate()
{
  RCLCPP_INFO(node_.lock()->get_logger(), "激活 MPPIGPUController");
}

void MPPIGPUController::deactivate()
{
  RCLCPP_INFO(node_.lock()->get_logger(), "停用 MPPIGPUController");
}

void MPPIGPUController::setPlan(const nav_msgs::msg::Path & path)
{
  global_plan_ = path;
}

void MPPIGPUController::setSpeedLimit(const double &, const bool &)
{
}

geometry_msgs::msg::TwistStamped MPPIGPUController::computeVelocityCommands(
  const geometry_msgs::msg::PoseStamped & pose,
  const geometry_msgs::msg::Twist & /*current_vel*/,
  nav2_core::GoalChecker *)
{
  geometry_msgs::msg::TwistStamped cmd_vel;
  cmd_vel.header.frame_id = "BASE_LINK";
  cmd_vel.header.stamp = node_.lock()->now();

  int N = num_samples_;
  int H = prediction_horizon_;

  double current_x = pose.pose.position.x;
  double current_y = pose.pose.position.y;
  double current_theta = tf2::getYaw(pose.pose.orientation);

  // 维护近期轨迹观测窗口（位置 + 朝向，用于 FOV 视锥检查）
  TrailPose tp;
  tp.x = current_x;
  tp.y = current_y;
  tp.cos_theta = std::cos(current_theta);
  tp.sin_theta = std::sin(current_theta);
  trail_poses_.push_back(tp);
  // 清理超出观测窗口的旧轨迹点
  while (!trail_poses_.empty()) {
    size_t max_trail = static_cast<size_t>(observation_window_duration_ * 20.0);  // 20Hz
    if (trail_poses_.size() > max_trail) {
      trail_poses_.pop_front();
    } else {
      break;
    }
  }

  double target_x = current_x;
  double target_y = current_y;
  int closest_idx = 0;

  if (!global_plan_.poses.empty()) {
    double min_dist = std::numeric_limits<double>::max();

    for (size_t i = 0; i < global_plan_.poses.size(); ++i) {
      double dx = global_plan_.poses[i].pose.position.x - current_x;
      double dy = global_plan_.poses[i].pose.position.y - current_y;
      double dist = std::hypot(dx, dy);
      if (dist < min_dist) {
        min_dist = dist;
        closest_idx = static_cast<int>(i);
      }
    }

    // 前瞻点：沿路径插值取精确的 min_lookahead_dist_ 米处
    // 在路径段上线性插值，而非直接取离散路径点，避免前瞻点跳变
    int last_idx = static_cast<int>(global_plan_.poses.size()) - 1;
    double accumulated = 0.0;
    double raw_lookahead_x = target_x;
    double raw_lookahead_y = target_y;
    bool found = false;

    for (int i = closest_idx; i < last_idx; ++i) {
      double dx = global_plan_.poses[i + 1].pose.position.x
                - global_plan_.poses[i].pose.position.x;
      double dy = global_plan_.poses[i + 1].pose.position.y
                - global_plan_.poses[i].pose.position.y;
      double seg_len = std::hypot(dx, dy);

      if (accumulated + seg_len >= min_lookahead_dist_) {
        // 在当前段内线性插值，取精确的前瞻点
        double remaining = min_lookahead_dist_ - accumulated;
        double alpha = (seg_len > 1e-9) ? remaining / seg_len : 0.0;
        alpha = std::max(0.0, std::min(1.0, alpha));
        raw_lookahead_x = global_plan_.poses[i].pose.position.x + alpha * dx;
        raw_lookahead_y = global_plan_.poses[i].pose.position.y + alpha * dy;
        found = true;
        break;
      }
      accumulated += seg_len;
    }

    // 路径不够长时，退化为终点
    if (!found && last_idx >= closest_idx) {
      raw_lookahead_x = global_plan_.poses[last_idx].pose.position.x;
      raw_lookahead_y = global_plan_.poses[last_idx].pose.position.y;
    }

    // 帧间指数平滑：抑制 closest_idx 跳变或路径点稀疏引入的残余抖动
    if (has_prev_lookahead_) {
      const double SMOOTH_ALPHA = 0.35;  // 平滑系数: 0=完全锁定, 1=不平滑
      target_x = prev_lookahead_x_ + SMOOTH_ALPHA * (raw_lookahead_x - prev_lookahead_x_);
      target_y = prev_lookahead_y_ + SMOOTH_ALPHA * (raw_lookahead_y - prev_lookahead_y_);
    } else {
      target_x = raw_lookahead_x;
      target_y = raw_lookahead_y;
      has_prev_lookahead_ = true;
    }
    prev_lookahead_x_ = target_x;
    prev_lookahead_y_ = target_y;
  }

  // 局部路径方向：取 closest_idx 处的一小段，用于 guidance 和噪声对齐
  double path_direction_x = 0.0;
  double path_direction_y = 0.0;
  if (!global_plan_.poses.empty() && closest_idx + 1 < static_cast<int>(global_plan_.poses.size())) {
    path_direction_x = global_plan_.poses[closest_idx + 1].pose.position.x
                     - global_plan_.poses[closest_idx].pose.position.x;
    path_direction_y = global_plan_.poses[closest_idx + 1].pose.position.y
                     - global_plan_.poses[closest_idx].pose.position.y;
    double path_len = std::hypot(path_direction_x, path_direction_y);
    if (path_len > 0.01) {
      path_direction_x /= path_len;
      path_direction_y /= path_len;
    }
  }

  // 提取全局路径点并均匀重采样（用于 GPU 内核的 cross-track error 计算）
  std::vector<float> host_path_x, host_path_y;
  int num_path_pts = 0;

  if (!global_plan_.poses.empty() && closest_idx < static_cast<int>(global_plan_.poses.size())) {
    // 第一步：计算从 closest_idx 到末尾的累计距离
    std::vector<double> cum_dist;
    cum_dist.push_back(0.0);
    double total_dist = 0.0;

    for (int i = closest_idx + 1; i < static_cast<int>(global_plan_.poses.size()); ++i) {
      double dx = global_plan_.poses[i].pose.position.x - global_plan_.poses[i - 1].pose.position.x;
      double dy = global_plan_.poses[i].pose.position.y - global_plan_.poses[i - 1].pose.position.y;
      total_dist += std::hypot(dx, dy);
      cum_dist.push_back(total_dist);
    }

    if (total_dist > 0.05 && cum_dist.size() >= 2) {
      // 第二步：按均匀步长采样 MAX_PATH_POINTS 个点
      double sample_dist = total_dist / (MAX_PATH_POINTS - 1);
      int seg_idx = 0;  // 当前所在的路径段索引

      for (int k = 0; k < MAX_PATH_POINTS; ++k) {
        double target_dist = k * sample_dist;

        // 找到包含 target_dist 的段
        while (seg_idx + 1 < static_cast<int>(cum_dist.size()) &&
               cum_dist[seg_idx + 1] < target_dist) {
          seg_idx++;
        }

        int i0 = closest_idx + seg_idx;
        int i1 = i0 + 1;
        if (i1 >= static_cast<int>(global_plan_.poses.size())) {
          i1 = static_cast<int>(global_plan_.poses.size()) - 1;
        }

        double seg_start = cum_dist[seg_idx];
        double seg_end = (seg_idx + 1 < static_cast<int>(cum_dist.size()))
                             ? cum_dist[seg_idx + 1]
                             : total_dist;
        double seg_len = seg_end - seg_start;
        double alpha = (seg_len > 1e-9) ? (target_dist - seg_start) / seg_len : 0.0;
        alpha = std::max(0.0, std::min(1.0, alpha));

        double px = global_plan_.poses[i0].pose.position.x +
                    alpha * (global_plan_.poses[i1].pose.position.x -
                             global_plan_.poses[i0].pose.position.x);
        double py = global_plan_.poses[i0].pose.position.y +
                    alpha * (global_plan_.poses[i1].pose.position.y -
                             global_plan_.poses[i0].pose.position.y);

        host_path_x.push_back(static_cast<float>(px));
        host_path_y.push_back(static_cast<float>(py));
      }
      num_path_pts = MAX_PATH_POINTS;
    }
  }

  // 初始化或滚动最优控制序列
  if (!initialized_) {
    double dx = target_x - current_x;
    double dy = target_y - current_y;
    double angle_to_goal = std::atan2(dy, dx);
    double angle_diff = angle_to_goal - current_theta;
    while (angle_diff > M_PI) angle_diff -= 2 * M_PI;
    while (angle_diff < -M_PI) angle_diff += 2 * M_PI;

    double dist_to_goal = std::hypot(dx, dy);
    double init_vx = std::min(max_v_, dist_to_goal / dt_);
    double init_vy = 0.0;
    double init_omega = std::max(-max_w_, std::min(max_w_, angle_diff / dt_));

    for (int i = 0; i < H; ++i) {
      optimal_vx_seq_[i] = init_vx;
      optimal_vy_seq_[i] = init_vy;
      optimal_omega_seq_[i] = init_omega;
    }
    initialized_ = true;
  } else {
    for (int i = 0; i < H - 1; ++i) {
      optimal_vx_seq_[i] = optimal_vx_seq_[i + 1];
      optimal_vy_seq_[i] = optimal_vy_seq_[i + 1];
      optimal_omega_seq_[i] = optimal_omega_seq_[i + 1];
    }
    // 尾部指数衰减而非直接清零，防止 base 序列逐帧塌缩
    // 连续 H 帧清零会导致整条序列归零，轨迹失去前向引导而四散
    const double TAIL_DECAY = 0.5;
    optimal_vx_seq_.back()     = optimal_vx_seq_[H - 2] * TAIL_DECAY;
    optimal_vy_seq_.back()     = optimal_vy_seq_[H - 2] * TAIL_DECAY;
    optimal_omega_seq_.back()  = optimal_omega_seq_[H - 2] * TAIL_DECAY;
  }

  // 预生成噪声序列（CPU 端，与原始 MPPI 一致）
  size_t noise_size = N * H;
  std::vector<float> noise_vx(noise_size);
  std::vector<float> noise_vy(noise_size);
  std::vector<float> noise_w(noise_size);

  for (int i = 0; i < N * H; ++i) {
    noise_vx[i] = static_cast<float>(dist_vx_(generator_));
    noise_vy[i] = static_cast<float>(dist_vy_(generator_));
    noise_w[i]  = static_cast<float>(dist_w_(generator_));
  }

  // 转换基控制序列为 float
  std::vector<float> base_vx_f(H), base_vy_f(H), base_w_f(H);
  for (int i = 0; i < H; ++i) {
    base_vx_f[i] = static_cast<float>(optimal_vx_seq_[i]);
    base_vy_f[i] = static_cast<float>(optimal_vy_seq_[i]);
    base_w_f[i]  = static_cast<float>(optimal_omega_seq_[i]);
  }

  // 获取 costmap 数据
  const unsigned char* costmap_data = nullptr;
  int costmap_w = 0, costmap_h = 0;
  float costmap_res = 0.05f;
  float costmap_origin_x = 0.0f, costmap_origin_y = 0.0f;

  if (costmap_ros_ != nullptr) {
    nav2_costmap_2d::Costmap2D* costmap = costmap_ros_->getCostmap();
    if (costmap != nullptr) {
      costmap_data = costmap->getCharMap();
      costmap_w = static_cast<int>(costmap->getSizeInCellsX());
      costmap_h = static_cast<int>(costmap->getSizeInCellsY());
      costmap_res = static_cast<float>(costmap->getResolution());
      costmap_origin_x = static_cast<float>(costmap->getOriginX());
      costmap_origin_y = static_cast<float>(costmap->getOriginY());
    }
  }

  // 按需分配/重分配 costmap GPU 缓冲区
  if (costmap_data != nullptr && costmap_w > 0 && costmap_h > 0) {
    if (costmap_w != costmap_w_ || costmap_h != costmap_h_) {
      cudaFree(d_costmap_);
      cudaError_t err = cudaMalloc(&d_costmap_, costmap_w * costmap_h * sizeof(unsigned char));
      if (err != cudaSuccess) {
        RCLCPP_ERROR(node_.lock()->get_logger(), "cudaMalloc(costmap) 失败: %s", cudaGetErrorString(err));
        d_costmap_ = nullptr;
        costmap_w_ = 0;
        costmap_h_ = 0;
      } else {
        costmap_w_ = costmap_w;
        costmap_h_ = costmap_h;
      }
    }
  }

  // 如果没有 costmap，确保 d_costmap_ 为 nullptr（内核需检查）
  if (costmap_data == nullptr) {
    costmap_w = 0;
    costmap_h = 0;
  }

  // ── 横向偏好分析：打破对称障碍物的左右抉择困境 ──
  // 在前瞻点处沿路径法向扫描 costmap，判断哪侧空闲更多，
  // 将 path_direction 微旋向空闲侧，使 MPPI 噪声采样/guidance 偏向该侧
  // 可通过 enable_lateral_bias 参数关闭
  if (enable_lateral_bias_ && costmap_data != nullptr && costmap_w > 0 && costmap_h > 0
      && std::hypot(path_direction_x, path_direction_y) > 0.01) {
    // 路径法向（全局坐标系）：左 = +90° 旋转
    double perp_x = -path_direction_y;
    double perp_y =  path_direction_x;

    auto sample_cost = [&](double wx, double wy) -> double {
      int mx = static_cast<int>((wx - costmap_origin_x) / costmap_res);
      int my = static_cast<int>((wy - costmap_origin_y) / costmap_res);
      if (mx >= 0 && mx < costmap_w && my >= 0 && my < costmap_h) {
        return costmap_data[my * costmap_w + mx] / 255.0;  // 归一化到 [0, 1]
      }
      return 1.0;  // 越界视为障碍
    };

    // 在前瞻点处沿法向采样左右两侧 (0.3m ~ 1.8m, 步长 0.3m)
    double left_cost = 0.0, right_cost = 0.0;
    int n_samples = 0;
    for (double d = 0.3; d <= 1.8; d += 0.3) {
      left_cost  += sample_cost(target_x + d * perp_x, target_y + d * perp_y);
      right_cost += sample_cost(target_x - d * perp_x, target_y - d * perp_y);
      n_samples++;
    }
    if (n_samples > 0) {
      left_cost /= n_samples;
      right_cost /= n_samples;
    }

    double cost_diff = right_cost - left_cost;  // >0 → 左侧更空闲 → 偏好左绕
    const double HYSTERESIS_MARGIN = 0.25;       // 迟滞区间，costmap 噪声下不易翻转

    if (preferred_lateral_dir_ < -0.5) {
      // 当前偏好左绕，需要右侧显著更空闲才切换
      if (cost_diff < -HYSTERESIS_MARGIN) {
        preferred_lateral_dir_ = 1.0;
      }
    } else if (preferred_lateral_dir_ > 0.5) {
      // 当前偏好右绕，需要左侧显著更空闲才切换
      if (cost_diff > HYSTERESIS_MARGIN) {
        preferred_lateral_dir_ = -1.0;
      }
    } else {
      // 无偏好，任一方向有显著优势即采纳
      if (cost_diff > HYSTERESIS_MARGIN) {
        preferred_lateral_dir_ = -1.0;
      } else if (cost_diff < -HYSTERESIS_MARGIN) {
        preferred_lateral_dir_ = 1.0;
      }
    }

    // 若前瞻点前方空旷且两侧对称，重置偏好（已通过障碍）
    double ahead_cost = sample_cost(target_x, target_y);
    if (ahead_cost < 0.05 && std::abs(cost_diff) < 0.08) {
      preferred_lateral_dir_ = 0.0;
    }

    // 将 path_direction 向偏好侧微旋（±6°），避免过度偏转引起摆动
    if (std::abs(preferred_lateral_dir_) > 0.1) {
      const double MAX_BIAS_ANGLE = 6.0 * M_PI / 180.0;
      double bias_angle = preferred_lateral_dir_ * MAX_BIAS_ANGLE;
      double cos_ba = std::cos(bias_angle);
      double sin_ba = std::sin(bias_angle);
      double biased_x = path_direction_x * cos_ba - path_direction_y * sin_ba;
      double biased_y = path_direction_x * sin_ba + path_direction_y * cos_ba;
      path_direction_x = biased_x;
      path_direction_y = biased_y;
    }
  }

  // 准备近期轨迹数据 (观测窗口：位置 + 朝向，用于 FOV 视锥检查)
  std::vector<float> trail_x, trail_y, trail_cos, trail_sin;
  int trail_count = static_cast<int>(trail_poses_.size());
  if (trail_count > MAX_TRAIL_POINTS) {
    // 超出最大容量时均匀降采样
    float step = static_cast<float>(trail_count) / static_cast<float>(MAX_TRAIL_POINTS);
    for (int i = 0; i < MAX_TRAIL_POINTS; ++i) {
      int idx = static_cast<int>(i * step);
      trail_x.push_back(static_cast<float>(trail_poses_[idx].x));
      trail_y.push_back(static_cast<float>(trail_poses_[idx].y));
      trail_cos.push_back(static_cast<float>(trail_poses_[idx].cos_theta));
      trail_sin.push_back(static_cast<float>(trail_poses_[idx].sin_theta));
    }
    trail_count = MAX_TRAIL_POINTS;
  } else {
    for (const auto& tp : trail_poses_) {
      trail_x.push_back(static_cast<float>(tp.x));
      trail_y.push_back(static_cast<float>(tp.y));
      trail_cos.push_back(static_cast<float>(tp.cos_theta));
      trail_sin.push_back(static_cast<float>(tp.sin_theta));
    }
  }
  float trust_radius_sq = static_cast<float>(trust_radius_ * trust_radius_);
  float fov_range_sq = static_cast<float>(fov_range_ * fov_range_);
  float fov_cos_half = std::cos(fov_half_angle_ * M_PI / 180.0);

  // 创建 CUDA stream
  cudaStream_t stream;
  cudaStreamCreate(&stream);

  // GPU 采样 + 代价计算
  int ret = mppi_gpu_sample_and_cost(
      noise_vx.data(), noise_vy.data(), noise_w.data(),
      base_vx_f.data(), base_vy_f.data(), base_w_f.data(),
      static_cast<float>(current_x), static_cast<float>(current_y), static_cast<float>(current_theta),
      static_cast<float>(target_x), static_cast<float>(target_y),
      costmap_data,
      costmap_w, costmap_h,
      costmap_res, costmap_origin_x, costmap_origin_y,
      static_cast<float>(dt_), static_cast<float>(min_v_), static_cast<float>(max_v_), static_cast<float>(max_vy_), static_cast<float>(max_w_),
      static_cast<float>(costmap_weight_),
      static_cast<float>(path_direction_x), static_cast<float>(path_direction_y),
      static_cast<float>(guidance_weight_),
      static_cast<float>(cross_track_noise_scale_),
      static_cast<float>(noise_decay_rate_),
      static_cast<float>(vel_direction_weight_),
      static_cast<float>(speed_reward_weight_),
      static_cast<float>(heading_weight_),
      static_cast<float>(lateral_guidance_scale_),
      static_cast<float>(unknown_cost_rear_),
      static_cast<float>(unknown_cost_side_),
      static_cast<float>(unknown_cost_front_),
      trail_x.data(), trail_y.data(),
      trail_cos.data(), trail_sin.data(),
      trail_count,
      trust_radius_sq,
      fov_range_sq,
      fov_cos_half,
      static_cast<float>(observed_area_cost_scale_),
      static_cast<float>(footprint_front_), static_cast<float>(footprint_back_),
      static_cast<float>(footprint_left_), static_cast<float>(footprint_right_),
      host_path_x.data(), host_path_y.data(),
      num_path_pts,
      static_cast<float>(path_attraction_weight_),
      N, H,
      d_noise_vx_, d_noise_vy_, d_noise_w_,
      d_base_vx_, d_base_vy_, d_base_w_,
      d_costmap_,
      d_path_x_, d_path_y_,
      d_trail_x_, d_trail_y_,
      d_trail_cos_, d_trail_sin_,
      d_costs_, d_sampled_vx_, d_sampled_vy_, d_sampled_w_,
      d_traj_x_, d_traj_y_,
      stream);

  if (ret != 0) {
    RCLCPP_ERROR(node_.lock()->get_logger(), "GPU 采样核函数失败，错误码: %d", ret);
    cudaStreamDestroy(stream);
    cmd_vel.twist.linear.x = 0.0;
    cmd_vel.twist.linear.y = 0.0;
    cmd_vel.twist.angular.z = 0.0;
    return cmd_vel;
  }

  // 拷贝代价回 CPU 以查找最小值
  std::vector<float> host_costs(N);
  cudaMemcpyAsync(host_costs.data(), d_costs_, N * sizeof(float), cudaMemcpyDeviceToHost, stream);
  cudaError_t sync_err = cudaStreamSynchronize(stream);
  if (sync_err != cudaSuccess) {
    RCLCPP_ERROR(node_.lock()->get_logger(),
      "cudaStreamSynchronize 失败 (代价拷贝): %s", cudaGetErrorString(sync_err));
    cudaStreamDestroy(stream);
    cmd_vel.twist.linear.x = 0.0;
    cmd_vel.twist.linear.y = 0.0;
    cmd_vel.twist.angular.z = 0.0;
    return cmd_vel;
  }

  float min_cost = std::numeric_limits<float>::max();
  int best_idx = 0;
  for (int i = 0; i < N; ++i) {
    if (host_costs[i] < min_cost) {
      min_cost = host_costs[i];
      best_idx = i;
    }
  }

  // GPU 加权求和 —— 对全部 H 个 timestep 独立计算
  ret = mppi_gpu_weighted_sum(
      d_costs_, d_sampled_vx_, d_sampled_vy_, d_sampled_w_,
      d_result_seq_,
      min_cost,
      static_cast<float>(lambda_),
      N, H,
      stream);

  if (ret != 0) {
    RCLCPP_ERROR(node_.lock()->get_logger(), "GPU 加权求和核函数失败，错误码: %d", ret);
    cudaStreamDestroy(stream);
    cmd_vel.twist.linear.x = 0.0;
    cmd_vel.twist.linear.y = 0.0;
    cmd_vel.twist.angular.z = 0.0;
    return cmd_vel;
  }

  // 拷贝全时域加权结果回 CPU（H × 4 个 float）
  std::vector<float> host_result_seq(H * 4);
  cudaMemcpyAsync(host_result_seq.data(), d_result_seq_, H * 4 * sizeof(float),
                  cudaMemcpyDeviceToHost, stream);
  sync_err = cudaStreamSynchronize(stream);
  if (sync_err != cudaSuccess) {
    RCLCPP_ERROR(node_.lock()->get_logger(),
      "cudaStreamSynchronize 失败 (结果拷贝): %s", cudaGetErrorString(sync_err));
    cudaStreamDestroy(stream);
    cmd_vel.twist.linear.x = 0.0;
    cmd_vel.twist.linear.y = 0.0;
    cmd_vel.twist.angular.z = 0.0;
    return cmd_vel;
  }

  // 解析全时域加权结果: u*_t = Σ w_k · sampled_u[k,t] / Σ w_k
  std::vector<double> u_star_vx(H, 0.0);
  std::vector<double> u_star_vy(H, 0.0);
  std::vector<double> u_star_w(H, 0.0);

  for (int t = 0; t < H; ++t) {
    float sum_w = host_result_seq[t * 4 + 3];
    if (sum_w > 1e-6f) {
      u_star_vx[t] = static_cast<double>(host_result_seq[t * 4 + 0] / sum_w);
      u_star_vy[t] = static_cast<double>(host_result_seq[t * 4 + 1] / sum_w);
      u_star_w[t]  = static_cast<double>(host_result_seq[t * 4 + 2] / sum_w);
    }
  }

  // 当前执行的控制量 = 优化序列的第一步 u*[0]
  double best_vx = u_star_vx[0];
  double best_vy = u_star_vy[0];
  double best_omega = u_star_w[0];

  // Clamp
  best_vx = std::max(min_v_, std::min(max_v_, best_vx));
  best_vy = std::max(-max_vy_, std::min(max_vy_, best_vy));
  best_omega = std::max(-max_w_, std::min(max_w_, best_omega));

  // ── 输出 EMA 低通滤波：抑制帧间控制量跳变 ──
  // ema = α·current + (1-α)·prev
  // α=0: 完全冻结, α=1: 无平滑 (raw MPPI)
  if (!ema_initialized_) {
    ema_cmd_vx_ = best_vx;
    ema_cmd_vy_ = best_vy;
    ema_cmd_w_  = best_omega;
    ema_initialized_ = true;
  } else {
    ema_cmd_vx_ = ema_alpha_ * best_vx + (1.0 - ema_alpha_) * ema_cmd_vx_;
    ema_cmd_vy_ = ema_alpha_ * best_vy + (1.0 - ema_alpha_) * ema_cmd_vy_;
    ema_cmd_w_  = ema_alpha_ * best_omega + (1.0 - ema_alpha_) * ema_cmd_w_;
  }
  best_vx = ema_cmd_vx_;
  best_vy = ema_cmd_vy_;
  best_omega = ema_cmd_w_;

  // MPPI 滚动优化：直接存储当前帧的全时域最优序列 u*
  // 下一帧开头会执行一次移位 (optimal[i] = optimal[i+1]) 将时间对齐到新时刻。
  // 此处不再移位，避免与开头的移位叠加形成"双重移位"导致 u*[1] 被跳过。
  for (int i = 0; i < H; ++i) {
    optimal_vx_seq_[i] = u_star_vx[i];
    optimal_vy_seq_[i] = u_star_vy[i];
    optimal_omega_seq_[i] = u_star_w[i];
  }

  // 最小输出阈值
  double min_output = 0.01;
  if (std::abs(best_vx) < min_output && std::abs(best_vy) < min_output && std::abs(best_omega) < min_output) {
    double dx = target_x - current_x;
    double dy = target_y - current_y;
    double angle_to_goal = std::atan2(dy, dx);
    double angle_diff = angle_to_goal - current_theta;
    while (angle_diff > M_PI) angle_diff -= 2 * M_PI;
    while (angle_diff < -M_PI) angle_diff += 2 * M_PI;
    best_vx = 0.3;
    best_omega = angle_diff * 0.5;
  }

  cmd_vel.twist.linear.x = best_vx;
  cmd_vel.twist.linear.y = best_vy;
  cmd_vel.twist.angular.z = best_omega;

  // 可视化：挑选代价最低的 10 条轨迹，从 GPU 拷贝
  const int TOP_K = 10;

  // 找出代价最低的 TOP_K 个索引
  std::vector<int> top_indices;
  {
    std::vector<std::pair<float, int>> cost_idx_pairs;
    cost_idx_pairs.reserve(N);
    for (int i = 0; i < N; ++i) {
      cost_idx_pairs.emplace_back(host_costs[i], i);
    }
    int n_select = std::min(TOP_K, N);
    std::partial_sort(cost_idx_pairs.begin(),
                      cost_idx_pairs.begin() + n_select,
                      cost_idx_pairs.end());
    for (int k = 0; k < n_select; ++k) {
      top_indices.push_back(cost_idx_pairs[k].second);
    }
  }

  int vis_samples = static_cast<int>(top_indices.size());
  std::vector<float> vis_traj_x(vis_samples * H);
  std::vector<float> vis_traj_y(vis_samples * H);

  // 按索引逐条拷贝（同一 stream 保证顺序）
  for (int k = 0; k < vis_samples; ++k) {
    int idx = top_indices[k];
    cudaMemcpyAsync(vis_traj_x.data() + k * H, d_traj_x_ + idx * H,
                    H * sizeof(float), cudaMemcpyDeviceToHost, stream);
    cudaMemcpyAsync(vis_traj_y.data() + k * H, d_traj_y_ + idx * H,
                    H * sizeof(float), cudaMemcpyDeviceToHost, stream);
  }

  // 最后一次同步：确保所有 stream 操作（含可视数据拷贝）完成
  cudaError_t vis_sync_err = cudaStreamSynchronize(stream);
  cudaStreamDestroy(stream);

  if (vis_sync_err != cudaSuccess) {
    RCLCPP_ERROR(node_.lock()->get_logger(),
      "cudaStreamSynchronize 失败 (vis): %s", cudaGetErrorString(vis_sync_err));
  }

  // top_indices[0] 代价最低，为最优轨迹（绿色），其余按代价升序排列
  int vis_best_idx = 0;

  publishVisualization(current_x, current_y, current_theta,
                       target_x, target_y,
                       vis_traj_x, vis_traj_y,
                       vis_samples, vis_best_idx,
                       pose.header.frame_id);

  return cmd_vel;
}

void MPPIGPUController::publishVisualization(
  double robot_x, double robot_y, double robot_theta,
  double target_x, double target_y,
  const std::vector<float>& traj_data_x,
  const std::vector<float>& traj_data_y,
  int vis_samples,
  int best_idx,
  const std::string& frame_id)
{
  auto node_ptr = node_.lock();
  if (!node_ptr || !vis_pub_) return;

  int H = prediction_horizon_;

  visualization_msgs::msg::MarkerArray marker_array;
  rclcpp::Time now = node_ptr->now();
  // 设置生命周期为控制器周期的 2 倍，确保每帧刷新、旧 marker 自动过期
  auto marker_lifetime = rclcpp::Duration::from_seconds(0.1);

  // 机器人位置（红色）
  {
    visualization_msgs::msg::Marker m;
    m.header.frame_id = frame_id;
    m.header.stamp = now;
    m.ns = "mppi_gpu";
    m.id = 0;
    m.type = visualization_msgs::msg::Marker::SPHERE;
    m.action = visualization_msgs::msg::Marker::ADD;
    m.lifetime = marker_lifetime;
    m.pose.position.x = robot_x;
    m.pose.position.y = robot_y;
    m.pose.position.z = 0.1;
    m.scale.x = 0.3;
    m.scale.y = 0.3;
    m.scale.z = 0.3;
    m.color.r = 1.0;
    m.color.g = 0.0;
    m.color.b = 0.0;
    m.color.a = 1.0;
    marker_array.markers.push_back(m);
  }

  // 目标点（绿色）
  {
    visualization_msgs::msg::Marker m;
    m.header.frame_id = frame_id;
    m.header.stamp = now;
    m.ns = "mppi_gpu";
    m.id = 1;
    m.type = visualization_msgs::msg::Marker::SPHERE;
    m.action = visualization_msgs::msg::Marker::ADD;
    m.lifetime = marker_lifetime;
    m.pose.position.x = target_x;
    m.pose.position.y = target_y;
    m.pose.position.z = 0.1;
    m.scale.x = 0.4;
    m.scale.y = 0.4;
    m.scale.z = 0.4;
    m.color.r = 0.0;
    m.color.g = 1.0;
    m.color.b = 0.0;
    m.color.a = 1.0;
    marker_array.markers.push_back(m);
  }

  // 机器人朝向（黄色箭头）
  {
    visualization_msgs::msg::Marker m;
    m.header.frame_id = frame_id;
    m.header.stamp = now;
    m.ns = "mppi_gpu";
    m.id = 2;
    m.type = visualization_msgs::msg::Marker::LINE_STRIP;
    m.action = visualization_msgs::msg::Marker::ADD;
    m.lifetime = marker_lifetime;
    m.points.resize(2);
    m.points[0].x = robot_x;
    m.points[0].y = robot_y;
    m.points[0].z = 0.15;
    m.points[1].x = robot_x + std::cos(robot_theta) * 0.8;
    m.points[1].y = robot_y + std::sin(robot_theta) * 0.8;
    m.points[1].z = 0.15;
    m.scale.x = 0.08;
    m.color.r = 1.0;
    m.color.g = 1.0;
    m.color.b = 0.0;
    m.color.a = 1.0;
    marker_array.markers.push_back(m);
  }

  // 采样轨迹
  for (int i = 0; i < vis_samples; ++i) {
    visualization_msgs::msg::Marker m;
    m.header.frame_id = frame_id;
    m.header.stamp = now;
    m.ns = "samples_gpu";
    m.id = i;
    m.type = visualization_msgs::msg::Marker::LINE_STRIP;
    m.action = visualization_msgs::msg::Marker::ADD;
    m.lifetime = marker_lifetime;

    // 起点：机器人当前位置（轨迹从这里开始）
    {
      geometry_msgs::msg::Point p;
      p.x = robot_x;
      p.y = robot_y;
      p.z = 0.05;
      m.points.push_back(p);
    }

    // GPU 预测的 H 步位置，到达目标附近时截断
    const float GOAL_REACHED_DIST = 0.25f;
    for (int t = 0; t < H; ++t) {
      float px = traj_data_x[i * H + t];
      float py = traj_data_y[i * H + t];
      geometry_msgs::msg::Point p;
      p.x = px;
      p.y = py;
      p.z = 0.05;
      m.points.push_back(p);
      float dx_g = static_cast<float>(target_x) - px;
      float dy_g = static_cast<float>(target_y) - py;
      if (std::hypot(dx_g, dy_g) < GOAL_REACHED_DIST) break;
    }

    if (i == best_idx) {
      m.color.r = 0.0;
      m.color.g = 1.0;
      m.color.b = 0.0;
      m.color.a = 0.8;
      m.scale.x = 0.06;
    } else {
      m.color.r = 0.7;
      m.color.g = 0.7;
      m.color.b = 0.7;
      m.color.a = 0.5;
      m.scale.x = 0.04;
    }
    marker_array.markers.push_back(m);
  }

  vis_pub_->publish(marker_array);
}

}  // namespace nav2_custom_plugins

PLUGINLIB_EXPORT_CLASS(nav2_custom_plugins::MPPIGPUController, nav2_core::Controller)
