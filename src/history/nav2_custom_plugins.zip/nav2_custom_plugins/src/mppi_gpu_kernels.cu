#include <cuda_runtime.h>
#include <cmath>
#include <cfloat>

// 点到线段的最短距离平方（GPU device 函数）
// 用于计算轨迹点偏离全局路径的 cross-track error
__device__ float point_to_segment_dist_sq(
    float px, float py,
    float ax, float ay,
    float bx, float by)
{
  float abx = bx - ax;
  float aby = by - ay;
  float apx = px - ax;
  float apy = py - ay;
  float ab_len_sq = abx * abx + aby * aby;

  // 线段退化为点
  if (ab_len_sq < 1e-8f) {
    return apx * apx + apy * apy;
  }

  // 投影参数 t，clamp 到 [0, 1]
  float t = (apx * abx + apy * aby) / ab_len_sq;
  t = fmaxf(0.0f, fminf(1.0f, t));

  float closest_x = ax + t * abx;
  float closest_y = ay + t * aby;
  float dx = px - closest_x;
  float dy = py - closest_y;
  return dx * dx + dy * dy;
}

// 代价地图双线性插值（GPU device 函数）
// 消除栅格边界处的代价跳变，返回连续值 [0, 255]
// 越界点返回 255（未知），与原始行为一致
__device__ float costmap_bilinear(
    float wx, float wy,
    const unsigned char* __restrict__ costmap,
    int costmap_w, int costmap_h,
    float costmap_res, float costmap_origin_x, float costmap_origin_y)
{
  // 连续坐标：cell i 的中心位于 (i + 0.5) * res + origin
  float fx = (wx - costmap_origin_x) / costmap_res - 0.5f;
  float fy = (wy - costmap_origin_y) / costmap_res - 0.5f;

  int mx0 = static_cast<int>(floorf(fx));
  int my0 = static_cast<int>(floorf(fy));
  int mx1 = mx0 + 1;
  int my1 = my0 + 1;

  float wx_frac = fx - static_cast<float>(mx0);
  float wy_frac = fy - static_cast<float>(my0);

  // 四个邻居，越界 → 255
  float c00 = (mx0 >= 0 && mx0 < costmap_w && my0 >= 0 && my0 < costmap_h)
      ? static_cast<float>(costmap[my0 * costmap_w + mx0]) : 255.0f;
  float c10 = (mx1 >= 0 && mx1 < costmap_w && my0 >= 0 && my0 < costmap_h)
      ? static_cast<float>(costmap[my0 * costmap_w + mx1]) : 255.0f;
  float c01 = (mx0 >= 0 && mx0 < costmap_w && my1 >= 0 && my1 < costmap_h)
      ? static_cast<float>(costmap[my1 * costmap_w + mx0]) : 255.0f;
  float c11 = (mx1 >= 0 && mx1 < costmap_w && my1 >= 0 && my1 < costmap_h)
      ? static_cast<float>(costmap[my1 * costmap_w + mx1]) : 255.0f;

  float c0 = c00 + (c10 - c00) * wx_frac;
  float c1 = c01 + (c11 - c01) * wx_frac;
  return c0 + (c1 - c0) * wy_frac;
}

// MPPI 轨迹滚动与代价计算核函数
// 每个 CUDA 线程处理一条完整的采样轨迹（horizon 步前向预测）
// 存储所有 H 步的实际控制量（含 guidance + clamp），用于后续全序列加权
__global__ void mppi_sample_kernel(
    const float* __restrict__ noise_vx,
    const float* __restrict__ noise_vy,
    const float* __restrict__ noise_w,
    const float* __restrict__ base_vx,
    const float* __restrict__ base_vy,
    const float* __restrict__ base_w,
    float current_x, float current_y, float current_theta,
    float target_x, float target_y,
    const unsigned char* __restrict__ costmap,
    int costmap_w, int costmap_h,
    float costmap_res, float costmap_origin_x, float costmap_origin_y,
    float dt, float min_v, float max_v, float max_vy, float max_w,
    float costmap_weight,
    float path_dir_x, float path_dir_y,
    float guidance_weight,
    float cross_track_noise_scale,
    float noise_decay_rate,
    float vel_direction_weight,
    float speed_reward_weight,
    float heading_weight,
    float lateral_guidance_scale,
    float unknown_cost_rear,
    float unknown_cost_side,
    float unknown_cost_front,
    const float* __restrict__ trail_x,
    const float* __restrict__ trail_y,
    const float* __restrict__ trail_cos,
    const float* __restrict__ trail_sin,
    int trail_count,
    float trust_radius_sq,
    float fov_range_sq,
    float fov_cos_half,
    float observed_area_cost_scale,
    float fp_front, float fp_back, float fp_left, float fp_right,
    const float* __restrict__ path_x,
    const float* __restrict__ path_y,
    int num_path_pts,
    float path_attraction_weight,
    int num_samples, int horizon,
    float* __restrict__ costs,
    float* __restrict__ sampled_vx,
    float* __restrict__ sampled_vy,
    float* __restrict__ sampled_w,
    float* __restrict__ traj_x,
    float* __restrict__ traj_y)
{
  int s = blockIdx.x * blockDim.x + threadIdx.x;
  if (s >= num_samples) return;

  float cos_rot = cosf(-current_theta);
  float sin_rot = sinf(-current_theta);
  float path_vx_robot = path_dir_x * cos_rot - path_dir_y * sin_rot;
  float path_vy_robot = path_dir_x * sin_rot + path_dir_y * cos_rot;

  // 路径方向与机器人朝向的夹角，用于 omega guidance
  float path_angle_error = atan2f(path_vy_robot, path_vx_robot);

  float x = current_x;
  float y = current_y;
  float theta = current_theta;

  float cost = 0.0f;
  float prev_x = x, prev_y = y;

  const float path_cost_weight = 0.2f;
  const float dist_weight = 1.0f;
  const float len_weight = 0.02f;

  for (int t = 0; t < horizon; ++t) {
    int idx = s * horizon + t;

    float base_vx_t = base_vx[t];
    float base_vy_t = base_vy[t];
    float base_w_t = base_w[t];

    float base_speed = hypotf(base_vx_t, base_vy_t);
    // 保底速度幅值：即使 base 归零，采样也不退化
    float base_speed_clamped = fmaxf(base_speed, 0.18f * max_v);

    // ── 时变噪声缩放 ──
    float progress_t = static_cast<float>(t) / fmaxf(1.0f, static_cast<float>(horizon - 1));
    float noise_scale_t = 1.0f - noise_decay_rate * progress_t;
    noise_scale_t = fmaxf(0.15f, noise_scale_t);

    // ── 渐进路径吸引（仅用于代价函数，不改变采样中心）──
    float path_follow_scale = 1.0f + progress_t * 1.2f;
    float path_attract_t    = path_attraction_weight * path_follow_scale;

    // ══════════════════════════════════════════════════════════
    // 核心设计：以上一阶段最优控制序列 (base) 为采样中心
    //
    // base_vx/vy/w 是上一帧 GPU 加权最优序列 shift 而来，
    // 保留了完整的时序信息。本帧在此中心周围加控制噪声采样，
    // 路径方向仅作为软引导（guidance），不再替代采样中心。
    //
    // guidance_weight 混合比 (建议 γ ≈ 0.2~0.4):
    //   γ → 0: 完全信任 base + 噪声 (时序最平滑，帧间一致)
    //   γ → 1: 完全锚定路径方向 (退化为旧行为，帧间离散跳变)
    //
    // 噪声语义: 控制空间 (m/s, rad/s)，与 CPU 端高斯采样一致
    // ══════════════════════════════════════════════════════════

    float noise_vx_s = noise_vx[idx] * noise_scale_t;
    float noise_vy_s = noise_vy[idx] * noise_scale_t;
    float noise_w_s  = noise_w[idx] * noise_scale_t;

    // vx: base + 控制噪声 (主体) 与 path_dir × speed (软引导) 混合
    float vx = (1.0f - guidance_weight) * (base_vx_t + noise_vx_s)
             + guidance_weight * path_vx_robot * base_speed_clamped;

    // vy: base + 控制噪声 (主体) 与 path_dir × speed (软引导) 混合
    //     横向受 lateral_guidance_scale 和 cross_track_noise_scale 双重抑制
    float vy = (1.0f - guidance_weight) * (base_vy_t + noise_vy_s * cross_track_noise_scale)
             + guidance_weight * path_vy_robot * base_speed_clamped * lateral_guidance_scale;

    // omega: base 为采样中心 + 噪声 + 弱路径朝向修正
    //        路径修正项仅在 guidance 较强时生效，避免 base 累积偏移
    float omega = base_w_t + noise_w_s
                + path_angle_error * (0.5f / dt) * guidance_weight;

    vx = fminf(max_v, fmaxf(min_v, vx));
    vy = fminf(max_vy, fmaxf(-max_vy, vy));
    omega = fminf(max_w, fmaxf(-max_w, omega));

    // ── 末端角速度阻尼 ──
    float dist_to_target = sqrtf((target_x - x) * (target_x - x) + (target_y - y) * (target_y - y));
    const float OMEGA_DAMP_DIST = 1.5f;
    const float OMEGA_DAMP_FLOOR = 0.06f;
    if (dist_to_target < OMEGA_DAMP_DIST) {
      float damp = dist_to_target / OMEGA_DAMP_DIST;
      damp = fmaxf(OMEGA_DAMP_FLOOR, damp);
      omega *= damp;
    }

    // ── 平滑目标到达阻尼 ──
    // 替换原来的硬截断 (GOAL_REACHED_DIST=0.25m break)：
    // 在目标 0.4m 内平滑降低控制量 → 零，避免终点附近代价跳变。
    // sqrt 曲线保证靠近目标时减速更平缓 (ease-out)。
    const float GOAL_SOFT_RADIUS = 0.4f;
    if (dist_to_target < GOAL_SOFT_RADIUS) {
      float arrival = dist_to_target / GOAL_SOFT_RADIUS;
      arrival = sqrtf(arrival);
      vx *= arrival;
      vy *= arrival;
      omega *= arrival;
    }

    // 存储每步的实际控制量
    sampled_vx[idx] = vx;
    sampled_vy[idx] = vy;
    sampled_w[idx]  = omega;

    // ── 中点法 (RK2) 运动学积分 ──
    // 欧拉法用步长起点的朝向计算整步位移，在大 ω 或 vy 下会
    // 产生抛物线式累积误差（"甩尾"）。中点法先推进半步得到中间
    // 朝向 θ_mid，再用 θ_mid 计算整步的 x/y 位移，二阶精度。
    float dx1 = vx * cosf(theta) - vy * sinf(theta);
    float dy1 = vx * sinf(theta) + vy * cosf(theta);
    float dtheta1 = omega;

    float half_dt = 0.5f * dt;
    float theta_mid = theta + dtheta1 * half_dt;

    float dx2 = vx * cosf(theta_mid) - vy * sinf(theta_mid);
    float dy2 = vx * sinf(theta_mid) + vy * cosf(theta_mid);
    float dtheta2 = omega;

    float new_x = x + dx2 * dt;
    float new_y = y + dy2 * dt;
    float new_theta = theta + dtheta2 * dt;

    x = new_x;
    y = new_y;
    theta = new_theta;

    if (traj_x != nullptr && traj_y != nullptr) {
      traj_x[idx] = x;
      traj_y[idx] = y;
    }

    // ⓪ 速度奖励：鼓励沿路径方向快速前进（负代价 = 奖励）
    // 只奖励沿路径方向的速度分量，不奖励横向/后退
    float speed_along_path = vx * path_vx_robot + vy * path_vy_robot;
    cost -= fmaxf(0.0f, speed_along_path) * speed_reward_weight
            / static_cast<float>(horizon);

    // ① 目标点渐进吸引：越靠近终点、越后期，代价越高
    float dx = target_x - x;
    float dy = target_y - y;
    float dist = sqrtf(dx * dx + dy * dy);
    float progress = static_cast<float>(t) / static_cast<float>(horizon);
    cost += dist * (1.0f - progress) * path_cost_weight;

    // ── 路径信任走廊：平滑过渡，消除二值悬崖 ──
    // 计算轨迹点到全局路径的最短距离（一次计算，两处复用）
    float traj_to_path_sq = FLT_MAX;
    if (num_path_pts >= 2) {
      for (int p = 0; p < num_path_pts - 1; ++p) {
        float d_sq = point_to_segment_dist_sq(
            x, y, path_x[p], path_y[p], path_x[p + 1], path_y[p + 1]);
        if (d_sq < traj_to_path_sq) traj_to_path_sq = d_sq;
      }
    }
    float path_trust_hw = fmaxf(fp_left, fp_right) + 0.1f;
    // 平滑信任系数: 走廊中心 ≈1.0, 边界 ≈0.5, 外部迅速衰减 → 0
    // corridor_trust → 1.0 深色走廊内（未知可信），→ 0 远离路径（不可信）
    float corridor_ratio = sqrtf(traj_to_path_sq) / fmaxf(path_trust_hw, 0.01f);
    float corridor_trust = 1.0f / (1.0f + corridor_ratio * corridor_ratio * corridor_ratio * 15.0f);

    // ── 观测窗口：连续置信度替代二值开关 ──
    // trail_confidence ∈ [0, 1]: 0 = 未被观测过, 1 = 机器人刚经过此处
    float cos_theta = cosf(theta);
    float sin_theta = sinf(theta);

    float fp_lx[8] = { fp_front,  fp_front, -fp_back,  -fp_back,
                        fp_front, -fp_back,  0.0f,      0.0f};
    float fp_ly[8] = { fp_left, -fp_right,  fp_left, -fp_right,
                        0.0f,     0.0f,     fp_left, -fp_right};

    float trail_confidence = 0.0f;
    if (trail_count > 0 && trail_x != nullptr && trail_y != nullptr) {
      for (int tr = 0; tr < trail_count; ++tr) {
        float tdx = x - trail_x[tr];
        float tdy = y - trail_y[tr];
        float dist_sq = tdx * tdx + tdy * tdy;

        // ① 距离置信度：越靠近历史轨迹点置信度越高
        if (dist_sq < trust_radius_sq) {
          float ratio = dist_sq / trust_radius_sq;
          float conf = 1.0f - ratio * ratio;  // 二次衰减，中心 1.0 → 边界 0.0
          if (conf > trail_confidence) trail_confidence = conf;
        }

        // ② 视锥置信度：结合距离 + 角度连续衰减
        if (dist_sq < fov_range_sq && trail_cos != nullptr && trail_sin != nullptr) {
          float forward_dot = tdx * trail_cos[tr] + tdy * trail_sin[tr];
          if (forward_dot > 0.0f) {
            float dist_f = sqrtf(dist_sq);
            float cos_angle = forward_dot / dist_f;
            // 角度: cos_angle ∈ [fov_cos_half, 1] → ang_conf ∈ [0, 1]
            float ang_conf = (cos_angle - fov_cos_half) / (1.0f - fov_cos_half);
            ang_conf = fmaxf(0.0f, ang_conf);
            // 距离: dist_sq ∈ [0, fov_range_sq] → dist_conf ∈ [1, 0]
            float dist_conf = 1.0f - dist_sq / fov_range_sq;
            float conf = ang_conf * ang_conf * dist_conf;  // 角度平方 + 距离线性
            if (conf > trail_confidence) trail_confidence = conf;
          }
        }
      }
    }

    // ── 代价地图碰撞/膨胀惩罚（双线性插值 + 平滑已知/未知过渡）──
    // 消除栅格边界悬崖 (#4) 与已知/未知公式不一致悬崖 (#5)
    float max_known_cost = 0.0f;
    float unknown_rear_penalty = 0.0f;
    float unknown_side_penalty = 0.0f;
    float unknown_front_penalty = 0.0f;

    for (int fp = 0; fp < 8; ++fp) {
      float fp_wx = x + fp_lx[fp] * cos_theta - fp_ly[fp] * sin_theta;
      float fp_wy = y + fp_lx[fp] * sin_theta + fp_ly[fp] * cos_theta;

      // 双线性插值：连续代价 [0, 255]，跨栅格边界平滑
      float cell_val = costmap_bilinear(fp_wx, fp_wy, costmap,
                                        costmap_w, costmap_h,
                                        costmap_res, costmap_origin_x, costmap_origin_y);

      // 已知/未知连续过渡: cell_val ∈ [254, 255] → frac_raw ∈ [0, 1]
      float unknown_frac_raw = fmaxf(0.0f, (cell_val - 254.0f));
      float known_frac = 1.0f - unknown_frac_raw;

      // 已知分量: 仅 cell_val 中真正已知的部分 (≤254)，不受 corridor 影响
      float effective_known = cell_val * known_frac;
      if (effective_known > max_known_cost) max_known_cost = effective_known;

      // 未知分量: 走廊信任折扣（深走廊内未知→可通行，远离→全额惩罚）
      float effective_unknown = unknown_frac_raw * (1.0f - corridor_trust);

      // 按足迹点方向分级累积
      if (effective_unknown > 0.001f) {
        if (fp_lx[fp] > 0.01f) {
          unknown_front_penalty += effective_unknown;
        } else if (fp_lx[fp] < -0.01f) {
          unknown_rear_penalty += effective_unknown;
        } else {
          unknown_side_penalty += effective_unknown;
        }
      }
    }

    // 已知障碍物代价 (平方归一化，保持对高代价栅格的敏感性)
    if (max_known_cost > 0.0f) {
      float norm = max_known_cost / 255.0f;
      cost += (norm * norm * costmap_weight) / static_cast<float>(horizon);
    }

    // 分方向未知区域代价
    // trail_confidence 连续折扣: 观测过 → 折扣大, 未观测 → 全额惩罚
    const float unknown_normalizer = 1.0f / 8.0f;
    float unknown_total =
        unknown_rear_penalty  * unknown_cost_rear  +
        unknown_side_penalty  * unknown_cost_side  +
        unknown_front_penalty * unknown_cost_front;
    // 连续观测折扣: confidence=1 → observed_area_cost_scale, confidence=0 → 1.0
    unknown_total *= (1.0f - trail_confidence * (1.0f - observed_area_cost_scale));
    if (unknown_total > 0.0f) {
      cost += (unknown_total * unknown_normalizer * costmap_weight)
              / static_cast<float>(horizon);
    }

    // ③ 全局路径吸引：Cross-track error 惩罚（渐进增强，远端更严）
    // 复用上方已计算的 traj_to_path_sq，避免重复遍历路径段
    if (num_path_pts >= 2) {
      cost += traj_to_path_sq * path_attract_t;
    }

    // ④ 朝向奖励：鼓励机器人面朝行进方向
    // vx, vy 在机器人坐标系下，atan2f(vy, vx) 即为速度方向与机头朝向的偏差
    float travel_angle = atan2f(vy, vx);
    const float PI_F = 3.14159265f;
    while (travel_angle > PI_F) travel_angle -= 2.0f * PI_F;
    while (travel_angle < -PI_F) travel_angle += 2.0f * PI_F;
    cost += fabsf(travel_angle) * heading_weight / static_cast<float>(horizon);

    // ⑤ 路径长度惩罚（防止绕路）
    float step_dx = x - prev_x;
    float step_dy = y - prev_y;
    cost += sqrtf(step_dx * step_dx + step_dy * step_dy) * len_weight;

    prev_x = x;
    prev_y = y;
  }

  // ⑤ 终端代价：终点距离
  float dx_final = target_x - x;
  float dy_final = target_y - y;
  float dist_to_goal = sqrtf(dx_final * dx_final + dy_final * dy_final);
  cost += dist_to_goal * dist_weight;

  costs[s] = cost;
}

// 全时域加权求和核函数
// 2D grid: gridDim.x 覆盖样本, gridDim.y 覆盖时域步
// 对每个 timestep t 独立计算 u*_t = Σ_k w_k · sampled_u[k,t]
__global__ void mppi_weighted_sum_kernel(
    const float* __restrict__ costs,
    const float* __restrict__ sampled_vx,
    const float* __restrict__ sampled_vy,
    const float* __restrict__ sampled_w,
    float* __restrict__ result_seq,
    float min_cost,
    float lambda,
    int num_samples,
    int horizon)
{
  int s = blockIdx.x * blockDim.x + threadIdx.x;
  int t = blockIdx.y;
  if (s >= num_samples || t >= horizon) return;

  int idx = s * horizon + t;
  float weight = expf(-(costs[s] - min_cost) / lambda);

  // result_seq 布局: [vx_0, vy_0, w_0, sum_w_0, vx_1, vy_1, w_1, sum_w_1, ...]
  int base = t * 4;
  atomicAdd(&result_seq[base + 0], weight * sampled_vx[idx]);
  atomicAdd(&result_seq[base + 1], weight * sampled_vy[idx]);
  atomicAdd(&result_seq[base + 2], weight * sampled_w[idx]);
  atomicAdd(&result_seq[base + 3], weight);
}

extern "C" {

int mppi_gpu_sample_and_cost(
    const float* noise_vx, const float* noise_vy, const float* noise_w,
    const float* base_vx, const float* base_vy, const float* base_w,
    float current_x, float current_y, float current_theta,
    float target_x, float target_y,
    const unsigned char* costmap,
    int costmap_w, int costmap_h,
    float costmap_res, float costmap_origin_x, float costmap_origin_y,
    float dt, float min_v, float max_v, float max_vy, float max_w,
    float costmap_weight,
    float path_dir_x, float path_dir_y,
    float guidance_weight,
    float cross_track_noise_scale,
    float noise_decay_rate,
    float vel_direction_weight,
    float speed_reward_weight,
    float heading_weight,
    float lateral_guidance_scale,
    float unknown_cost_rear,
    float unknown_cost_side,
    float unknown_cost_front,
    const float* trail_x, const float* trail_y,
    const float* trail_cos, const float* trail_sin,
    int trail_count,
    float trust_radius_sq,
    float fov_range_sq,
    float fov_cos_half,
    float observed_area_cost_scale,
    float fp_front, float fp_back, float fp_left, float fp_right,
    const float* path_x, const float* path_y,
    int num_path_pts,
    float path_attraction_weight,
    int num_samples, int horizon,
    float* d_noise_vx, float* d_noise_vy, float* d_noise_w,
    float* d_base_vx, float* d_base_vy, float* d_base_w,
    unsigned char* d_costmap,
    float* d_path_x, float* d_path_y,
    float* d_trail_x_, float* d_trail_y_,
    float* d_trail_cos_, float* d_trail_sin_,
    float* d_costs, float* d_sampled_vx, float* d_sampled_vy, float* d_sampled_w,
    float* d_traj_x, float* d_traj_y,
    cudaStream_t stream)
{
  size_t noise_bytes = num_samples * horizon * sizeof(float);
  size_t base_bytes = horizon * sizeof(float);
  size_t costmap_bytes = costmap_w * costmap_h * sizeof(unsigned char);

  cudaError_t err;

  err = cudaMemcpyAsync(d_noise_vx, noise_vx, noise_bytes, cudaMemcpyHostToDevice, stream);
  if (err != cudaSuccess) return 1;
  err = cudaMemcpyAsync(d_noise_vy, noise_vy, noise_bytes, cudaMemcpyHostToDevice, stream);
  if (err != cudaSuccess) return 2;
  err = cudaMemcpyAsync(d_noise_w, noise_w, noise_bytes, cudaMemcpyHostToDevice, stream);
  if (err != cudaSuccess) return 3;

  err = cudaMemcpyAsync(d_base_vx, base_vx, base_bytes, cudaMemcpyHostToDevice, stream);
  if (err != cudaSuccess) return 4;
  err = cudaMemcpyAsync(d_base_vy, base_vy, base_bytes, cudaMemcpyHostToDevice, stream);
  if (err != cudaSuccess) return 5;
  err = cudaMemcpyAsync(d_base_w, base_w, base_bytes, cudaMemcpyHostToDevice, stream);
  if (err != cudaSuccess) return 6;

  err = cudaMemcpyAsync(d_costmap, costmap, costmap_bytes, cudaMemcpyHostToDevice, stream);
  if (err != cudaSuccess) return 7;

  // 上传近期轨迹点到 GPU（观测窗口）
  if (trail_count > 0 && trail_x != nullptr && trail_y != nullptr) {
    size_t trail_bytes = trail_count * sizeof(float);
    err = cudaMemcpyAsync(d_trail_x_, trail_x, trail_bytes, cudaMemcpyHostToDevice, stream);
    if (err != cudaSuccess) return 11;
    err = cudaMemcpyAsync(d_trail_y_, trail_y, trail_bytes, cudaMemcpyHostToDevice, stream);
    if (err != cudaSuccess) return 12;
    err = cudaMemcpyAsync(d_trail_cos_, trail_cos, trail_bytes, cudaMemcpyHostToDevice, stream);
    if (err != cudaSuccess) return 13;
    err = cudaMemcpyAsync(d_trail_sin_, trail_sin, trail_bytes, cudaMemcpyHostToDevice, stream);
    if (err != cudaSuccess) return 14;
  }

  // 上传全局路径点到 GPU
  if (num_path_pts > 0 && path_x != nullptr && path_y != nullptr) {
    size_t path_bytes = num_path_pts * sizeof(float);
    err = cudaMemcpyAsync(d_path_x, path_x, path_bytes, cudaMemcpyHostToDevice, stream);
    if (err != cudaSuccess) return 9;
    err = cudaMemcpyAsync(d_path_y, path_y, path_bytes, cudaMemcpyHostToDevice, stream);
    if (err != cudaSuccess) return 10;
  }

  int threads_per_block = 256;
  int blocks = (num_samples + threads_per_block - 1) / threads_per_block;

  mppi_sample_kernel<<<blocks, threads_per_block, 0, stream>>>(
      d_noise_vx, d_noise_vy, d_noise_w,
      d_base_vx, d_base_vy, d_base_w,
      current_x, current_y, current_theta,
      target_x, target_y,
      d_costmap,
      costmap_w, costmap_h,
      costmap_res, costmap_origin_x, costmap_origin_y,
      dt, min_v, max_v, max_vy, max_w,
      costmap_weight,
      path_dir_x, path_dir_y,
      guidance_weight,
      cross_track_noise_scale,
      noise_decay_rate,
      vel_direction_weight,
      speed_reward_weight,
      heading_weight,
      lateral_guidance_scale,
      unknown_cost_rear,
      unknown_cost_side,
      unknown_cost_front,
      d_trail_x_, d_trail_y_,
      d_trail_cos_, d_trail_sin_,
      trail_count,
      trust_radius_sq,
      fov_range_sq,
      fov_cos_half,
      observed_area_cost_scale,
      fp_front, fp_back, fp_left, fp_right,
      d_path_x, d_path_y,
      num_path_pts,
      path_attraction_weight,
      num_samples, horizon,
      d_costs, d_sampled_vx, d_sampled_vy, d_sampled_w,
      d_traj_x, d_traj_y);

  err = cudaGetLastError();
  if (err != cudaSuccess) return 8;

  return 0;
}

int mppi_gpu_weighted_sum(
    const float* d_costs,
    const float* d_sampled_vx, const float* d_sampled_vy, const float* d_sampled_w,
    float* d_result_seq,
    float min_cost,
    float lambda,
    int num_samples,
    int horizon,
    cudaStream_t stream)
{
  // result_seq 有 horizon * 4 个 float
  cudaError_t err = cudaMemsetAsync(d_result_seq, 0, horizon * 4 * sizeof(float), stream);
  if (err != cudaSuccess) return 1;

  int threads_per_block = 256;
  int blocks_per_t = (num_samples + threads_per_block - 1) / threads_per_block;

  dim3 grid(blocks_per_t, horizon);
  mppi_weighted_sum_kernel<<<grid, threads_per_block, 0, stream>>>(
      d_costs, d_sampled_vx, d_sampled_vy, d_sampled_w,
      d_result_seq,
      min_cost, lambda,
      num_samples, horizon);

  err = cudaGetLastError();
  if (err != cudaSuccess) return 2;

  return 0;
}

}  // extern "C"
