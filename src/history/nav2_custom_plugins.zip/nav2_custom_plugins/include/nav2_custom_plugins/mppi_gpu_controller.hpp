#ifndef NAV2_CUSTOM_PLUGINS__MPPI_GPU_CONTROLLER_HPP_
#define NAV2_CUSTOM_PLUGINS__MPPI_GPU_CONTROLLER_HPP_

#include <string>
#include <memory>
#include <vector>
#include <deque>
#include <random>

#include "nav2_core/controller.hpp"
#include "rclcpp/rclcpp.hpp"
#include "pluginlib/class_list_macros.hpp"
#include "geometry_msgs/msg/twist_stamped.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "nav_msgs/msg/path.hpp"
#include "nav2_costmap_2d/costmap_2d_ros.hpp"
#include "visualization_msgs/msg/marker_array.hpp"

namespace nav2_custom_plugins
{

/// 近期轨迹点：位置 + 朝向，用于 GPU 观测窗口的 FOV 视锥检查
struct TrailPose
{
  double x, y, cos_theta, sin_theta;
};

/**
 * @class MPPIGPUController
 * @brief GPU 加速的 MPPI 控制器
 *
 * 将 MPPI 控制器的采样、轨迹滚动和代价计算卸载到 GPU 上并行执行。
 * CUDA 线程一对一映射到采样轨迹，实现大规模并行加速。
 * 在 Jetson Orin 等嵌入式 GPU 平台上可获得显著性能提升。
 */
class MPPIGPUController : public nav2_core::Controller
{
public:
  MPPIGPUController() = default;
  ~MPPIGPUController() override = default;

  void configure(
    const rclcpp_lifecycle::LifecycleNode::WeakPtr & parent,
    std::string name, std::shared_ptr<tf2_ros::Buffer> tf,
    std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros) override;

  void cleanup() override;
  void activate() override;
  void deactivate() override;

  void setPlan(const nav_msgs::msg::Path & path) override;

  geometry_msgs::msg::TwistStamped computeVelocityCommands(
    const geometry_msgs::msg::PoseStamped & pose,
    const geometry_msgs::msg::Twist & velocity,
    nav2_core::GoalChecker * goal_checker) override;

  void setSpeedLimit(const double & speed_limit, const bool & percentage) override;

private:
  rclcpp_lifecycle::LifecycleNode::WeakPtr node_;
  std::shared_ptr<tf2_ros::Buffer> tf_;
  std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros_;
  nav_msgs::msg::Path global_plan_;
  std::string plugin_name_;

  // MPPI 参数
  int num_samples_ = 1000;
  int prediction_horizon_ = 15;
  double dt_ = 0.3;
  double max_v_ = 2.0;
  double min_v_ = -2.0;
  double max_vy_ = 2.0;
  double max_w_ = 0.5;
  double action_std_v_ = 0.2;
  double action_std_vy_ = 0.15;
  double action_std_w_ = 0.2;
  double lambda_ = 50.0;
  double costmap_weight_ = 10.0;
  double path_attraction_weight_ = 1.0;
  double lookahead_distance_ = 1.0;
  double lookahead_time_ = 2.0;
  double min_lookahead_dist_ = 2.0;
  double guidance_weight_ = 0.3;  // 路径引导权重: 0=完全跟随base, 1=完全锚定路径
  double cross_track_noise_scale_ = 0.3;
  double noise_decay_rate_ = 0.7;
  double vel_direction_weight_ = 0.3;
  double speed_reward_weight_ = 2.0;
  double heading_weight_ = 0.5;      // 朝向目标奖励权重
  double lateral_guidance_scale_ = 0.2; // 横向 guidance 缩放 (0~1)，越小越抑制侧移
  double ema_alpha_ = 0.2;               // 输出 EMA 平滑系数: 0=完全冻结, 1=无平滑
  double unknown_cost_rear_ = 1.0;   // 后方未知区域代价权重 (0~1)
  double unknown_cost_side_ = 0.7;   // 侧方未知区域代价权重 (0~1)
  double unknown_cost_front_ = 0.0;  // 前方未知区域代价权重 (0~1)
  double observation_window_duration_ = 5.0;  // 观测窗口时长 (s)
  double trust_radius_ = 0.5;         // 信任半径 (m)，距近期轨迹多近算安全
  double fov_half_angle_ = 45.0;      // 传感器 FOV 半角 (度)，90° 总 FOV
  double fov_range_ = 3.0;            // 传感器有效观测距离 (m)
  double observed_area_cost_scale_ = 0.1; // 观测窗口内未知代价缩放 (0~1)，越小越信任
  double footprint_front_ = 0.3;   // 碰撞箱前向半尺寸 (m)
  double footprint_back_ = 0.3;    // 碰撞箱后向半尺寸 (m)
  double footprint_left_ = 0.4;    // 碰撞箱左向半尺寸 (m)
  double footprint_right_ = 0.4;   // 碰撞箱右向半尺寸 (m)
  static constexpr int MAX_PATH_POINTS = 30;
  static constexpr int MAX_TRAIL_POINTS = 200;  // 最大轨迹点缓存 (10s @ 20Hz)

  // 最优控制序列记忆（滚动窗口）
  std::vector<double> optimal_vx_seq_;
  std::vector<double> optimal_vy_seq_;
  std::vector<double> optimal_omega_seq_;
  bool initialized_ = false;

  // 上一帧前瞻点位置，用于帧间平滑，避免跳变
  double prev_lookahead_x_ = 0.0;
  double prev_lookahead_y_ = 0.0;
  bool has_prev_lookahead_ = false;

  // 横向偏好方向：打破对称障碍物的左右抉择困境
  // -1.0 = 偏好左绕, 0.0 = 无偏好, +1.0 = 偏好右绕
  // 每帧基于 costmap 分析更新，带迟滞避免振荡
  double preferred_lateral_dir_ = 0.0;
  bool enable_lateral_bias_ = true;  // 是否启用横向偏好分析

  // 输出 EMA 平滑状态（帧间低通滤波，抑制控制量跳变）
  double ema_cmd_vx_ = 0.0;
  double ema_cmd_vy_ = 0.0;
  double ema_cmd_w_ = 0.0;
  bool ema_initialized_ = false;

  // 随机数生成器（噪声预生成）
  std::mt19937 generator_;
  std::normal_distribution<> dist_vx_;
  std::normal_distribution<> dist_vy_;
  std::normal_distribution<> dist_w_;

  // GPU 缓冲区（持久分配，避免反复 cudaMalloc）
  float *d_noise_vx_ = nullptr;
  float *d_noise_vy_ = nullptr;
  float *d_noise_w_ = nullptr;
  float *d_base_vx_ = nullptr;
  float *d_base_vy_ = nullptr;
  float *d_base_w_ = nullptr;
  float *d_costs_ = nullptr;
  float *d_sampled_vx_ = nullptr;   // N × H: 每条采样轨迹每步的实际 vx
  float *d_sampled_vy_ = nullptr;   // N × H: 每条采样轨迹每步的实际 vy
  float *d_sampled_w_  = nullptr;   // N × H: 每条采样轨迹每步的实际 omega
  float *d_result_seq_ = nullptr;   // H × 4: 每个 timestep 的 [vx, vy, w, weight_sum]
  unsigned char *d_costmap_ = nullptr;
  float *d_path_x_ = nullptr;
  float *d_path_y_ = nullptr;
  float *d_traj_x_ = nullptr;
  float *d_traj_y_ = nullptr;
  float *d_trail_x_ = nullptr;   // 近期轨迹点 x (观测窗口)
  float *d_trail_y_ = nullptr;   // 近期轨迹点 y (观测窗口)
  float *d_trail_cos_ = nullptr; // 近期轨迹点 cos_θ (观测窗口 FOV)
  float *d_trail_sin_ = nullptr; // 近期轨迹点 sin_θ (观测窗口 FOV)

  // 近期轨迹缓存 (观测窗口)：位置 + 朝向，用于 FOV 视锥检查
  std::deque<TrailPose> trail_poses_;

  int costmap_w_ = 0;
  int costmap_h_ = 0;
  bool gpu_buffers_allocated_ = false;

  void allocateGPUBuffers();
  void freeGPUBuffers();

  // 可视化发布者
  rclcpp::Publisher<visualization_msgs::msg::MarkerArray>::SharedPtr vis_pub_;

  void publishVisualization(
    double robot_x, double robot_y, double robot_theta,
    double target_x, double target_y,
    const std::vector<float>& traj_data_x,
    const std::vector<float>& traj_data_y,
    int vis_samples,
    int best_idx,
    const std::string& frame_id);
};

}  // namespace nav2_custom_plugins

#endif  // NAV2_CUSTOM_PLUGINS__MPPI_GPU_CONTROLLER_HPP_
